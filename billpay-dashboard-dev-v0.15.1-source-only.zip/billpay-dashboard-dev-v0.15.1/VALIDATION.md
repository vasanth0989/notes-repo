# Version 0.15.1 validation — 2026-11-04

83 tests and TypeScript/Vite build pass on Windows. Tests verify unmatched-only and combined exclusions, overlap with closed outcomes, exact TXT groups, default retention, conflict retention, empty reference handling and leading-zero distinctions. No fresh browser test for this patch. No new dependencies.

# Version 0.15.0 validation — 2026-11-02

81 tests and TypeScript/Vite build pass on Windows. Browser: synthetic Member/Consumer-only import with pre-deconversion toggle completes without missing-payee/payment warnings; only customer/funding overview tiles remain, unsupported menus disabled. Closed-account analysis yields two matched zero-remaining pairs and one nonmatch; payment controls are hidden. Unit tests check both-file requirement, ignored extra layouts, full-mode preservation and retained parsing/linking errors. No production/Mac validation claimed. No added dependencies.

# Version 0.14.2 validation — 2026-10-29

79 tests and TypeScript/Vite build pass on Windows. Native npm audit reports zero vulnerabilities. New test verifies exact exclusion TXT contents, leading zeros, first-seen order, unique disjoint groups, chart count agreement, outside-driver omission, invalid export group rejection and empty groups. Preview ID guards remain in worker. No fresh browser download verification for this patch. No new dependencies.

# Version 0.14.1 validation — 2026-10-29

78 tests and TypeScript/Vite build pass on Windows. The server test required local loopback access. Browser verified synthetic closed-pair-to-CIF reconciliation and a segment count of 2 delivery profiles versus 3 driver CIFs. Expanded local examples rendered with preserved leading zeros; panel spacing and text readability reviewed. Production counts must be reconciled on the user machine. No dependencies added. Export rules unchanged.

# Version 0.14.0 validation — 2026-10-29

Windows: all 76 tests pass; TypeScript and Vite production build pass. npm lockfile audit reports zero vulnerabilities. No dependencies added; Vite remains 8.3.4.

Driver builder tests cover full-workbook exclusions outside the delivery, deduplicated union/overlap, all closure outcomes, unmatched/conflicting segmentation retained, required evidence, invalid closure inputs, strict UTF-8, leading zeros, BOM/CRLF, malformed/header/CSV rejection, and streaming across a 1 MiB boundary.

Browser verification with synthetic data: menu disabled before segmentation and enabled afterward; six Finacle lines become five unique CIFs. Three segment exclusions and two closed-account exclusions overlap on one CIF, removing four and retaining one. The downloaded TXT was verified to contain exactly 000000777 followed by CRLF. Changing a criterion cleared the preview/export; recalculation produced the expected new counts. The final v0.14.0 screen was visually inspected. Screenshot and synthetic fixtures remain outside the release archive in ../driver-builder-verification/.

The source-only release excludes dist, node_modules, vendor, screenshots and datasets. README documents input formats, worker protocol, exclusion semantics and limitations. Mac execution and production-data reconciliation have not been independently tested for this release. Closed-account outcomes use the supplied current-delivery funding inventory, not a live account-status lookup.
# Version 0.13.1 validation
67 tests and TypeScript/Vite production build pass on Windows. Includes new payment/customer/account isolation, model-only association, history exclusion, reference conflicts, missing/rejected files, unlinked records, filter/export behavior, and end-to-end fixed-width delivery aggregation. No new dependencies. No fresh browser visual verification for this patch. Previous version browser evidence is retained below.

# Validation — 0.13.0

2026-10-23, Windows. 62 automated tests pass. TypeScript and Vite 8.3.4 build pass. Native npm lockfile audit: zero reported vulnerabilities. Registry dependencies only, including community @e965/xlsx 0.20.3 via xlsx alias. No vendor or dist shipped.

New tests cover segment CIF deduplication/leading zeros/parent segments; whole-input multi-account removal; repeated funding and input rows; wrong-CIF/foreign-account nonmatches; ambiguous CIF ownership; unknown account identifiers; malformed and oversized lines; streamed BOM/CRLF/final line handling; combined filters, stable numeric sorting, all-page exports and exact account navigation. Existing 54 tests remain green.

Browser: selected segment 1.B downloaded exactly two synthetic CIFs with leading zeros. Closed-account fixture yielded three matched pairs/two customers, two unmatched pairs, one duplicate and one invalid row. Current/post counts were 3/1, 3/1 and 1/0. Ascending sort placed zero first; Zero remaining export downloaded exactly 000000002,00400 with no header. Matched account navigation opened only account 00400 for its customer. All data used was synthetic; no production files supplied.

Core benchmark: 100,000 synthetic customers, 300,000 distinct funding accounts and 700,000 input lines (400,000 duplicates), approximately 0.825 seconds for indexing, matching and aggregation on Windows Node. This excludes input I/O, browser rendering and exports. No Mac performance claim is made.

No sample files, screenshots, node_modules, vendor archives or dist in the source-only ZIP. Run npm install and npm run build. Actual production-file reconciliation remains a local user validation step. Post Removal models the supplied valid matches only and does not authorize unenrollment or confirm live status.

