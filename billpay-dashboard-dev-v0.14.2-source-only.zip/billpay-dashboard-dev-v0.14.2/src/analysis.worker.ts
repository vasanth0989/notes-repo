import {readDriverFile,prepareDriverPreview,driverText,driverPopulation,driverSegments} from './core/driver-builder.mjs';
import {segmentCifs,analyzeClosed,closedPage,exportClosed} from './core/closed-accounts.mjs';
import {parseSegmentation,applySegmentation} from './core/segmentation.mjs';
import {analyzeFiles} from './core/stream.mjs';
import {pageEntities,pagePayments,publicResult,summary} from './core/explore.mjs';
import catalog from './layouts.json';
let closedAnalysis:any=null,segmentationReference:any=null,builderPreview:any=null;
let builderGeneration=0;
let result:any=null,inputs:any[]=[],queryAbort:AbortController|null=null;
self.onmessage=async({data})=>{try{
 if(data.type==='builder-analyze'){
  if(!result?.segmentation||!segmentationReference)throw Error('Complete segmentation before building a driver file.');
  const generation=++builderGeneration;builderPreview=null;
  const population=await readDriverFile(data.file,(bytes=0,total=0)=>self.postMessage({type:'builder-progress',builderId:data.builderId,message:'Reading Finacle CIFs: '+Math.round(100*bytes/(total||1))+'%'}));
  if(generation!==builderGeneration)return;
  if((data.outcomes||[]).some((key:string)=>['zero','remaining','unknown'].includes(key))&&['member','consumer'].some(id=>!result.files.some((f:any)=>f.layout===id&&f.rejected===0)))throw Error('Closed-account exclusions require Member and Consumer files with no rejected rows. Resolve delivery coverage first.');
  const closed=data.closedFile?await analyzeClosed(data.closedFile,result,(bytes=0,total=0)=>self.postMessage({type:'builder-progress',builderId:data.builderId,message:'Matching closed accounts: '+Math.round(100*bytes/(total||1))+'%'})):null;
  if(generation!==builderGeneration)return;
  const computed=prepareDriverPreview(population.cifs,segmentationReference,closed,{segments:data.segments,outcomes:data.outcomes,customers:result.customers});
  builderPreview={...computed,source:population.source,previewId:crypto.randomUUID(),builderId:data.builderId};
  self.postMessage({type:'builder-result',builderId:data.builderId,previewId:builderPreview.previewId,source:builderPreview.source,summary:builderPreview.summary});return;
 }
 if(data.type==='builder-export'){
  if(!builderPreview||data.previewId!==builderPreview.previewId||data.builderId!==builderPreview.builderId)throw Error('Preview the driver file again before exporting.');
  const group=data.group??'retained',cifs=driverPopulation(builderPreview,group);
  if(!cifs.length)throw Error('No CIFs in this export group.');
  self.postMessage({type:'export',builderId:data.builderId,filename:'fis-driver-'+group+'-'+result.asOf+'-'+cifs.length+'-cifs.txt',blob:new Blob([driverText(builderPreview,group)],{type:'text/plain;charset=utf-8'})});return;
 }
 if(data.type==='segment-export'){
  if(!result)throw Error('Analyze the delivery first.');const exported=segmentCifs(result,data.segment);if(!exported.count)throw Error('No CIFs are available for this segment.');
  self.postMessage({type:'export',filename:'segment-'+String(data.segment||'all').replace(/[^a-z0-9.-]+/gi,'-')+'-cifs.txt',blob:new Blob([exported.text],{type:'text/plain;charset=utf-8'})});return;
 }
 if(data.type==='closed-analyze'){
  if(!result)throw Error('Analyze the deconversion delivery first.');closedAnalysis=null;
  closedAnalysis=await analyzeClosed(data.file,result,(bytes=0,total=0)=>self.postMessage({type:'closed-progress',closedId:data.closedId,percent:Math.round(100*bytes/(total||1))}));
  self.postMessage({type:'closed-result',closedId:data.closedId,...closedPage(closedAnalysis,data)});return;
 }
 if(data.type==='closed-page'){self.postMessage({type:'closed-result',closedId:data.closedId,...closedPage(closedAnalysis,data)});return;}
 if(data.type==='closed-export'){
  const text=exportClosed(closedAnalysis,data);if(!text)throw Error('No pairs match the selected filters.');
  self.postMessage({type:'export',closedId:data.closedId,filename:'closed-accounts-'+String(data.segment||'all-segments').replace(/[^a-z0-9.-]+/gi,'-')+(data.post?'-'+data.post:'')+'.txt',blob:new Blob([text],{type:'text/plain;charset=utf-8'})});return;
 }
 if(data.type==='explore'){

  if(!result)return;queryAbort?.abort();const controller=new AbortController();queryAbort=controller;
  const response=data.entity==='Payments'?await pagePayments(inputs,catalog,result,data,controller.signal):pageEntities(result,data);
  if(!controller.signal.aborted)self.postMessage({type:'explore',...response,requestId:data.requestId});return;
 }
 if(data.type==='export'){
  if(result)self.postMessage({type:'export',blob:new Blob([JSON.stringify({version:'0.14.2',note:'Provisional joins; full account numbers included; no settlement inference.',...publicResult(result)})],{type:'application/json'})});return;
 }
 queryAbort?.abort();result=null;closedAnalysis=null;segmentationReference=null;builderPreview=null;builderGeneration++;inputs=data.files;
 result=await analyzeFiles(inputs,catalog,data.asOf,data.blankModels,p=>self.postMessage({type:'progress',...p}));
 if(data.segmentationFile){const segmentStart=performance.now();self.postMessage({type:'progress',bytes:0,total:data.segmentationFile.size,records:result.metrics.customers,name:'Reading segmentation workbook and matching CIFs locally'});const reference=parseSegmentation(await data.segmentationFile.arrayBuffer(),data.segmentationFile.name);segmentationReference=reference;applySegmentation(result,reference);result.segmentation.driverSegments=driverSegments(reference);result.segmentation.seconds=(performance.now()-segmentStart)/1000;result.performance.seconds+=result.segmentation.seconds;}
 self.postMessage({type:'complete',result:summary(result)});
}catch(e){if(e instanceof Error&&e.name==='AbortError')return;self.postMessage({type:data.builderId?'builder-error':data.closedId?'closed-error':'error',builderId:data.builderId,closedId:data.closedId,requestId:data.requestId,message:e instanceof Error?e.message:'Analysis failed.'});}};

