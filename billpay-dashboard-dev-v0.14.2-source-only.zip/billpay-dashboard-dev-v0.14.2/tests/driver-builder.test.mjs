import test from 'node:test';
import assert from 'node:assert/strict';
import {prepareDriverPreview,driverText} from '../src/core/driver-builder.mjs';
const reference=()=>({assignments:new Map([['0001',{code:'SEGMENT 3'}],['0002',{code:'SEGMENT 3'}],['0003',{code:'SEGMENT 1.A'}],['0004',{code:null,conflict:true}]]),definitions:new Map([['SEGMENT 3','Enrolled only']])});
const closures=()=>({summary:{invalid:0},rows:[{cif:'0002',status:'Matched',post:0},{cif:'0002',status:'Matched',post:0},{cif:'0003',status:'Matched',post:0},{cif:'outside',status:'Matched',post:0}]});
test('builder unions exclusions within driver population, counts overlap once and preserves zeros/order',()=>{
 const p=prepareDriverPreview(['0001','0002','0003','0005','0005'],reference(),closures(),{segments:['SEGMENT 3'],outcomes:['zero']});
 assert.deepEqual([p.summary.total,p.summary.bySegment,p.summary.byClosed,p.summary.overlap,p.summary.excluded,p.summary.retained],[4,2,2,1,3,1]);assert.equal(driverText(p),'0005\r\n');assert.equal(p.summary.closedCriteria[0].outsideDriver,1);
});
test('builder does not drop unknown or conflicting segment assignments without another selected criterion',()=>{
 const p=prepareDriverPreview(['0004','0005'],reference(),null,{segments:['SEGMENT 3']});assert.equal(p.summary.unmatchedSegment,1);assert.equal(p.summary.conflictedSegment,1);assert.equal(p.summary.unresolvedRetained,2);assert.equal(p.summary.retained,2);
});
test('builder requires reference and closed evidence for selected outcomes; rejects invalid criteria and partial closure input',()=>{
 assert.throws(()=>prepareDriverPreview([],null,null),/segmentation/);assert.throws(()=>prepareDriverPreview([],reference(),null,{outcomes:['zero']}),/closed-account/);assert.throws(()=>prepareDriverPreview([],reference(),closures(),{segments:['SEGMENT 9']}),/segment/);assert.throws(()=>prepareDriverPreview([],reference(),closures(),{outcomes:['oops']}),/Unknown/);
 assert.throws(()=>prepareDriverPreview([],reference(),{...closures(),summary:{invalid:1}},{outcomes:['zero']}),/invalid/);
});
test('builder handles all selected closure outcomes as distinct CIFs, not pair counts',()=>{
 const closed={summary:{invalid:0},rows:[{cif:'0001',status:'Matched',post:1},{cif:'0001',status:'No Match',post:null},{cif:'0002',status:'Matched',post:null},{cif:'0003',status:'Ambiguous',post:null}]};
 const p=prepareDriverPreview(['0001','0002','0003'],reference(),closed,{outcomes:['remaining','unknown','noMatch','ambiguous']});assert.equal(p.summary.byClosed,3);assert.equal(p.summary.excluded,3);assert.equal(driverText(p),'');
});
test('builder no selections exports complete unique population; input reference is never mutated',()=>{
 const ref=reference(),p=prepareDriverPreview(['0003','0001','0003'],ref,closures());assert.equal(driverText(p),'0003\r\n0001\r\n');assert.equal(ref.assignments.size,4);assert.equal(p.summary.excluded,0);
});
import {readDriverFile,driverSegments} from '../src/core/driver-builder.mjs';
test('driver TXT preserves leading zeros and order, removes BOM, skips blanks, counts duplicates',async()=>{
 const p=await readDriverFile(new File(['\uFEFF0002\r\n0001\n\n0002\n0003'],'finacle.txt'));
 assert.deepEqual([...p.cifs],['0002','0001','0003']);assert.deepEqual(p.source,{name:'finacle.txt',rows:4,duplicates:1,unique:3});
});
test('driver rejects headers, CSV, malformed UTF-8, empty content and oversized lines',async()=>{
 for(const text of ['CIF\n001','001,002','001 002','"001"','x'.repeat(1025),'x'.repeat(65),'\n\r\n'])await assert.rejects(readDriverFile(new File([text],'bad.txt')));
 await assert.rejects(readDriverFile(new File([new Uint8Array([0xff])],'bad.txt')),/UTF-8/);
});
test('driver streaming handles chunk boundaries without losing or truncating identifiers',async()=>{
 const p=await readDriverFile(new File(['0001\r\n'.repeat(180000)+'0002'],'large.txt'));
 assert.equal(p.source.rows,180001);assert.equal(p.source.duplicates,179999);assert.deepEqual([...p.cifs],['0001','0002']);
});
test('full workbook segments include reference CIFs outside delivery and keep unmatched driver CIFs',()=>{
 const ref=reference();ref.assignments.set('outside-delivery',{code:'SEGMENT 2.C'});
 assert.ok(driverSegments(ref).some(s=>s.code==='SEGMENT 2.C'));
 const p=prepareDriverPreview(['outside-delivery','unknown'],ref,null,{segments:['SEGMENT 2.C']});assert.equal(p.summary.excluded,1);assert.equal(driverText(p),'unknown\r\n');
});

test('closed reconciliation explains pairs, unique CIFs, outside driver and overlap separately',()=>{
 const s=prepareDriverPreview(['0001','0002','0003'],reference(),closures(),{segments:['SEGMENT 3'],outcomes:['zero']}).summary;
 const r=s.closedReconciliation;
 assert.deepEqual([r.pairs,r.extraPairs,r.uniqueCifs,r.outsideDriver,r.inDriver,r.overlap,r.additional],[4,1,3,1,2,1,1]);
 assert.deepEqual(r.examples,{multipleAccounts:'0002',outsideDriver:'outside',overlap:'0002',closedOnly:'0003'});
});
test('segment reconciliation separates customer profiles, multi-CIF profiles and two-way population differences',()=>{
 const ref={assignments:new Map(['01','02','03','04','05','06'].map(cif=>[cif,{code:'SEGMENT 3'}])),definitions:new Map()};
 const customers=[{segment:'SEGMENT 3',cifs:['01','02']},{segment:'SEGMENT 3',cifs:['03']},{segment:'CONFLICT',cifs:['04']}];
 const s=prepareDriverPreview(['01','02','04','05'],ref,null,{segments:['SEGMENT 3'],customers}).summary.segmentReconciliation[0];
 assert.deepEqual([s.overviewCustomers,s.overviewCifs,s.overviewOnly,s.both,s.builderOnly,s.inDriver,s.workbookOutsideDriver],[2,3,1,2,2,4,2]);
 assert.equal(s.overviewCifs-s.overviewOnly+s.builderOnly,s.inDriver);
 assert.deepEqual(s.examples,{overviewOnly:'03',builderOnly:'04',both:'01'});
});

test('exclusion exports are distinct, complete, preserve zeros/order and agree with chart counts',()=>{
 const p=prepareDriverPreview(['0003','0002','0001','0001','0005'],reference(),closures(),{segments:['SEGMENT 3'],outcomes:['zero']});
 assert.equal(driverText(p,'segmentOnly'),'0001\r\n');assert.equal(driverText(p,'closedOnly'),'0003\r\n');assert.equal(driverText(p,'both'),'0002\r\n');assert.equal(driverText(p),'0005\r\n');
 assert.equal(p.groups.segmentOnly.length,p.summary.segmentOnly);assert.equal(p.groups.closedOnly.length,p.summary.closedOnly);assert.equal(p.groups.both.length,p.summary.overlap);
 const excluded=Object.values(p.groups).flat();assert.equal(new Set(excluded).size,p.summary.excluded);assert.equal(excluded.includes('outside'),false);
 assert.throws(()=>driverText(p,'__proto__'),/Unknown/);
 const empty=prepareDriverPreview(['0001'],reference(),null);assert.equal(driverText(empty,'both'),'');assert.equal(driverText(empty,'segmentOnly'),'');
});
