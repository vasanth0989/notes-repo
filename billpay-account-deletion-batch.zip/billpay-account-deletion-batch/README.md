# BillPay Account Deletion Batch

Standalone Java 21 / Gradle / Spring Boot 3.5.16 / Spring Batch application.
H2 in-memory stores Spring Batch metadata. No web server or UI.

## Run

Install JDK 21 and select it as the Gradle JVM in IntelliJ. Import this folder's
settings.gradle as a Gradle project. The Gradle wrapper is included.

Windows:
```powershell
.\gradlew.bat clean build
.\gradlew.bat bootRun --args="inputFile=input/sample-accounts.psv runId=demo-1"
```

macOS / Linux:
```bash
bash gradlew clean build
bash gradlew bootRun --args='inputFile=input/sample-accounts.psv runId=demo-1'
```

IntelliJ Gradle Run field:
```text
bootRun --args="inputFile=input/sample-accounts.psv runId=demo-1"
```

The sample contains 473 synthetic records. Run input/sample-errors.psv for failure examples.
Input originals remain in place. Output defaults to
output/yyyyMMdd-HHmmss-<execution-id>/account-deletion-report.psv.
An optional outputDir job parameter overrides the directory. Existing reports are never overwritten.
Use a distinct output directory for subsequent executions.

## Layouts

UTF-8 pipe-separated files without headers. Preserve identifiers as strings, including leading zeros.

Input: GIF|AccountNumber
```text
GIF000001|100000000001
```

Output: GIF|AccountNumber|AccountId|Status|Message
```text
GIF000001|100000000001|FIS-000001|DELETED|Funding account deleted
NOT_FOUND|123||FAILED|Funding account not found
DELETE_ERROR|999|FAIL|FAILED|Funding account deletion failed
```

GIF follows the requested identifier name. If your source export uses CIF, map that
customer identifier into the first column. No extra final blank line is required.
Malformed nonempty rows produce FAILED output. Completely empty lines may be ignored
by the underlying flat-file reader; do not include empty records.
Rows can arrive out of input order when parallel processing is enabled.

## Processing

Reader -> AccountDeletionProcessor -> Fiso -> FisService -> report writer.

Fiso retrieves funding accounts using GIF, finds exactly one account whose number
matches the input, and returns its account ID. The processor passes GIF and that ID
to the deletion operation. Missing, ambiguous, or blank IDs prevent deletion.
The resolved ID remains in output if deletion fails.

FisService defines both SOAP operation boundaries. SampleFisService is a runnable dummy,
not a live SOAP integration. It returns two deterministic accounts for GIF000001
through GIF999999; the account matching 100000 plus the six-digit suffix is deleted
successfully. NOT_FOUND, LOOKUP_ERROR, and DELETE_ERROR demonstrate failures.
Replace this implementation with a SOAP adapter using your WSDL-generated types,
endpoint, credentials and timeouts. The adapter must validate SOAP business errors as
well as transport faults, and throw FisServiceException with a sanitized message.
No real account is deleted by this sample.

## Chunk Size and Parallelism

application.yml:
```yaml
deletion:
  chunk-size: 10
  concurrency: 4
```

chunk-size is records per transaction, not a maximum number of records in the job.
concurrency limits simultaneously executing workers/chunks. Set concurrency to 1
for sequential execution. A Spring ThreadPoolTaskExecutor uses a fixed-size pool
and bounded queue. Partitions contain disjoint ranges aligned to chunk boundaries.
For 473 records at chunk size 10, there are 47 full data chunks and one 3-record chunk.
All records are processed; there is no hardcoded 473-record limit.

Override with DELETION_CHUNK_SIZE and DELETION_CONCURRENCY environment variables
or --deletion.chunk-size=10 --deletion.concurrency=4 application arguments.

Each partition has its own reader. The shared report writer synchronizes chunk writes.
Run one job execution per application process.

## Errors and Logging

No retry or skip policies are enabled. Record validation, lookup and deletion failures
produce FAILED rows and processing continues. Infrastructure failures (missing input,
unwritable output, report write failure) fail the job. A completed job can contain
FAILED rows, so inspect the report.

Logs are written to logs/account-deletion.log and the console. Listeners record job
completion and each committed chunk; processing logs record input line and outcome.
Full customer/account identifiers and SOAP payloads are not logged.

SOAP deletion is an external side effect and cannot be rolled back with an H2
transaction. A crash after deletion may leave an incomplete report. Automatic retries
are disabled; reconcile downstream state before rerunning live deletions. H2 metadata
is lost on process exit; this skeleton does not provide durable restart or deduplication.

## Packages and Tests

Uses com.discover.billpay.migration.batch with config, domain, model, exception,
listener, processor, reader, service, and writer packages.
Lombok supplies configuration accessors, constructors, logging, and result builders.
Java records represent immutable input/account data; Java 21 getFirst and streams
support account matching.

```text
./gradlew test
```

Full-context batch integration tests launch actual jobs against temporary files and H2.
They verify 473 output records, correct account IDs, bounded parallel execution,
failure results, no repeated service calls, preserved input, missing-file failure,
and output overwrite protection. Tests replace only the FIS boundary.

## Distribution

The source ZIP includes the wrapper, source, tests, sample input and this README.
It excludes build, .gradle, logs, output and IDE files.
