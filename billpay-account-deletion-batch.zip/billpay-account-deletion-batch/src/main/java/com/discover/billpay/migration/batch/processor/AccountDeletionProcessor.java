package com.discover.billpay.migration.batch.processor;

import com.discover.billpay.migration.batch.domain.*;
import com.discover.billpay.migration.batch.service.Fiso;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class AccountDeletionProcessor implements ItemProcessor<AccountInput, DeletionResult> {
    private final Fiso fiso;

    @Override
    public DeletionResult process(AccountInput input) {
        var result = DeletionResult.builder().lineNumber(input.lineNumber())
                .gif(input.gif()).accountNumber(input.accountNumber()).accountId("");
        if (input.validationError() != null) {
            log.warn("Deletion FAILED at input line {}: invalid input", input.lineNumber());
            return result.status(DeletionStatus.FAILED).message(input.validationError()).build();
        }
        try {
            var accountId = fiso.resolveAccountId(input.gif(), input.accountNumber());
            result.accountId(accountId);
            fiso.deleteFundingAccount(input.gif(), accountId);
            log.info("Deletion DELETED at input line {}", input.lineNumber());
            return result.status(DeletionStatus.DELETED).message("Funding account deleted").build();
        } catch (RuntimeException ex) {
            // Do not expose SOAP payloads, credentials, or customer identifiers in logs/output.
            log.warn("Deletion FAILED at input line {}, exceptionType={}",
                    input.lineNumber(), ex.getClass().getSimpleName());
            var reason = ex instanceof com.discover.billpay.migration.batch.exception.FisServiceException
                    ? ex.getMessage() : "Unexpected FIS operation failure";
            return result.status(DeletionStatus.FAILED).message(reason).build();
        }
    }
}
