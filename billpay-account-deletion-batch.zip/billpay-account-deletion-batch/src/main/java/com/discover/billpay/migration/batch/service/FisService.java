package com.discover.billpay.migration.batch.service;

import com.discover.billpay.migration.batch.model.FundingAccount;
import java.util.List;

// Adapter boundary for the two FIS SOAP operations.
public interface FisService {
    List<FundingAccount> getFundingAccounts(String gif);
    void deleteFundingAccount(String gif, String accountId);
}
