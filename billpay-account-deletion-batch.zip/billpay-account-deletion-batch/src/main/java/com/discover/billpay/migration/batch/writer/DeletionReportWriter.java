package com.discover.billpay.migration.batch.writer;

import com.discover.billpay.migration.batch.domain.DeletionResult;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;

public class DeletionReportWriter implements ItemWriter<DeletionResult> {
    private Path output;
    public synchronized void initialize(Path output) { this.output = output; }

    @Override
    public synchronized void write(Chunk<? extends DeletionResult> chunk) throws IOException {
        var text = new StringBuilder();
        for (var item : chunk) {
            text.append(String.join("|", clean(item.getGif()), clean(item.getAccountNumber()),
                    clean(item.getAccountId()), item.getStatus().name(), clean(item.getMessage()))).append('\n');
        }
        Files.writeString(output, text, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
    }

    private String clean(String value) {
        return value == null ? "" : value.replace('|', ' ').replace('\r', ' ').replace('\n', ' ').strip();
    }
}
