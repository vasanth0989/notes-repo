package com.discover.billpay.migration.batch;

import com.discover.billpay.migration.batch.config.DeletionProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(DeletionProperties.class)
public class BillPayMigration {
    public static void main(String[] args) {
        var context = SpringApplication.run(BillPayMigration.class, args);
        System.exit(SpringApplication.exit(context));
    }
}
