package com.discover.billpay.migration.batch.config;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Data
@Validated
@ConfigurationProperties("deletion")
public class DeletionProperties {
    @Min(1) @Max(10000)
    private int chunkSize = 10;
    @Min(1) @Max(32)
    private int concurrency = 4;
}
