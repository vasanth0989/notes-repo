package com.discover.billpay.migration.batch.exception;

public class FisServiceException extends RuntimeException {
    public FisServiceException(String message) { super(message); }
    public FisServiceException(String message, Throwable cause) { super(message, cause); }
}
