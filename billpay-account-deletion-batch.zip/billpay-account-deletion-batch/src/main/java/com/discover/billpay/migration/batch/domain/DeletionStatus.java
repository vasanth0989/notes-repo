package com.discover.billpay.migration.batch.domain;

public enum DeletionStatus { DELETED, FAILED }
