package com.discover.billpay.migration.batch.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class BatchLoggingListener implements JobExecutionListener, ChunkListener {
    @Override
    public void beforeJob(JobExecution job) {
        log.info("Starting job {} execution={}", job.getJobInstance().getJobName(), job.getId());
    }
    @Override
    public void afterJob(JobExecution job) {
        log.info("Job finished status={}, output={}", job.getStatus(),
                job.getExecutionContext().getString("reportPath", "not created"));
    }
    @Override
    public void afterChunk(ChunkContext context) {
        var step = context.getStepContext().getStepExecution();
        log.info("Chunk committed step={} read={} written={} commits={}",
                step.getStepName(), step.getReadCount(), step.getWriteCount(), step.getCommitCount());
    }
    @Override
    public void afterChunkError(ChunkContext context) {
        log.error("Chunk failed step={}", context.getStepContext().getStepName());
    }
}
