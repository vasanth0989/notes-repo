package com.discover.billpay.migration.batch.service;

import com.discover.billpay.migration.batch.exception.FisServiceException;
import com.discover.billpay.migration.batch.model.FundingAccount;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class SampleFisService implements FisService {
    @Override
    public List<FundingAccount> getFundingAccounts(String gif) {
        if ("LOOKUP_ERROR".equals(gif)) throw new FisServiceException("Funding account lookup failed");
        if ("NOT_FOUND".equals(gif)) return List.of();
        if ("DELETE_ERROR".equals(gif)) return List.of(new FundingAccount("999", "FAIL"));
        if (!gif.matches("GIF[0-9]{6}")) return List.of();
        var suffix = gif.substring(3);
        return List.of(new FundingAccount("100000" + suffix, "FIS-" + suffix),
                new FundingAccount("200000" + suffix, "OTHER-" + suffix));
    }

    @Override
    public void deleteFundingAccount(String gif, String accountId) {
        if ("FAIL".equals(accountId)) throw new FisServiceException("Funding account deletion failed");
        // TODO Invoke the deletion SOAP operation and validate its business response.
    }
}
