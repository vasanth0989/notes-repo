package com.discover.billpay.migration.batch.domain;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class DeletionResult {
    long lineNumber;
    String gif;
    String accountNumber;
    String accountId;
    DeletionStatus status;
    String message;
}
