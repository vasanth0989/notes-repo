package com.discover.billpay.migration.batch.service;

import com.discover.billpay.migration.batch.exception.FisServiceException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class Fiso {
    private final FisService fisService;

    public String resolveAccountId(String gif, String accountNumber) {
        var accounts = fisService.getFundingAccounts(gif);
        if (accounts == null) throw new FisServiceException("Funding account lookup returned no response");
        var matches = accounts.stream()
                .filter(account -> account != null && accountNumber.equals(account.accountNumber()))
                .toList();
        if (matches.size() != 1) {
            throw new FisServiceException(matches.isEmpty()
                    ? "Funding account not found" : "Multiple funding accounts match; deletion not attempted");
        }
        var id = matches.getFirst().accountId();
        if (id == null || id.isBlank()) throw new FisServiceException("Funding account ID is missing");
        return id;
    }

    public void deleteFundingAccount(String gif, String accountId) {
        fisService.deleteFundingAccount(gif, accountId);
    }
}
