package com.discover.billpay.migration.batch.config;

import com.discover.billpay.migration.batch.domain.*;
import com.discover.billpay.migration.batch.listener.BatchLoggingListener;
import com.discover.billpay.migration.batch.processor.AccountDeletionProcessor;
import com.discover.billpay.migration.batch.reader.AccountFileReader;
import com.discover.billpay.migration.batch.writer.DeletionReportWriter;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.*;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@RequiredArgsConstructor
public class AccountDeletionJobConfig {
    private final DeletionProperties properties;

    @Bean
    public ThreadPoolTaskExecutor deletionExecutor() {
        var executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(properties.getConcurrency());
        executor.setMaxPoolSize(properties.getConcurrency());
        executor.setQueueCapacity(properties.getConcurrency());
        executor.setThreadNamePrefix("deletion-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(60);
        return executor;
    }

    @Bean
    public Job accountDeletionJob(JobRepository repository, Step prepareStep, Step deletionManager,
                                  BatchLoggingListener listener) {
        return new JobBuilder("accountDeletionJob", repository)
                .validator(parameters -> {
                    var input = parameters.getString("inputFile");
                    if (input == null || input.isBlank())
                        throw new JobParametersInvalidException("inputFile is required");
                })
                .listener(listener).start(prepareStep).next(deletionManager).build();
    }

    @Bean
    public Step prepareStep(JobRepository repository, PlatformTransactionManager transactionManager,
                            DeletionReportWriter reportWriter) {
        return new StepBuilder("prepareStep", repository).tasklet((contribution, context) -> {
            var job = contribution.getStepExecution().getJobExecution();
            var input = Path.of(job.getJobParameters().getString("inputFile")).toAbsolutePath().normalize();
            long count;
            try (var lines = Files.lines(input)) { count = lines.count(); }
            if (count == 0) throw new IllegalArgumentException("Input file is empty");
            if (count > Integer.MAX_VALUE) throw new IllegalArgumentException("Input file exceeds supported row count");
            var configured = job.getJobParameters().getString("outputDir");
            var directory = configured == null
                    ? Path.of("output", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))
                            + "-" + job.getId())
                    : Path.of(configured);
            Files.createDirectories(directory);
            var report = directory.resolve("account-deletion-report.psv").toAbsolutePath().normalize();
            if (input.equals(report)) throw new IllegalArgumentException("Output must differ from input");
            Files.writeString(report, "", StandardOpenOption.CREATE_NEW);
            reportWriter.initialize(report);
            job.getExecutionContext().putLong("recordCount", count);
            job.getExecutionContext().putString("reportPath", report.toString());
            return RepeatStatus.FINISHED;
        }, transactionManager).build();
    }

    @Bean
    @StepScope
    public Partitioner accountPartitioner(@Value("#{jobExecutionContext['recordCount']}") Long count) {
        return gridSize -> {
            Map<String, ExecutionContext> partitions = new LinkedHashMap<>();
            var chunkSize = properties.getChunkSize();
            var totalChunks = (count + chunkSize - 1) / chunkSize;
            var chunksPerWorker = (totalChunks + gridSize - 1) / gridSize;
            var range = chunksPerWorker * chunkSize;
            for (int i = 0; (long) i * range < count; i++) {
                var start = i * range;
                var execution = new ExecutionContext();
                execution.putInt("start", Math.toIntExact(start));
                execution.putInt("count", Math.toIntExact(Math.min(range, count - start)));
                partitions.put("partition" + i, execution);
            }
            return partitions;
        };
    }

    @Bean
    public Step deletionManager(JobRepository repository, Step deletionWorker,
                                Partitioner accountPartitioner, ThreadPoolTaskExecutor deletionExecutor) {
        return new StepBuilder("deletionManager", repository)
                .partitioner("deletionWorker", accountPartitioner).step(deletionWorker)
                .gridSize(properties.getConcurrency()).taskExecutor(deletionExecutor).build();
    }

    @Bean
    public Step deletionWorker(JobRepository repository, PlatformTransactionManager transactionManager,
                               FlatFileItemReader<AccountInput> accountReader,
                               AccountDeletionProcessor processor, DeletionReportWriter reportWriter,
                               BatchLoggingListener listener) {
        return new StepBuilder("deletionWorker", repository)
                .<AccountInput, DeletionResult>chunk(properties.getChunkSize(), transactionManager)
                .reader(accountReader).processor(processor).writer(reportWriter)
                .listener((ChunkListener) listener).allowStartIfComplete(false).build();
    }

    @Bean
    @StepScope
    public FlatFileItemReader<AccountInput> accountReader(
            @Value("#{jobParameters['inputFile']}") String input,
            @Value("#{stepExecutionContext['start']}") Integer start,
            @Value("#{stepExecutionContext['count']}") Integer count) {
        return AccountFileReader.create(input, start, count);
    }

    @Bean
    public DeletionReportWriter reportWriter() {
        return new DeletionReportWriter();
    }
}
