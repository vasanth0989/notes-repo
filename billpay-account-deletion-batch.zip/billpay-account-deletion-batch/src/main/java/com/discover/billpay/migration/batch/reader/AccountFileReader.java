package com.discover.billpay.migration.batch.reader;

import com.discover.billpay.migration.batch.domain.AccountInput;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.core.io.FileSystemResource;

public final class AccountFileReader {
    private AccountFileReader() {}

    public static FlatFileItemReader<AccountInput> create(String path, int start, int count) {
        return new FlatFileItemReaderBuilder<AccountInput>()
                .name("accountReader").resource(new FileSystemResource(path))
                .strict(true).saveState(false).comments(new String[0])
                .linesToSkip(start).maxItemCount(count)
                .lineMapper((line, number) -> parse(line, number)).build();
    }

    static AccountInput parse(String line, int number) {
        var fields = line.split("\\|", -1);
        var gif = fields.length > 0 ? fields[0].strip() : "";
        var account = fields.length > 1 ? fields[1].strip() : "";
        var error = fields.length != 2 ? "Expected GIF|AccountNumber"
                : gif.isBlank() || account.isBlank() ? "GIF and account number are required" : null;
        return new AccountInput(number, gif, account, error);
    }
}
