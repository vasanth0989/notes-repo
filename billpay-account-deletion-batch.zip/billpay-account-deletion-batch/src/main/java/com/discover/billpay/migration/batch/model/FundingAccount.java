package com.discover.billpay.migration.batch.model;

public record FundingAccount(String accountNumber, String accountId) {}
