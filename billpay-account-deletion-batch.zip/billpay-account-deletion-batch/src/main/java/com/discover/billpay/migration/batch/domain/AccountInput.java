package com.discover.billpay.migration.batch.domain;

public record AccountInput(long lineNumber, String gif, String accountNumber, String validationError) {}
