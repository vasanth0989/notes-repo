package com.discover.billpay.migration.batch;

import com.discover.billpay.migration.batch.model.FundingAccount;
import com.discover.billpay.migration.batch.service.FisService;
import com.discover.billpay.migration.batch.exception.FisServiceException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.IntStream;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@SpringBootTest(properties = {"spring.batch.job.enabled=false", "deletion.chunk-size=10", "deletion.concurrency=4"})
class AccountDeletionJobIntegrationTest {
    @Autowired JobLauncher launcher;
    @Autowired Job accountDeletionJob;
    @MockitoBean FisService fis;
    @TempDir Path temporary;

    @Test
    void processes473RecordsExactlyOnceWithBoundedParallelismAndPartialFinalChunk() throws Exception {
        var threads = ConcurrentHashMap.<String>newKeySet();
        var active = new AtomicInteger();
        var peak = new AtomicInteger();
        when(fis.getFundingAccounts(anyString())).thenAnswer(invocation -> {
            threads.add(Thread.currentThread().getName());
            int current = active.incrementAndGet();
            peak.accumulateAndGet(current, Math::max);
            try {
                Thread.sleep(2);
                var gif = invocation.<String>getArgument(0);
                var suffix = gif.substring(3);
                return List.of(new FundingAccount("WRONG", "OTHER"),
                        new FundingAccount("100000" + suffix, "FIS-" + suffix));
            } finally { active.decrementAndGet(); }
        });
        var lines = IntStream.rangeClosed(1, 473)
                .mapToObj(i -> "GIF%06d|100000%06d".formatted(i, i)).toList();
        var input = temporary.resolve("473.psv");
        Files.writeString(input, String.join("\n", lines)); // Deliberately no final newline.
        var output = temporary.resolve("out");
        var execution = launch(input, output);
        assertThat(execution.getStatus()).isEqualTo(BatchStatus.COMPLETED);
        var report = Files.readAllLines(output.resolve("account-deletion-report.psv"));
        assertThat(report).hasSize(473).doesNotHaveDuplicates()
                .allMatch(row -> row.contains("|DELETED|"));
        assertThat(report.stream().map(row -> row.split("\\|")[0]).toList())
                .containsExactlyInAnyOrderElementsOf(lines.stream().map(row -> row.split("\\|")[0]).toList());
        for (int i = 1; i <= 473; i++) {
            verify(fis).deleteFundingAccount("GIF%06d".formatted(i), "FIS-%06d".formatted(i));
        }
        verify(fis, times(473)).getFundingAccounts(anyString());
        assertThat(threads).hasSizeGreaterThan(1);
        assertThat(peak.get()).isBetween(2, 4);
        var workers = execution.getStepExecutions().stream()
                .filter(step -> step.getStepName().startsWith("deletionWorker:")).toList();
        assertThat(workers.stream().mapToLong(StepExecution::getWriteCount).sum()).isEqualTo(473);
        assertThat(workers.stream().anyMatch(step -> step.getWriteCount() % 10 == 3)).isTrue();
        assertThat(Files.readAllLines(input)).hasSize(473);
    }

    @Test
    void writesFailuresAndDoesNotRetryOrDeleteUnmatchedAccounts() throws Exception {
        when(fis.getFundingAccounts("GOOD")).thenReturn(List.of(new FundingAccount("001", "ID1")));
        when(fis.getFundingAccounts("NONE")).thenReturn(List.of());
        when(fis.getFundingAccounts("AMBIGUOUS")).thenReturn(List.of(
                new FundingAccount("003", "ID3"), new FundingAccount("003", "ID4")));
        when(fis.getFundingAccounts("LOOKUP")).thenThrow(new FisServiceException("Lookup failed"));
        when(fis.getFundingAccounts("DELETE")).thenReturn(List.of(new FundingAccount("005", "ID5")));
        doThrow(new FisServiceException("Deletion failed")).when(fis).deleteFundingAccount("DELETE", "ID5");
        var input = temporary.resolve("errors.psv");
        Files.writeString(input, "GOOD|001\nNONE|002\nAMBIGUOUS|003\nLOOKUP|004\nDELETE|005\nbad|row|extra\n|006");
        var output = temporary.resolve("errors");
        assertThat(launch(input, output).getStatus()).isEqualTo(BatchStatus.COMPLETED);
        var report = Files.readAllLines(output.resolve("account-deletion-report.psv"));
        assertThat(report).hasSize(7);
        assertThat(report.stream().filter(row -> row.contains("|FAILED|")).count()).isEqualTo(6);
        assertThat(report).contains("DELETE|005|ID5|FAILED|Deletion failed");
        verify(fis, times(5)).getFundingAccounts(anyString());
        verify(fis).deleteFundingAccount("GOOD", "ID1");
        verify(fis).deleteFundingAccount("DELETE", "ID5");
        verify(fis, times(2)).deleteFundingAccount(anyString(), anyString());
    }

    @Test
    void missingInputFailsBeforeCallingFis() throws Exception {
        assertThat(launch(temporary.resolve("missing.psv"), temporary.resolve("out")).getStatus())
                .isEqualTo(BatchStatus.FAILED);
        verifyNoInteractions(fis);
    }

    @Test
    void existingOutputFailsWithoutOverwritingOrCallingFis() throws Exception {
        var input = temporary.resolve("input.psv");
        Files.writeString(input, "GIF000001|100000000001");
        var output = Files.createDirectory(temporary.resolve("existing"));
        var report = output.resolve("account-deletion-report.psv");
        Files.writeString(report, "existing report");
        assertThat(launch(input, output).getStatus()).isEqualTo(BatchStatus.FAILED);
        assertThat(Files.readString(report)).isEqualTo("existing report");
        verifyNoInteractions(fis);
    }

    private JobExecution launch(Path input, Path output) throws Exception {
        return launcher.run(accountDeletionJob, new JobParametersBuilder()
                .addString("inputFile", input.toString()).addString("outputDir", output.toString())
                .addString("runId", UUID.randomUUID().toString()).toJobParameters());
    }
}
