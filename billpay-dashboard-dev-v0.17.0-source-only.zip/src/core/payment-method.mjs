// User-approved reporting inference, not transaction-level remittance evidence.
export function paymentMethod(payee,customer){
 if(!customer?.isMember)return {method:'unknown',methodLabel:'Unknown',methodReason:'Customer ownership is unresolved',indicator:payee?.electronic||''};
 if(!payee)return {method:'unknown',methodLabel:'Unknown',methodReason:'No matching current payee relationship',indicator:''};
 if(payee.rows!==1||payee.conflicting)return {method:'unknown',methodLabel:'Unknown',methodReason:'Repeated or conflicting payee relationship',indicator:payee.electronic||''};
 const indicator=payee.electronic||'';
 if(!['N','Y'].includes(indicator))return {method:'unknown',methodLabel:'Unknown',methodReason:'Current payee indicator is missing or unsupported',indicator};
 return {method:indicator==='N'?'check':'electronic',methodLabel:indicator==='N'?'Inferred check':'Inferred electronic',methodReason:'Inferred from current payee Electronic Indicator; historical method may differ',indicator};
}
export function validatePaymentReview(request){
 for(const value of [request.dateFrom,request.dateTo])if(value){
  if(!/^\d{8}$/.test(value))throw Error('Choose a valid payment date.');
  const iso=value.slice(0,4)+'-'+value.slice(4,6)+'-'+value.slice(6),d=new Date(iso+'T00:00:00Z');
  if(!Number.isFinite(d.getTime())||d.toISOString().slice(0,10)!==iso)throw Error('Choose a valid payment date.');
 }
 if(request.dateFrom&&request.dateTo&&request.dateFrom>request.dateTo)throw Error('From date must be on or before Through date.');
 if(request.method&&!['check','electronic','unknown'].includes(request.method))throw Error('Unknown payment method filter.');
 if(request.activity&&!['reported','scheduled','history'].includes(request.activity))throw Error('Unknown payment activity filter.');
}
// Escape every cell; guard spreadsheet formulas without altering ordinary zero-prefixed IDs.
const cell=value=>'"'+String(value??'').replace(/^[=+@-]/,"'$&").replaceAll('"','""')+'"';
export const paymentCsvHeader=['CIF','Customer','Sponsor member ID','Payee','Payment ID','Record type','Date','Date basis','Amount (minor units)','Source status','Inferred method','Current payee indicator','Method evidence','Payee source file','Payee source line','Payment source file','Payment source line','Analysis date','Excluded customer profiles'].map(cell).join(',')+'\r\n';
export function paymentCsvRow(p,result){return [p.cifs.join(' | '),p.customer,p.member,p.payee,p.paymentId,p.kind,p.date,p.kind==='history'?'History process date':p.kind==='model'?'Model initial start date':'Scheduled process date',p.amount,p.status,p.methodLabel,p.indicator,p.methodReason,p.payeeSource?.file,p.payeeSource?.line,p.source.file,p.source.line,result.asOf,result.cohortExclusions?.customers||0].map(cell).join(',')+'\r\n';}
