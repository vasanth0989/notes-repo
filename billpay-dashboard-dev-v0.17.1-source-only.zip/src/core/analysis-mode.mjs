export const preLayouts=['member','consumer'];
export const unavailablePages=['Payees','Duplicate payees','Recurring payments','Payments'];
export function modeInputs(files,pre){
 if(!pre)return files;
 for(const id of preLayouts)if(!files.some(f=>f.layout===id))throw Error('Pre-deconversion analysis requires both Member and Consumer files.');
 return files.filter(f=>preLayouts.includes(f.layout));
}
export function applyAnalysisMode(result,pre,catalog){
 result.analysisMode=pre?'pre-deconversion':'full';
 if(!pre)return result;
 result.notAnalyzed=catalog.layouts.filter(l=>!preLayouts.includes(l.id)).map(l=>l.title);
 result.missing=catalog.layouts.filter(l=>preLayouts.includes(l.id)&&!result.files.some(f=>f.layout===l.id)).map(l=>l.title);
 result.partial=!!(result.missing.length||result.issueCount||result.metrics.unlinkedCustomerGroups);
 return result;
}
