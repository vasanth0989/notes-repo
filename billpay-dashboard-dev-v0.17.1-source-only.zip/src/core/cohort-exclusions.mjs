export function exclusionPlan(customers,requested,already=new Set()){
 const owners=new Map();for(const c of customers)for(const cif of c.cifs||[]){const keys=owners.get(cif)||new Set();keys.add(c.key);owners.set(cif,keys);}
 const keys=new Set(already),matched=[],notFound=[],ambiguous=[];
 for(const cif of requested){const found=owners.get(cif);if(!found){notFound.push(cif);continue;}if(found.size!==1){ambiguous.push(cif);continue;}matched.push(cif);keys.add([...found][0]);}
 const removed=customers.filter(c=>keys.has(c.key));
 return {keys,summary:{requested:requested.size,matched:matched.length,notFound:notFound.length,ambiguous:ambiguous.length,newCustomers:keys.size-already.size,totalCustomers:keys.size,remainingCustomers:customers.length-keys.size,removedCifs:[...new Set(removed.flatMap(c=>c.cifs||[]))],notFoundCifs:notFound,ambiguousCifs:ambiguous}};
}
export function cohortDriver(customers){return [...new Set(customers.flatMap(c=>c.cifs||[]))].join('\r\n')+(customers.some(c=>c.cifs?.length)?'\r\n':'');}
