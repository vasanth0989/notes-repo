export const unmatchedCriterion={code:'UNMATCHED',definition:'Exclude only CIFs belonging to UNMATCHED customers in the current delivery and present in Finacle. Other Finacle CIFs absent from the workbook are retained unless another exclusion applies.'};
// Builder counts are CIF sets, never sums of closure rows or customer buckets.
export const closureCriteria=[
 {key:'zero',label:'Matched · none remain'},
 {key:'remaining',label:'Matched · accounts remain'},
 {key:'unknown',label:'Matched · count unknown'},
 {key:'noMatch',label:'No match'},
 {key:'ambiguous',label:'Ambiguous CIF'}
];
export function closureOutcome(row){
 if(row.status==='No Match')return 'noMatch';
 if(row.status==='Ambiguous')return 'ambiguous';
 return row.post===null?'unknown':row.post===0?'zero':'remaining';
}
export function prepareDriverPreview(population,reference,closed,options={}){
 if(!reference)throw Error('Complete segmentation before building a driver file.');
 const segments=new Set(options.segments||[]),outcomes=new Set(options.outcomes||[]);
 const allowedSegments=new Set([...reference.assignments.values()].filter(a=>a.code&&!a.conflict).map(a=>a.code));
 for(const s of segments)if(s!=='UNMATCHED'&&!allowedSegments.has(s))throw Error('Selected segment is no longer available.');
 for(const s of outcomes)if(!closureCriteria.some(c=>c.key===s))throw Error('Unknown closed-account exclusion.');
 if(outcomes.size&&!closed)throw Error('Choose and analyze a closed-account file for these exclusions.');
 if(outcomes.size&&closed.summary.invalid)throw Error('Correct the invalid closed-account rows before applying closed-account exclusions.');
 const deliveryCustomers=options.customers||[];
 if(segments.has('UNMATCHED')&&!Array.isArray(options.customers))throw Error('Current delivery customers are required for UNMATCHED exclusion.');
 const unmatchedCustomers=deliveryCustomers.filter(c=>c.segment==='UNMATCHED');
 const unmatchedCifs=new Set(unmatchedCustomers.flatMap(c=>c.cifs||[]));
 const hitSegment=cif=>{const a=reference.assignments.get(cif);return (segments.has('UNMATCHED')&&unmatchedCifs.has(cif))||!!(a?.code&&!a.conflict&&segments.has(a.code));};
 const scope=new Set(population),closureSets=new Map(closureCriteria.map(c=>[c.key,new Set()]));
 for(const row of closed?.rows||[])closureSets.get(closureOutcome(row)).add(row.cif);
 const selectedClosed=new Set();for(const key of outcomes)for(const cif of closureSets.get(key))selectedClosed.add(cif);
 let bySegment=0,byClosed=0,overlap=0,unmatchedSegment=0,conflictedSegment=0,unresolvedRetained=0;
 const groups={segmentOnly:[],closedOnly:[],both:[]};
 const remaining=[],segmentCounts=new Map([...allowedSegments].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).map(code=>[code,0]));
 for(const cif of scope){
  const assignment=reference.assignments.get(cif),conflicted=!!assignment?.conflict;
  if(conflicted)conflictedSegment++;else if(!assignment?.code)unmatchedSegment++;else segmentCounts.set(assignment.code,segmentCounts.get(assignment.code)+1);
  const segmentHit=hitSegment(cif),closedHit=selectedClosed.has(cif);
  if(segmentHit&&closedHit)groups.both.push(cif);else if(segmentHit)groups.segmentOnly.push(cif);else if(closedHit)groups.closedOnly.push(cif);
  if(segmentHit)bySegment++;if(closedHit)byClosed++;if(segmentHit&&closedHit)overlap++;
  if(!segmentHit&&!closedHit){remaining.push(cif);if(conflicted||!assignment?.code)unresolvedRetained++;}
 }
 const unmatchedInDriver=[...unmatchedCifs].filter(cif=>scope.has(cif)).length;
 const unmatchedReconciliation={customers:unmatchedCustomers.length,uniqueCifs:unmatchedCifs.size,outsideDriver:unmatchedCifs.size-unmatchedInDriver,inDriver:unmatchedInDriver};
 const excluded=bySegment+byClosed-overlap;
 const selectedRows=(closed?.rows||[]).filter(row=>outcomes.has(closureOutcome(row)));
 const pairCounts=new Map();for(const row of selectedRows)pairCounts.set(row.cif,(pairCounts.get(row.cif)||0)+1);
 const selectedOutside=[...selectedClosed].filter(cif=>!scope.has(cif));
 const selectedInside=[...selectedClosed].filter(cif=>scope.has(cif));
 const sample=items=>items.values().next().value??null;
 const closedReconciliation={pairs:selectedRows.length,uniqueCifs:selectedClosed.size,extraPairs:selectedRows.length-selectedClosed.size,outsideDriver:selectedOutside.length,inDriver:byClosed,overlap,additional:byClosed-overlap,
 examples:{multipleAccounts:sample([...selectedClosed].filter(cif=>pairCounts.get(cif)>1)),outsideDriver:sample(selectedOutside),overlap:sample(selectedInside.filter(hitSegment)),closedOnly:sample(selectedInside.filter(cif=>!hitSegment(cif)))}};
 const segmentReconciliation=[...segmentCounts].map(([code,inDriver])=>{
  const customers=deliveryCustomers.filter(c=>c.segment===code);
  const overviewCifs=new Set(customers.flatMap(c=>c.cifs||[]));
  const workbookCifs=new Set([...reference.assignments].filter(([,a])=>!a.conflict&&a.code===code).map(([cif])=>cif));
  const both=[...overviewCifs].filter(cif=>scope.has(cif)&&workbookCifs.has(cif));
  const overviewOnly=[...overviewCifs].filter(cif=>!scope.has(cif));
  const builderOnly=[...workbookCifs].filter(cif=>scope.has(cif)&&!overviewCifs.has(cif));
  return {code,overviewCustomers:customers.length,overviewCifs:overviewCifs.size,overviewOnly:overviewOnly.length,both:both.length,builderOnly:builderOnly.length,inDriver,workbookCifs:workbookCifs.size,workbookOutsideDriver:[...workbookCifs].filter(cif=>!scope.has(cif)).length,
 examples:{overviewOnly:sample(overviewOnly),builderOnly:sample(builderOnly),both:sample(both)}};
 });
 return {remaining,groups,summary:{unmatchedReconciliation,closedReconciliation,segmentReconciliation,total:scope.size,excluded,retained:remaining.length,bySegment,byClosed,overlap,segmentOnly:bySegment-overlap,closedOnly:byClosed-overlap,unmatchedSegment,conflictedSegment,unresolvedRetained,
  segments:[...segmentCounts].map(([code,count])=>({code,count,definition:reference.definitions.get(code)||'Definition not supplied in workbook.'})).concat([{...unmatchedCriterion,count:unmatchedInDriver}]),
  closedCriteria:closureCriteria.map(c=>({...c,cifs:[...closureSets.get(c.key)].filter(cif=>scope.has(cif)).length,outsideDriver:[...closureSets.get(c.key)].filter(cif=>!scope.has(cif)).length})),
  selectedSegments:[...segments],selectedOutcomes:[...outcomes],closedSummary:closed?.summary||null}};
}
export function driverPopulation(preview,group='retained'){
 if(!['retained','segmentOnly','closedOnly','both'].includes(group))throw Error('Unknown driver export group.');
 return group==='retained'?preview.remaining:preview.groups[group];
}
export function driverText(preview,group='retained'){const cifs=driverPopulation(preview,group);return cifs.join('\r\n')+(cifs.length?'\r\n':'');}

// Bounded line reader. Reject malformed input rather than silently exporting a partial population.
export async function readDriverFile(file,onProgress=(_bytes=0,_total=0)=>{}){
 if(!file||typeof file.slice!=='function')throw Error('Choose a Finacle TXT file.');
 const cifs=new Set(),decoder=new TextDecoder('utf-8',{fatal:true});let pending='',rows=0,duplicates=0,line=0;
 const accept=text=>{
  line++;const cif=text.replace(/\r$/,'').trim();if(!cif)return;
  if(/^(CIF|BNK_CUST_NBR|SECURE[ _]LOGIN[ _]ID)$/i.test(cif))throw Error('Finacle file must contain one CIF per line, without a header (line '+line+').');
  if(!/^[A-Za-z0-9._@+\-]{1,64}$/.test(cif))throw Error('Invalid CIF format at line '+line+'. Use one identifier per line (up to 64 characters), without commas, quotes or spaces.');
  rows++;if(cifs.has(cif))duplicates++;else cifs.add(cif);
 };
 try{
  for(let offset=0;offset<file.size;offset+=1024*1024){
   const text=decoder.decode(await file.slice(offset,offset+1024*1024).arrayBuffer(),{stream:true});
   for(const piece of text.split(/(?<=\n)/)){
    pending+=piece;if(pending.length>1024)throw Error('Oversized line '+(line+1)+' in the Finacle file.');
    if(piece.endsWith('\n')){accept(pending.slice(0,-1));pending='';}
   }
   onProgress(Math.min(file.size,offset+1024*1024),file.size);
  }
  pending+=decoder.decode();if(pending)accept(pending);
 }catch(error){if(error instanceof TypeError)throw Error('Finacle file must be UTF-8 text.');throw error;}
 if(!cifs.size)throw Error('The Finacle file has no CIFs.');
 return {cifs,source:{name:file.name,rows,duplicates,unique:cifs.size}};
}
export function driverSegments(reference){
 const codes=new Set([...reference.assignments.values()].filter(a=>a.code&&!a.conflict).map(a=>a.code));
 return [...codes].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).map(code=>({code,definition:reference.definitions.get(code)||'Definition not supplied in workbook.'})).concat([unmatchedCriterion]);
}
