import {useEffect,useRef,useState} from 'react';

type Props={pre?:boolean;worker:Worker|null;customer:(key:string)=>void;account:(key:string,number:string)=>void};

export default function ClosedAccounts({worker,customer,account,pre=false}:Props){

 const [file,setFile]=useState<File|null>(null),[data,setData]=useState<any>({summary:null,rows:[],total:0,segments:[]}),[busy,setBusy]=useState(false),[error,setError]=useState(''),[exporting,setExporting]=useState(false),[progress,setProgress]=useState(0),[filters,setFilters]=useState<any>({}),[page,setPage]=useState(0),[loading,setLoading]=useState(false);

 const seq=useRef(0),instance=useRef(crypto.randomUUID());

 const ask=(type:string,more:any={})=>{const id=instance.current+':'+(++seq.current);worker?.postMessage({type,...filters,page,...more,closedId:id});return id;};

 useEffect(()=>{

  if(!worker)return;

  const handler=({data:d}:MessageEvent)=>{if(!d.closedId?.startsWith(instance.current+':'))return;

   if(d.type==='closed-progress'){setProgress(d.percent);return;}

   if(d.type==='closed-error'){setError(d.message);setBusy(false);setLoading(false);setExporting(false);return;}

   if(d.type==='export'){setExporting(false);return;}

   if(d.closedId!==instance.current+':'+seq.current)return;

   if(d.type==='closed-result'){setData(d);setBusy(false);setLoading(false);}

  };worker.addEventListener('message',handler);return()=>worker.removeEventListener('message',handler);

 },[worker]);

 useEffect(()=>{if(busy)return;setLoading(true);const timer=setTimeout(()=>ask('closed-page'),180);return()=>clearTimeout(timer);},[worker,filters,page,busy]);

 const change=(key:string,value:string)=>{setFilters((f:any)=>({...f,[key]:value||undefined}));setPage(0);};

 const s=data.summary;

 const buckets=s?[{label:'Matched · none remain',count:s.zero,color:'#b45c50',filter:'zero'},{label:'Matched · accounts remain',count:s.remaining,color:'#227d73',filter:'remaining'},{label:'Matched · count unknown',count:s.unknown,color:'#b58a3b',filter:'unknown'},{label:'No match',count:s.noMatch,color:'#7d8c9b',status:'No Match'},{label:'Ambiguous CIF',count:s.ambiguous,color:'#8b6bb1',status:'Ambiguous'}]:[];

 let accumulated=0;

 return <>

  <section className="card closed-import"><div className="eyebrow">DFS CLOSED ACCOUNTS · DELIVERY RECONCILIATION</div><h3>Which closed accounts are still in this delivery?</h3><p>Select a text file containing <b>account number,CIF</b>, one pair per line. Matching uses both identifiers exactly, including leading zeros.</p><label>Closed-account file <input type="file" accept=".txt,.csv" aria-label="Closed-account file" disabled={busy} onChange={e=>{setFile(e.target.files?.[0]||null);setError('');}}/></label><button className="button primary" disabled={!file||busy||!worker} onClick={()=>{setBusy(true);setError('');setProgress(0);setLoading(true);setData({summary:null,rows:[],total:0,segments:[]});setFilters({});setPage(0);ask('closed-analyze',{file,segment:undefined,status:undefined,post:undefined,query:'',page:0,sortDirection:undefined,payment:undefined});}}>Perform Analysis</button>{busy&&<p role="status">Reading closed-account file locally… {progress}%</p>}

  <p className="source-ref">Post Removal = distinct funding account numbers in this delivery minus all distinct matched accounts in this input. Duplicate input lines and repeated Consumer rows do not subtract twice. This is a what-if review, not an account deletion or unenrollment action.</p></section>

  {error&&<div role="alert" className="notice amber">{error}</div>}

  {s&&<><div className="context-bar"><strong>{s.name}</strong><span>{s.total.toLocaleString()} unique pairs · {s.matchedCustomers.toLocaleString()} matched customers · {s.zeroCustomers.toLocaleString()} customers with zero remaining</span></div>

  {(s.invalid>0||s.duplicates>0)&&<div className="notice amber">{s.duplicates} duplicate pairs counted once · {s.invalid} invalid rows excluded. Counts use valid matched input only.{s.issues.length>0&&<details><summary>Input issues</summary>{s.issues.map((v:any)=><p key={v.line}>Line {v.line}: {v.reason}</p>)}</details>}</div>}

  <section className="card segment-chart"><h3>Closed-account match outcomes</h3><p>Unique input pairs across the whole file. Click an outcome to filter the table.</p><div className="segment-chart-body"><div className="segment-ring"><svg viewBox="0 0 240 240" aria-label="Closed account outcomes"><circle cx="120" cy="120" r="88" stroke="#e8edeb" strokeWidth="32" fill="none"/>{buckets.map(b=>{const fraction=b.count/(s.total||1),offset=accumulated;accumulated+=fraction;return <circle key={b.label} cx="120" cy="120" r="88" fill="none" stroke={b.color} strokeWidth="32" pathLength="100" strokeDasharray={`${fraction*100} ${100-fraction*100}`} strokeDashoffset={-offset*100} transform="rotate(-90 120 120)" role="button" tabIndex={0} aria-label={b.label+': '+b.count} onClick={()=>{setFilters({...filters,status:b.status,post:b.filter});setPage(0);}} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();setFilters({...filters,status:b.status,post:b.filter});setPage(0);}}}><title>{b.label}: {b.count}</title></circle>;})}</svg><div className="segment-ring-label"><strong>{s.total.toLocaleString()}</strong><span>Unique input pairs</span></div></div><div className="segment-legend">{buckets.map(b=><button key={b.label} onClick={()=>{setFilters({...filters,status:b.status,post:b.filter});setPage(0);}}><i style={{background:b.color}}/><span>{b.label}</span><b>{b.count.toLocaleString()}</b><small>{(100*b.count/(s.total||1)).toFixed(1)}%</small></button>)}</div></div></section>

  <section hidden={pre} className="card"><h3>Payments on accounts proposed for closure</h3><p>Supplied one-time payments, recurring instances and recurring instructions are shown separately. Instructions without instances are included. History is not an active payment; no future occurrences or live status are inferred. None reported requires both payment files with no rejected rows or unresolved ownership. Counts are source rows, not deduplicated payment obligations.</p><div className="segment-legend">{Object.entries(s.paymentCounts||{}).map(([label,count]:any)=><button key={label} onClick={()=>change('payment',label)}><i style={{background:label==='Payments present'?'#b45c50':'#227d73'}}/><span>{label}</span><b>{count.toLocaleString()}</b><small>{(100*count/(s.total||1)).toFixed(1)}%</small></button>)}</div><p className="source-ref">Whole-file unique input pairs. Click an outcome to filter the table and export. “Payments present” flags closure review, not confirmation of live payment status.</p></section>

  <section className="card closed-results"><div className="panel-heading"><div><h3>Review funding account matches</h3><p>{data.total.toLocaleString()} pairs match the current filters · exports include every matching page</p></div><button className="button primary" disabled={busy||loading||exporting||!data.total} onClick={()=>{setError('');setExporting(true);ask('closed-export');}}>Export CIF + Account</button></div><div className="closed-filters"><label>Segment <select aria-label="Closed account segment" value={filters.segment||''} onChange={e=>change('segment',e.target.value)}><option value="">All segments</option>{[...new Set<string>(data.segments.filter((v:string)=>v.startsWith('SEGMENT ')).map((v:string)=>v.split('.')[0]))].map(g=><option key={g} value={'GROUP:'+g}>{g} · all subsegments</option>)}{data.segments.map((v:string)=><option key={v}>{v}</option>)}</select></label><label>Match <select aria-label="Closed account match" value={filters.status||''} onChange={e=>change('status',e.target.value)}><option value="">All outcomes</option>{['Matched','No Match','Ambiguous'].map(v=><option key={v}>{v}</option>)}</select></label><label>Post Removal <select aria-label="Post removal filter" value={filters.post||''} onChange={e=>change('post',e.target.value)}><option value="">All counts</option><option value="zero">Zero remaining</option><option value="remaining">One or more remain</option><option value="unknown">Unknown count</option></select></label><label hidden={pre}>Payment association <select aria-label="Payment association" value={filters.payment||''} onChange={e=>change('payment',e.target.value)}><option value="">All payment outcomes</option>{['Payments present','None reported','Review needed','Not matched'].map(v=><option key={v}>{v}</option>)}</select></label><label>Search <input aria-label="Search closed accounts" placeholder="CIF, customer or account" value={filters.query||''} onChange={e=>change('query',e.target.value)}/></label><button className="button secondary" onClick={()=>{setFilters({});setPage(0);}}>Reset filters</button></div><p className="source-ref">Export format: CIF,account number. No header; one unique pair per line. Select Zero remaining to review customers who may need unenrollment. These are candidates only; other eligibility checks are outside this analysis.</p>

  {loading?<p role="status">Filtering…</p>:<div className="table-scroll"><table><thead><tr>{['CIF','Customer','Segment','Account number','Match','Payments on this account','Funding accounts'].filter(h=>!pre||h!=='Payments on this account').map(h=><th key={h}>{h}</th>)}<th aria-sort={filters.sortDirection==='desc'?'descending':filters.sortDirection==='asc'?'ascending':'none'}><button className="column-sort" aria-label={'Post Removal: sort '+(filters.sortDirection==='asc'?'descending':'ascending')} onClick={()=>change('sortDirection',filters.sortDirection==='asc'?'desc':'asc')}>Post Removal {filters.sortDirection==='asc'?'↑':filters.sortDirection==='desc'?'↓':'↕'}</button></th></tr></thead><tbody>{data.rows.map((r:any)=><tr key={r.line} className={r.status==='Matched'?'closed-matched':''}><td>{r.cif}</td><td>{r.customerKey?<button className="record-link" onClick={()=>customer(r.customerKey)}>{r.customer}</button>:'NA'}</td><td>{r.segment}</td><td>{r.customerKey?<button className="record-link matched-account" onClick={()=>account(r.customerKey,r.account)}>{r.account}</button>:r.account}</td><td title={r.reason}>{r.status}<small className="source-ref">{r.reason}</small></td><td hidden={pre}><strong className={r.payments.state==='Payments present'?'zero-remaining':''}>{r.payments.state}</strong>{r.customerKey&&<small className="source-ref">{r.payments.single} one-time · {r.payments.instances} recurring instances · {r.payments.models} recurring instructions · {r.payments.history} history rows{r.payments.review?' · Coverage needs review':''}</small>}</td><td>{r.current??'—'}</td><td><strong className={r.post===0?'zero-remaining':''}>{r.post??'—'}</strong></td></tr>)}</tbody></table>{!data.total&&<div className="empty-state">No matching pairs. Adjust the filters.</div>}</div>}<div className="table-footer"><span>Page {page+1} · up to 100 pairs per page</span><div><button className="button secondary" disabled={busy||loading||page===0} onClick={()=>setPage(p=>p-1)}>Previous</button><button className="button secondary" disabled={busy||loading||(page+1)*100>=data.total} onClick={()=>setPage(p=>p+1)}>Next</button></div></div></section></>}

 </>;

}

