import test from 'node:test';
import assert from 'node:assert/strict';
import {modeInputs,applyAnalysisMode} from '../src/core/analysis-mode.mjs';
const catalog={layouts:[{id:'member',title:'Member'},{id:'consumer',title:'Consumer'},{id:'payee',title:'Payee'}]};
const result=()=>({files:[{layout:'member'},{layout:'consumer'}],missing:['Payee'],partial:true,issueCount:0,metrics:{unlinkedCustomerGroups:0}});
test('pre-deconversion requires both core files and ignores other selected files; full mode is unchanged',()=>{
 const files=[{layout:'member'},{layout:'consumer'},{layout:'payee'},{layout:''}];
 assert.deepEqual(modeInputs(files,true),files.slice(0,2));assert.equal(modeInputs(files,false),files);
 assert.throws(()=>modeInputs(files.slice(0,1),true),/both Member and Consumer/);
});
test('pre-deconversion coverage is complete only for its declared scope and retains errors',()=>{
 const r=applyAnalysisMode(result(),true,catalog);assert.deepEqual(r.missing,[]);assert.deepEqual(r.notAnalyzed,['Payee']);assert.equal(r.partial,false);assert.equal(r.analysisMode,'pre-deconversion');
 for(const change of [{issueCount:1},{metrics:{unlinkedCustomerGroups:1}},{files:[{layout:'member'}]}])assert.equal(applyAnalysisMode({...result(),...change},true,catalog).partial,true);
 const full=applyAnalysisMode(result(),false,catalog);assert.deepEqual(full.missing,['Payee']);assert.equal(full.partial,true);assert.equal(full.analysisMode,'full');
});
