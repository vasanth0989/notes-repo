import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {analyzeFiles} from '../src/core/stream.mjs';
import {pagePayments} from '../src/core/explore.mjs';
import {paymentMethod,paymentCsvHeader,paymentCsvRow,validatePaymentReview} from '../src/core/payment-method.mjs';
const catalog=JSON.parse(fs.readFileSync(new URL('../src/layouts.json',import.meta.url)));
const base={'Sponsor ID':'S','Sponsor Id':'S','Sponsor Member ID':'0001','Sponsor member id':'0001','Sponsor Member id':'0001','Member ID':'00001','Secure login ID':'000001','First Name':'TEST','Last Name':'PERSON','Last Name/Business Name':'PERSON','Payee Relationship Number':'0001','Payee Name':'UTILITY','Electronic Indicator':'N','Payee Account Number':'00009876','FI Account Number':'00001234','FI R&T':'000000001','FI Account Reference Number':'0007','FI Account Type':'DDA','Primary Account Indicator':'Y','Payment Amount':'12345','Payment Schedule Date':'20261101','Payment Date':'20261101','Payment Status':'1','Payment Frequency':'000004','Recurring / Single Payment Identifier':'','FIS Recurring Rule DB':'000009'};
const row=(id,r)=>catalog.layouts.find(l=>l.id===id).fields.map(f=>String(r[f.name]??'').padEnd(f.length)).join('');
const file=(id,records)=>({layout:id,file:new File([records.map(r=>row(id,{...base,...r})).join('\r\n')],id+'.TXT')});
const fixtures=()=>[file('member',[{}]),file('consumer',[{}]),file('payee',[{}, {'Payee Relationship Number':'0002','Electronic Indicator':'Y'}]),file('single_payments',[{}, {'Payment Schedule Date':'20261031'},{'Payee Relationship Number':'0002','Payment Status':'50'},{'Payee Relationship Number':'9999'},{'Payment Schedule Date':'20261103'}]),file('recurring_payments',[{}, {'Recurring / Single Payment Identifier':'1'}]),file('payment_history',[{'Payment Status':'STOPPED'}])];
test('method inference requires one linked current payee; N/Y/unknown remain evidence not history truth',()=>{
 assert.equal(paymentMethod({rows:1,electronic:'N'},{isMember:true}).method,'check');
 assert.equal(paymentMethod({rows:1,electronic:'Y'},{isMember:true}).method,'electronic');
 for(const p of [undefined,{rows:2,electronic:'N'},{rows:1,conflicting:true,electronic:'N'},{rows:1,electronic:'EN'}])assert.equal(paymentMethod(p,{isMember:true}).method,'unknown');
 assert.equal(paymentMethod({rows:1,electronic:'N'},{isMember:false}).method,'unknown');
});
test('inclusive date/activity/method filters separate history from scheduled and exclude templates from review',async()=>{
 const files=fixtures(),r=await analyzeFiles(files,catalog,'20261110',true);
 const request={dateFrom:'20261101',dateTo:'20261101',activity:'reported'};
 const all=await pagePayments(files,catalog,r,request);
 assert.equal(all.total,5);assert.equal(all.review.history.count,1);assert.equal(all.review.scheduled.count,4);
 assert.equal(all.review.check.count,3);assert.equal(all.review.electronic.count,1);assert.equal(all.review.unknown.count,1);
 assert.equal(all.review.check.amount,'37035');assert.equal(all.modelAmount,'0');
 const checks=await pagePayments(files,catalog,r,{...request,method:'check',activity:'history'});
 assert.equal(checks.total,1);assert.equal(checks.rows[0].status,'STOPPED');assert.equal(checks.rows[0].methodLabel,'Inferred check');assert.equal(checks.rows[0].payeeSource.line,1);
 assert.ok(paymentCsvRow(checks.rows[0],r).includes('"00001234","0007","Candidate match"')); 
 assert.equal((await pagePayments(files,catalog,r,{...request,method:'electronic',query:'000001'})).total,1);
 assert.equal((await pagePayments(files,catalog,r,{...request,customerKey:'other'})).total,0);
 const models=await pagePayments(files,catalog,r,{filter:'model'});assert.equal(models.total,1);assert.equal(models.review.check.count,0);
});
test('report export callback covers every page, preserves IDs/status/evidence and uses identical filters',async()=>{
 const files=[file('member',[{}]),file('payee',[{}]),file('single_payments',Array.from({length:125},(_,i)=>({'Payment ID':String(i).padStart(12,'0')})))];
 const r=await analyzeFiles(files,catalog,'20261110',true),exported=[];
 const page=await pagePayments(files,catalog,r,{method:'check',activity:'scheduled'});
 const total=await pagePayments(files,catalog,r,{method:'check',activity:'scheduled'},undefined,p=>exported.push(paymentCsvRow(p,r)));
 assert.equal(page.rows.length,100);assert.equal(total.total,125);assert.equal(exported.length,125);assert.equal(total.rows.length,0);
 assert.ok(paymentCsvHeader.includes('"Funding account number","Funding account reference","Funding mapping"'));
 assert.ok(exported.every(line=>line.includes('"00001234","0007",')));
 assert.ok(exported[0].includes('"000001"'));assert.ok(exported[0].includes('"000000000000"'));assert.ok(exported[0].includes('Inferred check'));assert.ok(exported[0].endsWith('\r\n'));
 r._excludedCustomerKeys=new Set([r.customers[0].key]);assert.equal((await pagePayments(files,catalog,r,{method:'check'})).total,0);
});
test('invalid dates/ranges and unsupported filters fail; CSV escapes quotes and spreadsheet formula starts',()=>{
 for(const req of [{dateFrom:'20260230'},{dateFrom:'2026-11-01'},{dateFrom:'20261103',dateTo:'20261101'},{method:'wire'},{activity:'settled'}])assert.throws(()=>validatePaymentReview(req));
 validatePaymentReview({dateFrom:'20261101',dateTo:'20261101'});
 const csv=paymentCsvRow({cifs:['0001'],customer:'=1+1',payee:'A "B"',source:{file:'test',line:1}},{asOf:'20261110'});
 assert.ok(csv.includes('"\'=1+1"'));assert.ok(csv.includes('"A ""B"""'));
});
