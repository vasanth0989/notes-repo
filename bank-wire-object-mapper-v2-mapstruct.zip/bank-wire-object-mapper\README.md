# bank-wire-object-mapper

Maps the Payment Exchange payment object (`SDPPayload`) for an outbound GPN or corporate wire to an
ISO 20022 **pain.001.001.11** customer credit transfer initiation, as schema-valid XML. Used inside
Wire Rail II, which receives the payment from the PayX integration service after OFAC, converts it with
this library, detokenises the account numbers, calls the FIS OPF API and returns OPF's HTTP code.

The XML is the Phase 2 asset: what Capital One will send to the banks directly once OPF is gone. For
Phase 1 the same mapped data is rendered as the FIS JSON (pain.001.001.11 inside a business application
header) by Wire Rail II; that rendering is a placeholder here, see "What is not in this library".

Java 21, Gradle, MapStruct, Jakarta XML Binding. No Spring: the library is plain Java and is wired into
a Spring service as one bean (`new Pain001V11Mapper(context)`).

## Where the mapping is

The whole mapping is declared in one MapStruct interface, in the same style as the SWIFT mapper
(`bank-swift-object-mapper`):

```
src/main/java/com/capitalone/bank/wire/object/mapper/mappers/WireCreditTransferPain001V11.java
```

It reads top-down in message order, one method per ISO block: `Document`, `CstmrCdtTrfInitn`, `GrpHdr`,
`PmtInf`, `CdtTrfTxInf` (with `PmtId` and `PmtTpInf`), then the reusable types (party, postal address,
agent, financial institution, cash account). Every line names an ISO element and the payment-object
field it comes from:

```java
@Mapping(target = "pmtInfId", source = "clientTransactionId")
@Mapping(target = "pmtMtd", constant = "TRF")
@Mapping(target = "reqdExctnDt.dt", source = "valueDate", qualifiedByName = "valueDate")
@Mapping(target = "dbtr", source = "payer", qualifiedByName = "toParty")
@Mapping(target = "dbtrAcct", source = "payer", qualifiedByName = "toDebtorAccount")
@Mapping(target = "dbtrAgt", source = ".", qualifiedByName = "debtorAgent")
PaymentInstruction40 toPaymentInformation(SDPPayload payload, @Context MappingContext context);
```

- A plain `source` is a direct copy (trimmed; a blank value is never written).
- `constant` is a fixed value.
- `qualifiedByName` names a rule. A line with `source = "."` is derived from more than one field.
- An ISO element with no line is not written.

The rules are the `@Named` methods lower in the same interface. Each is a choice, a code translation or
a derived value and delegates to `util/WireMapperCommon`; single-value qualifiers (BIC, LEI, country,
currency, dates, UETR) are in `util/WireQualifierUtil`. MapStruct generates the implementation at
compile time (`build/generated/sources/annotationProcessor/.../WireCreditTransferPain001V11Impl.java`),
so what runs is ordinary Java that can be read and debugged.

## Build and run

```bash
./gradlew build            # generates the V11 classes from the XSD and the MapStruct implementation, runs the tests
./gradlew renderSamples    # maps every sample payment object to XML in build/samples and validates it
./gradlew renderSamples -Psample=gpn-usd-wire
./gradlew publishToMavenLocal
```

On the Capital One network put these in `~/.gradle/gradle.properties` (never in the repository):

```
artifactoryUrl=https://artifactory.cloud.capitalone.com/artifactory/<virtual-repo>
artifactoryUser=<EID>
artifactoryToken=<token>
payxPayloadVersion=2.16-beta
```

`payxPayloadVersion` switches the payment object dependency to the real library
`com.capitalone.commercial:payx-payload` (2.16-beta, the version the Wire II integration service uses,
with its `jackson-databind` excluded as that service does). Without it the build uses
`payx-payload-local`, a stand-in written from the field lists of the 2.16-beta sources, with the same
package, class, field and accessor names (`com.capitalone.commercial.payx.sdp.payload.model`), limited
to the fields a wire uses. The library therefore builds and tests off the network, and code that
compiles against the stand-in compiles against the real jar. The module can be deleted once every build
uses the real artifact; nothing else references it.

Payload 2.16-beta has no `countryOfResidence`, `issuer`, `debtorAgentAccount`, `creditorAgentAccount` or
`tertiaryIntermediaryBank`, so the mapper does not write `CtryOfRes`, `Issr`, `DbtrAgtAcct` or
`IntrmyAgt3`, and takes `CdtrAgtAcct` from `payeeBank.bankAccountNumber`. Each is one more `@Mapping`
line once the payload library carries the field. Two spellings to know in that version: the country of
birth is `customerPersonalInfo.countryofbirth` (lower case), and `Account` carries an
`accountHolderFullName`, which the mapper uses when `accountName` is blank.

A JDK 21 is used through the Gradle toolchain; if none is installed, the Foojay resolver downloads one.

## Using it

```java
var context = new MappingContext(
        new MappingContext.InitiatingParty("Discover Bank", null, "US"),
        null,                                     // fixed debtor agent, used only when payerBank is absent
        null,                                     // initiation source (off by default)
        MappingContext.FisExtension.defaults(),   // instMethod, templateName, accountType, waiveFees
        Clock.systemUTC(),
        MappingRules.defaults());
var mapper = new Pain001V11Mapper(context);

String xml = mapper.mapToXml(payload);        // schema-validated pain.001.001.11
Document document = mapper.map(payload);      // the JAXB tree, for the JSON rendering in Wire Rail II
```

`Pain001V11Mapper` is the entry point. It validates the payment object, then calls the MapStruct mapper.
A payment that cannot be mapped throws `MappingException`. Its `problems()` list every reason at once,
each with the payment-object path that caused it (`payload.payee.accountNumber: is required`). Messages
never contain field values, so they are safe to log; the library itself logs nothing.

## How the payment object becomes pain.001

1. **Receive and validate** (`PayloadPreconditions`). Everything the schema makes mandatory and every
   length or format it enforces is checked against the payment object first: a message id of at most 35
   characters, a UETR that is a UUID v4, a value date in `yyyy-MM-dd`, a positive amount with an ISO
   currency, a payer and a payee each with an account number and a name, and the lengths and formats of
   every party, bank and address field. Any miss rejects the payment with the full list of reasons before
   anything is built.
2. **Group header.** Message id from `clientTransactionId`; creation time now, UTC, milliseconds; one
   transaction; control sum equal to the amount written; initiating party from the payment object when it
   has a name, otherwise the fixed party from the context.
3. **Payment information (debit side).** Payment information id from `clientTransactionId`; method TRF;
   no batch booking; requested execution date from `valueDate` as a date only; debtor from `payer`;
   debtor account from `payer`; debtor agent from `payerBank` as received.
4. **Credit transfer transaction (credit side).** Instruction id from `instructionId` and end-to-end id
   from `endToEndId`, each falling back to `clientTransactionId`; UETR from
   `swiftEndToEndTransactionReference`; priority HIGH; local instrument from `paymentTypeCode` converted
   to the ISO code; service level and category purpose when present; the amount; charge bearer from
   `chargedTo`; ultimate debtor from `ultimateDebtor`; two intermediary agents with their accounts;
   creditor agent from `payeeBank` as received, with its account; creditor and creditor account from
   `payee`; ultimate creditor; `bankToBank` as instructions for the creditor agent; purpose from
   `transactionReasonCd`; remittance information; the two FIS supplements.
5. **Amount and FX.** No `exchangeRate`: `InstdAmt` is `transactionAmount` in `currencyCode`. With a
   foreign currency and no debit amount: `InstdAmt` is `exchangeRate.instructedAmount` in the foreign
   currency. With both: `EqvtAmt` (the debit amount plus the currency of transfer) by default, or
   `InstdAmt` in the foreign currency when the rule says so. Rate, rate type (SPOT, SALE, AGRD) and
   contract id go to `XchgRateInf`. Amounts are rounded half-up to the currency's minor unit.
6. **XML.** The document is marshalled with JAXB and validated against `pain.001.001.11.xsd`, which is
   shipped inside the jar. The JSON rendering for FIS is the next step, in Wire Rail II.

## Mapping summary

The interface is the authority; this table is the same content for readers without the code open.

| pain.001.001.11 | Source in the payment object | Rule |
|---|---|---|
| GrpHdr/MsgId | clientTransactionId | copy |
| GrpHdr/CreDtTm | clock | UTC, milliseconds |
| GrpHdr/NbOfTxs, PmtInf/NbOfTxs | constant | 1 |
| GrpHdr/CtrlSum, PmtInf/CtrlSum | the amount written | equals InstdAmt or EqvtAmt/Amt |
| GrpHdr/InitgPty | initiatingParty, else context | party rule |
| GrpHdr/InitnSrc | context | off by default (not in the FIS samples) |
| PmtInf/PmtInfId | clientTransactionId | copy |
| PmtInf/PmtMtd, BtchBookg | constants | TRF, false |
| PmtInf/ReqdExctnDt/Dt | valueDate | strict yyyy-MM-dd, date only |
| PmtInf/Dbtr | payer | party rule |
| PmtInf/DbtrAcct | payer | IBAN when accountIdType is IBAN; else Othr/Id with no scheme; Tp/Cd from accountIdType (DDA to CACC, savings to SVGS, else OTHR); Ccy only when the account carries a currency |
| PmtInf/DbtrAgt | payerBank | agent rule, as received; when absent, the fixed agent of the context if configured, else an empty FinInstnId (the schema requires the element) |
| CdtTrfTxInf/PmtId/InstrId | instructionId, else clientTransactionId | copy |
| CdtTrfTxInf/PmtId/EndToEndId | endToEndId, else clientTransactionId | copy |
| CdtTrfTxInf/PmtId/UETR | swiftEndToEndTransactionReference | lower-case UUID v4 |
| CdtTrfTxInf/PmtTpInf/InstrPrty | constant | HIGH |
| CdtTrfTxInf/PmtTpInf/LclInstrm | paymentTypeCode | BTRC to BTR, CTRC to CTR; BTR, CTR, DRC pass through; written as Cd |
| CdtTrfTxInf/PmtTpInf/SvcLvl, CtgyPurp | serviceLevelCd, categoryPurpose | ISO external code to Cd, otherwise Prtry |
| CdtTrfTxInf/Amt, XchgRateInf | transactionAmount, currencyCode, exchangeRate | see "Amount and FX" |
| CdtTrfTxInf/ChrgBr | chargedTo | as received: DEBT, CRED, SHAR, SLEV and the usual words for them; not written when absent; unknown rejected |
| CdtTrfTxInf/UltmtDbtr | ultimateDebtor | party rule |
| CdtTrfTxInf/IntrmyAgt1, IntrmyAgt2 (+Acct) | firstIntermediaryBank, secondaryIntermediaryBank | agent rule; account from bankAccountNumber |
| CdtTrfTxInf/CdtrAgt (+Acct) | payeeBank | agent rule, as received; omitted when absent; account from bankAccountNumber |
| CdtTrfTxInf/Cdtr | payee | party rule |
| CdtTrfTxInf/CdtrAcct | payee | IBAN, or Othr/Id with SchmeNm/Prtry "Proprietary" and no type; Ccy only when the account carries a currency |
| CdtTrfTxInf/UltmtCdtr | ultimateCreditor | party rule |
| CdtTrfTxInf/InstrForCdtrAgt | bankToBank | one InstrInf per line, each split at 140 |
| CdtTrfTxInf/Purp | transactionReasonCd | ISO external code to Cd, otherwise Prtry |
| CdtTrfTxInf/RmtInf/Ustrd | remitterInfo.unstructuredInfo | one per line; split at 140 by default |
| CdtTrfTxInf/RmtInf/Strd/Invcr, Invcee | remitterInfo.invoicerIdentification, invoiceeIdentification | Id/OrgId/Othr/Id |
| CdtTrfTxInf/SplmtryData | clientTransactionId | FIS transaction supplement: transactionTraceIdentification |
| CstmrCdtTrfInitn/SplmtryData | clientTransactionId, context | FIS payment information supplement: receipt and trace identification, extension block |

Reusable types:

| Type | Mapping |
|---|---|
| Party (Dbtr, Cdtr, UltmtDbtr, UltmtCdtr, InitgPty) | Nm from accountName, else accountHolderFullName, else the name parts; PstlAdr from address; Id as OrgId (organisation id number, LEI, BIC) or else PrvtId (identification number, date and place of birth), never both |
| Postal address | department, subDepartment, streetName, buildingNumber, buildingName, floor, postalBox, room, postalCode, city or townName, townLocationName, districtName, stateCode or stateProvince, countryCode; addressLine1 to 4 as AdrLine; an address with no values is not written |
| Agent | BICFI from swiftBankIdentifierCode; ClrSysMmbId from bankCode with bankSystemIdentifier (a nine-digit code without one is USABA); LEI; Nm from bankName; PstlAdr from address |

Text rules everywhere: values are trimmed and blank values skipped; Max35Text identifiers, Max140Text
names and lines, Max70Text street names and address lines, Max16Text building numbers and post codes,
Max34Text account ids; over length is rejected by the validation step unless a policy says truncate or
split. Country codes are two letters upper case, BICs 8 or 11 characters, LEIs 20.

## The rules (`MappingRules`)

A rule exists only where a decision is still open with FIS or may differ per deployment.

| Rule | Default | Alternatives |
|---|---|---|
| identifiers.uetrRequired | true | false |
| parties.addressStyle | STRUCTURED_AND_LINES | STRUCTURED_ONLY, LINES_ONLY |
| parties.namePolicy | REJECT over 140 | TRUNCATE |
| accounts.debtorScheme, debtorType | NONE, FROM_ACCOUNT_ID_TYPE (FIS samples) | BBAN or PROPRIETARY; CACC, NONE or PROPRIETARY_RAW |
| accounts.creditorScheme, creditorType | PROPRIETARY, NONE (FIS samples) | same |
| codes.localInstrumentStyle | EXTERNAL_CODE | PROPRIETARY |
| codes.chargeBearerPolicy | REJECT unknown | OMIT |
| codes.rateTypePolicy | REJECT unknown | OMIT |
| codes.inferUsabaFromNineDigitBankCode | true | false |
| amounts.fxAmountStyle | EQUIVALENT_AMOUNT | INSTRUCTED_AMOUNT_ONLY |
| texts.remittancePolicy | SPLIT | TRUNCATE, REJECT |
| texts.bankToBankSlashCleanup | false | true (TMOBS, TMOBSDOM, OBS senders: slashes become spaces) |
| header.emitInitiationSource | false | true |
| supplements.emitFisSupplements | true | false |

## The FIS sample requests

FIS provided four sample requests (bank transfer, customer transfer, customer transfer with an
intermediary agent, and a drawdown with structured and hybrid addresses and structured remittance). They
are bundled under `src/main/resources/samples/fis`, and each is rebuilt from a payment object under
`src/test/resources/samples/sdp/fis-*.json`; `FisSampleEquivalenceTest` checks the mapped message
against the FIS JSON value by value. What the samples settled:

- The payment type (BTR, CTR, DRC) is `localInstrument.code`, not proprietary.
- The debtor account is `other.identification` with no scheme and a `type.code` (OTHR or CACC); the
  creditor account is `other.identification` with `schemeName.proprietary: "Proprietary"` and no type.
  Neither carries a currency.
- The debtor agent is a BIC or a USABA member id; the intermediary agent is a USABA member id with no
  account; agents may carry a structured address and no name.
- Addresses are either address lines only or fully structured plus address lines; both pass.
- Remittance and instructions for the creditor agent repeat as arrays of short lines.
- Every request carries the two FIS supplements with the message id as trace id and an extension block
  (internationalPayment, instMethod, templateName, accountType, waiveFees).
- The samples carry no UETR and the drawdown carries no end-to-end id; the mapper writes the UETR and
  falls back to the message id for the end-to-end id, which the schema allows.
- The business application header (sender PaymentSystemId and CoreBankIdentifier, receiver OPF with an
  endPointName, market practice "FIS EP Universal Execution, 2022 Edition 3, SuppressCallBack:Test") is
  JSON-level and belongs to Wire Rail II.

Not reproduced because the payment object has no source for them: the garnishment block of the
structured remittance, and the names and addresses of the invoicer and invoicee (only their
identifications are mapped).

## What is not in this library, and why

- **FIS JSON rendering.** `Pain001V11JsonRenderer.toFisJson` is a placeholder that throws. The FIS
  Universal Execution JSON is the FIS contract's shape (ISO long names, amount objects, the business
  application header), not a generic XML-to-JSON conversion; it is built in Wire Rail II from the
  contract models. The FIS samples are bundled so the target shape travels with the mapping; the
  supplements are already in the XML, so the rendering only copies them.
- **Detokenisation.** Account numbers arrive tokenised; Wire Rail II detokenises them through Turing.
  The mapper copies what it is given.
- **On-behalf-of payer.** In the existing PIE flow `onBehalfOfPayer` feeds the debtor agent. That is
  specific to PIE and is not expected on Discover's wires, so it is not mapped.
- **PIE supplementary data.** The V9 converter wrote a PIE-specific client-data envelope (FX debit
  currency and amount, initiator, approver). OPF does not read it; it is not written.
- **Garnishment and referred documents.** No source in the payment object.
- **Address standardisation.** The V9 converter called the ACE address service for one channel and
  payment type and blanked structured agent addresses as a PIE work-around. Neither is carried over.
- **Correspondent and instructing agents, clearing references, message format.** They belong to the
  clearing leg (pacs.008), not to pain.001.
- **Payment status, returns, ACH, card, RTP and letter fields** of the payment object are not read.

## Mapping decisions

Settled in the mapping review and implemented:

1. **Local instrument.** Payment Exchange issues BTRC and CTRC; BKP and NOS are not possible through the
   external API. BTR, CTR and DRC are ISO external local instrument codes, so the conversion from the
   Payment Exchange code to the ISO code is done in this layer.
2. **Agents.** The wire layer adds no agent of its own. An ordinary outbound wire carries a creditor
   agent and no debtor agent; a drawdown carries a debtor agent and no creditor agent. Whatever the
   payment object carries is mapped.
3. **Charge bearer and rate type.** Mapped from the payment object as received; nothing is hard-coded or
   defaulted.
4. **Names.** A name over 140 characters is already rejected by the external API; the mapper rejects
   too and never truncates by default.
5. **Ultimate debtor.** Mapped from `ultimateDebtor` only; there is no precedence with
   `onBehalfOfPayer`, which is not mapped.

## Open questions

### Mapping decisions still open

1. The Payment Exchange payment type code for a drawdown is not defined yet; DRC is expected.
2. Account type: the FIS samples carry `Tp/Cd` (CACC, OTHR), while existing PIE messages carry the
   account id type as `Tp/Prtry` (DDA, IBAN). The default follows the FIS samples; the proprietary form
   is one rule away.
3. Which payment-object fields carry the message id, payment information id, instruction id and
   end-to-end id for GPN and corporate wires, and who generates them.
4. Whether `onBehalfOfPayer` can occur on Discover's wires at all.
5. How the debtor and creditor agents arrive for a drawdown, and whether an empty debtor agent on an
   ordinary wire is acceptable to OPF.
6. The exact `chargedTo` values the channels send; the mapper accepts the ISO codes and the words
   originator, beneficiary and shared.

### Questions for FIS

7. Does OPF accept `EqvtAmt` for FX wires, or only `InstdAmt`?
8. Which address form does OPF require per rail (structured, hybrid, address lines), and does it reject
   structured fields combined with address lines?
9. Is `InstrForCdtrAgt/InstrInf` the right carrier for bank-to-bank text, and what chunking and line
   markers does OPF expect?
10. Does OPF require a BIC for GPN agents? (The clearing system codes themselves come from the ISO
    external code list.)
11. Does OPF read `InitnSrc` or any supplementary data beyond its own two envelopes?
12. Which V11 elements survive OPF's conversion to pain.001 V3 for the correspondent banks? This goes
    hand in hand with the address question.
13. Does OPF keep the UETR Capital One sends all the way to the network? V3 carries the end-to-end id
    rather than a UETR, and the samples carry none.
14. The extension block of the payment information supplement: what do instMethod ("Person"),
    accountType ("Consumer", "consumer"), templateName and waiveFees mean for Discover's wires, and which
    values does OPF expect from Capital One?
15. The creditor account scheme "Proprietary" and the debtor account type OTHR versus CACC: are these
    validated, and does OPF accept ISO codes instead?
16. Drawdown requests (DRC): the sample has no end-to-end id; is one required for Discover?
17. The invoicee address in the drawdown sample uses "stateOrProvince", which is not in the API
    specification; it looks like an older sample, with `countrySubDivision` the intended element.

Whether service level, category purpose, purpose, regulatory reporting and the date precision of the
requested execution date are required is answered by the API specification and needs no question.

## Samples and tests

`src/test/resources/samples/sdp` holds nine payment objects:

| Sample | What it covers |
|---|---|
| fis-bank-transfer | the FIS bank transfer sample (BTR): BIC debtor agent, OTHR account type, two remittance lines, two instructions |
| fis-customer-transfer | the FIS customer transfer sample (CTR): USABA agents, CACC debtor account |
| fis-intermediary-customer-transfer | the FIS customer transfer with intermediary sample (CTR): BIC debtor agent, USABA intermediary agent 1 without an account, two remittance lines, two instructions |
| fis-drawdown-structured | the FIS drawdown sample (DRC): structured and hybrid addresses on every party and agent, ultimate parties, intermediary agent, invoicer and invoicee |
| gpn-usd-wire | domestic USD wire with the Payment Exchange code CTRC, USABA agents, organisation id, category purpose, remittance, long bank-to-bank text |
| corp-fx-eur-wire | USD-to-EUR wire with equivalent amount and exchange rate, LEI, BIC agents, IBAN creditor, intermediary agent, address lines, remittance split |
| corp-on-behalf-of-wire | composed personal name, private identification with date and place of birth, creditor agent account, ultimate creditor, an on-behalf-of party that is not mapped |
| fx-instructed-amount-only | FX wire with no debit amount: instructed amount in JPY rounded to no decimals, BIC-only agents |
| invalid-missing-required-fields | rejected with seven reasons at once |

`src/test/resources/golden` holds the XML of the eight valid samples with a fixed creation time; the
golden test compares the full output. After a deliberate mapping change, regenerate them with
`./gradlew renderSamples -Pclock=fixed` and copy `build/samples/*.xml` over after reviewing the diff.

## Layout

```
build.gradle, settings.gradle          Gradle 9, Java 21 toolchain, XSD code generation, MapStruct, renderSamples task
payx-payload-local/                    stand-in for the payment object library (off-network builds only)
src/main/resources/xsd/                pain.001.001.11.xsd (also shipped in the jar for validation)
src/main/resources/samples/fis/        the four FIS sample requests, the example from the FIS contract, and the request used for the Code Connect connectivity test
src/main/java/com/capitalone/bank/wire/object/mapper/
  mappers/                             WireCreditTransferPain001V11: the MapStruct mapping, all in one interface
  util/                                WireQualifierUtil (value qualifiers), WireMapperCommon (choices, code tables, amounts, supplements)
  pain001/v11/                         Pain001V11Mapper (entry point), MappingContext, MappingRules,
                                       PayloadPreconditions (validation), Pain001V11Marshaller
  pain001/v11/json/                    Pain001V11JsonRenderer (placeholder)
  common/                              Text, IsoDates, Amounts, MappingException, MappingProblem, Problems
  generated/pain001v11/                generated at build time from the XSD (not in the repository)
src/test/                              tests, sample payment objects, golden XML, SampleRenderer
docs/                                  payment object inventory, field mapping analysis, V11 element tree
```
