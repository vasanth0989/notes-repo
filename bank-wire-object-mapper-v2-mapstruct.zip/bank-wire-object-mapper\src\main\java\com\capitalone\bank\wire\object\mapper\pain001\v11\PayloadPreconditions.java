package com.capitalone.bank.wire.object.mapper.pain001.v11;

import static com.capitalone.bank.wire.object.mapper.common.Text.hasText;
import static com.capitalone.bank.wire.object.mapper.common.Text.isBlank;

import com.capitalone.bank.wire.object.mapper.common.Amounts;
import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Problems;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.LongTextPolicy;
import com.capitalone.commercial.payx.sdp.payload.model.Account;
import com.capitalone.commercial.payx.sdp.payload.model.Address;
import com.capitalone.commercial.payx.sdp.payload.model.Bank;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * The "receive and validate" step, run before the mapping: everything pain.001.001.11 makes mandatory
 * and every length or format the schema enforces, checked against the payment object so that a payment
 * is rejected with the complete list of reasons, each naming the payment-object field. The mapping that
 * follows can then be a plain declaration of which field goes where.
 */
final class PayloadPreconditions {

    private PayloadPreconditions() {
    }

    static Problems check(SDPPayload payload, MappingContext context) {
        var rules = context.rules();
        var problems = new Problems();

        identifier(problems, payload.getClientTransactionId(), "payload.clientTransactionId",
                "GrpHdr/MsgId, PmtInf/PmtInfId");
        max(problems, payload.getInstructionId(), Text.MAX_35, "payload.instructionId");
        max(problems, payload.getEndToEndId(), Text.MAX_35, "payload.endToEndId");
        if (rules.identifiers().uetrRequired() || hasText(payload.getSwiftEndToEndTransactionReference())) {
            attempt(problems, () -> Text.uetr(payload.getSwiftEndToEndTransactionReference(),
                    "payload.swiftEndToEndTransactionReference"));
        }

        if (isBlank(payload.getValueDate())) {
            problems.add("payload.valueDate", "is required (PmtInf/ReqdExctnDt)");
        } else {
            try {
                DateTimeFormatter.ISO_LOCAL_DATE.parse(payload.getValueDate().strip());
            } catch (DateTimeParseException e) {
                problems.add("payload.valueDate", "must be a date in the form yyyy-MM-dd");
            }
        }

        amount(problems, payload);

        var namePolicy = rules.parties().namePolicy();
        var payer = payload.getPayer();
        if (payer == null) {
            problems.add("payload.payer", "is required (PmtInf/Dbtr)");
        } else {
            requiredParty(problems, payer, "payload.payer", "PmtInf/Dbtr");
            party(problems, payer, "payload.payer", namePolicy);
        }
        var payee = payload.getPayee();
        if (payee == null) {
            problems.add("payload.payee", "is required (CdtTrfTxInf/Cdtr)");
        } else {
            requiredParty(problems, payee, "payload.payee", "CdtTrfTxInf/Cdtr");
            party(problems, payee, "payload.payee", namePolicy);
        }
        party(problems, payload.getInitiatingParty(), "payload.initiatingParty", namePolicy);
        party(problems, payload.getUltimateDebtor(), "payload.ultimateDebtor", namePolicy);
        party(problems, payload.getUltimateCreditor(), "payload.ultimateCreditor", namePolicy);

        // Agents are mapped as received: the debtor agent is absent on ordinary outbound wires and the
        // creditor agent on drawdowns, so neither is required here.
        bank(problems, payload.getPayerBank(), "payload.payerBank", namePolicy);
        bank(problems, payload.getPayeeBank(), "payload.payeeBank", namePolicy);
        bank(problems, payload.getFirstIntermediaryBank(), "payload.firstIntermediaryBank", namePolicy);
        bank(problems, payload.getSecondaryIntermediaryBank(), "payload.secondaryIntermediaryBank", namePolicy);
        return problems;
    }

    private static void identifier(Problems problems, String value, String path, String target) {
        if (isBlank(value)) {
            problems.add(path, "is required (" + target + ")");
        } else {
            max(problems, value, Text.MAX_35, path);
        }
    }

    private static void amount(Problems problems, SDPPayload payload) {
        var fx = payload.getExchangeRate();
        var foreignCurrency = fx == null ? null : fx.getForeignExchangeCurrencyCode();
        if (hasText(foreignCurrency)) {
            attempt(problems, () -> Amounts.currency(foreignCurrency, "payload.exchangeRate.foreignExchangeCurrencyCode"));
            if (Amounts.isPositive(payload.getTransactionAmount())) {
                attempt(problems, () -> Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode"));
            } else if (!Amounts.isPositive(fx.getInstructedAmount())) {
                problems.add("payload.transactionAmount",
                        "or payload.exchangeRate.instructedAmount must be greater than zero (CdtTrfTxInf/Amt)");
            }
            max(problems, fx.getContractId(), Text.MAX_35, "payload.exchangeRate.contractId");
        } else {
            attempt(problems, () -> Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode"));
            if (!Amounts.isPositive(payload.getTransactionAmount())) {
                problems.add("payload.transactionAmount", "must be greater than zero (CdtTrfTxInf/Amt)");
            }
        }
    }

    /** A debtor or creditor must have an account number and a name. */
    private static void requiredParty(Problems problems, Account account, String path, String target) {
        if (isBlank(account.getAccountNumber())) {
            problems.add(path + ".accountNumber", "is required (" + target + "Acct)");
        }
        if (isBlank(account.getAccountName()) && isBlank(account.getAccountHolderFullName())
                && isBlank(account.getAccountLastName())) {
            problems.add(path + ".accountName", "is required (" + target + "/Nm)");
        }
    }

    /** Lengths and formats of a party; a null party is fine. */
    private static void party(Problems problems, Account account, String path, LongTextPolicy namePolicy) {
        if (account == null) {
            return;
        }
        if (namePolicy != LongTextPolicy.TRUNCATE) {
            max(problems, account.getAccountName(), Text.MAX_140, path + ".accountName");
            max(problems, account.getAccountHolderFullName(), Text.MAX_140, path + ".accountHolderFullName");
        }
        max(problems, account.getAccountNumber(), Text.MAX_34, path + ".accountNumber");
        max(problems, account.getOrganizationIdentificationNumber(), Text.MAX_35, path + ".organizationIdentificationNumber");
        max(problems, account.getIdentificationNumber(), Text.MAX_35, path + ".identificationNumber");
        if (hasText(account.getBankIdentifierCode())) {
            attempt(problems, () -> Text.bic(account.getBankIdentifierCode(), path + ".bankIdentifierCode"));
        }
        if (hasText(account.getLegalEntityIdentifier())) {
            attempt(problems, () -> Text.lei(account.getLegalEntityIdentifier(), path + ".legalEntityIdentifier"));
        }
        if (hasText(account.getCurrencyCode())) {
            attempt(problems, () -> Amounts.currency(account.getCurrencyCode(), path + ".currencyCode"));
        }
        address(problems, account.getAddress(), path + ".address");
    }

    /** Lengths and formats of a bank; a null bank is fine. */
    private static void bank(Problems problems, Bank bank, String path, LongTextPolicy namePolicy) {
        if (bank == null) {
            return;
        }
        if (hasText(bank.getSwiftBankIdentifierCode())) {
            attempt(problems, () -> Text.bic(bank.getSwiftBankIdentifierCode(), path + ".swiftBankIdentifierCode"));
        }
        if (hasText(bank.getLegalEntityIdentifier())) {
            attempt(problems, () -> Text.lei(bank.getLegalEntityIdentifier(), path + ".legalEntityIdentifier"));
        }
        max(problems, bank.getBankCode(), Text.MAX_35, path + ".bankCode");
        max(problems, bank.getBankAccountNumber(), Text.MAX_34, path + ".bankAccountNumber");
        if (namePolicy != LongTextPolicy.TRUNCATE) {
            max(problems, bank.getBankName(), Text.MAX_140, path + ".bankName");
        }
        address(problems, bank.getAddress(), path + ".address");
    }

    private static void address(Problems problems, Address address, String path) {
        if (address == null) {
            return;
        }
        max(problems, address.getDepartment(), Text.MAX_70, path + ".department");
        max(problems, address.getSubDepartment(), Text.MAX_70, path + ".subDepartment");
        max(problems, address.getStreetName(), Text.MAX_70, path + ".streetName");
        max(problems, address.getBuildingNumber(), Text.MAX_16, path + ".buildingNumber");
        max(problems, address.getBuildingName(), Text.MAX_35, path + ".buildingName");
        max(problems, address.getFloor(), Text.MAX_70, path + ".floor");
        max(problems, address.getPostalBox(), Text.MAX_16, path + ".postalBox");
        max(problems, address.getRoom(), Text.MAX_70, path + ".room");
        max(problems, address.getPostalCode(), Text.MAX_16, path + ".postalCode");
        max(problems, address.getCity(), Text.MAX_35, path + ".city");
        max(problems, address.getTownName(), Text.MAX_35, path + ".townName");
        max(problems, address.getTownLocationName(), Text.MAX_35, path + ".townLocationName");
        max(problems, address.getDistrictName(), Text.MAX_35, path + ".districtName");
        max(problems, address.getStateCode(), Text.MAX_35, path + ".stateCode");
        max(problems, address.getStateProvince(), Text.MAX_35, path + ".stateProvince");
        max(problems, address.getAddressLine1(), Text.MAX_70, path + ".addressLine1");
        max(problems, address.getAddressLine2(), Text.MAX_70, path + ".addressLine2");
        max(problems, address.getAddressLine3(), Text.MAX_70, path + ".addressLine3");
        max(problems, address.getAddressLine4(), Text.MAX_70, path + ".addressLine4");
        if (hasText(address.getCountryCode())) {
            attempt(problems, () -> Text.country(address.getCountryCode(), path + ".countryCode"));
        }
    }

    private static void max(Problems problems, String value, int max, String path) {
        if (value != null && value.strip().length() > max) {
            problems.add(path, "exceeds " + max + " characters (" + value.strip().length() + ")");
        }
    }

    private static void attempt(Problems problems, Runnable check) {
        try {
            check.run();
        } catch (MappingException e) {
            e.problems().forEach(p -> problems.add(p.path(), p.message()));
        }
    }
}
