package com.capitalone.bank.wire.object.mapper.util;

import com.capitalone.bank.wire.object.mapper.common.Amounts;
import com.capitalone.bank.wire.object.mapper.common.IsoDates;
import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AccountIdentification4Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AccountSchemeName1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ActiveOrHistoricCurrencyAndAmount;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AmountType4Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.BranchAndFinancialInstitutionIdentification6;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccount40;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccountType2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CategoryPurpose1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ChargeBearerType1Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ClearingSystemIdentification2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ClearingSystemMemberIdentification2;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.DateAndPlaceOfBirth1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.EquivalentAmount2;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ExchangeRate1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ExchangeRateType1Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.FinancialInstitutionIdentification18;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GenericAccountIdentification1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GenericOrganisationIdentification1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GenericPersonIdentification1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.InstructionForCreditorAgent3;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.LocalInstrument2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.OrganisationIdentification29;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.OrganisationIdentificationSchemeName1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Party38Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PartyIdentification135;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentInitiationSource1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PersonIdentification13;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PersonIdentificationSchemeName1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PostalAddress24;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Purpose2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.RemittanceInformation21;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ServiceLevel8Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.StructuredRemittanceInformation17;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.SupplementaryData1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.SupplementaryDataEnvelope1;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.FinancialInstitution;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.AccountScheme;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.AccountType;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.AddressStyle;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.CodeRules;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.CodeStyle;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.LongTextPolicy;
import com.capitalone.commercial.payx.sdp.payload.model.Account;
import com.capitalone.commercial.payx.sdp.payload.model.Address;
import com.capitalone.commercial.payx.sdp.payload.model.Bank;
import com.capitalone.commercial.payx.sdp.payload.model.CustomerPersonalInfo;
import com.capitalone.commercial.payx.sdp.payload.model.ExchangeRate;
import com.capitalone.commercial.payx.sdp.payload.model.RemitterInfo;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import javax.xml.XMLConstants;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Building logic shared by the wire mappers, for the ISO 20022 elements that are a choice, a code
 * translation or a derived value and so cannot be expressed as a single {@code @Mapping} line: amounts
 * and FX, account identification and type, party identification, clearing system membership, code
 * tables, remittance and instruction splitting, and the FIS supplementary data envelopes. The mapper
 * interface names each of these in its {@code @Mapping} list and delegates here.
 *
 * <p>Works on plain payment-object values and returns ISO objects; it never reads a JAXB object back.
 */
public final class WireMapperCommon {

    /** GrpHdr/NbOfTxs and PmtInf/NbOfTxs: one payment object is one transaction. */
    public static final String ONE_TRANSACTION = "1";

    public static final String FIS_PAYMENT_INFORMATION_SCHEMA = "urn:fis:ep:supplement:pain.001.001.11:pmtinf:universal:1";
    public static final String FIS_TRANSACTION_SCHEMA = "urn:fis:ep:supplement:pain.001.001.11:txinf:universal:1";
    /** The place-and-name the FIS samples use for the payment information supplement. */
    public static final String FIS_PAYMENT_INFORMATION_PLACE =
            "$.businessDocument.customerCreditTransferInitiation.paymentInformation[0]";

    /**
     * Payment Exchange payment type codes and the ISO external local instrument code each becomes. HERA
     * issues BTRC and CTRC; a drawdown code is not defined there yet, and DRC is expected. A value that
     * is already an ISO code (BTR, CTR, DRC) passes through.
     */
    private static final Map<String, String> LOCAL_INSTRUMENT_CODES = Map.of(
            "BTRC", "BTR",
            "CTRC", "CTR");

    /** chargedTo values and the ISO charge bearer each means; the ISO codes themselves are accepted as they are. */
    private static final Map<String, ChargeBearerType1Code> CHARGE_BEARERS = Map.ofEntries(
            Map.entry("DEBT", ChargeBearerType1Code.DEBT), Map.entry("OUR", ChargeBearerType1Code.DEBT),
            Map.entry("ORIGINATOR", ChargeBearerType1Code.DEBT), Map.entry("DEBTOR", ChargeBearerType1Code.DEBT),
            Map.entry("CRED", ChargeBearerType1Code.CRED), Map.entry("BEN", ChargeBearerType1Code.CRED),
            Map.entry("BENEFICIARY", ChargeBearerType1Code.CRED), Map.entry("CREDITOR", ChargeBearerType1Code.CRED),
            Map.entry("SHAR", ChargeBearerType1Code.SHAR), Map.entry("SHA", ChargeBearerType1Code.SHAR),
            Map.entry("SHARED", ChargeBearerType1Code.SHAR),
            Map.entry("SLEV", ChargeBearerType1Code.SLEV));

    /** accountIdType values that mean IBAN: the word and the legacy single-letter code. */
    private static final Set<String> IBAN_TYPES = Set.of("IBAN", "I");
    private static final Set<String> CURRENT_ACCOUNT_TYPES = Set.of("DDA", "D", "CHK", "CACC", "CHECKING");
    private static final Set<String> SAVINGS_TYPES = Set.of("SVGS", "SAV", "SAVINGS");
    private static final Set<String> SLASH_CLEANUP_SENDERS = Set.of("TMOBS", "TMOBSDOM", "OBS");
    private static final Set<String> INTERNATIONAL_CLEARING_SYSTEMS = Set.of("SWIFT");
    private static final Pattern NINE_DIGITS = Pattern.compile("\\d{9}");
    private static final String USABA = "USABA";
    private static final String DOMESTIC_CURRENCY = "USD";
    /** ExternalClearingSystemIdentification1Code is at most 5 characters. */
    private static final int CLEARING_SYSTEM_CODE_MAX = 5;

    private WireMapperCommon() {
    }

    // ------------------------------------------------------------------ group header

    /** GrpHdr/CreDtTm: now, UTC, milliseconds, from the context clock. */
    public static XMLGregorianCalendar creationDateTime(MappingContext context) {
        return IsoDates.dateTime(OffsetDateTime.now(context.clock()));
    }

    /** GrpHdr/InitgPty when the payment object names no initiating party: the fixed party of the context. */
    public static PartyIdentification135 contextInitiatingParty(MappingContext context) {
        var fixed = context.initiatingParty();
        var path = "context.initiatingParty";
        var party = new PartyIdentification135();
        party.setNm(Text.bounded(fixed.name(), Text.MAX_140, path + ".name"));
        Text.clean(fixed.anyBic()).map(value -> Text.bic(value, path + ".anyBic")).ifPresent(bic -> {
            var organisation = new OrganisationIdentification29();
            organisation.setAnyBIC(bic);
            var choice = new Party38Choice();
            choice.setOrgId(organisation);
            party.setId(choice);
        });
        Text.clean(fixed.countryOfResidence())
                .map(value -> Text.country(value, path + ".countryOfResidence"))
                .ifPresent(party::setCtryOfRes);
        return party;
    }

    /** GrpHdr/InitnSrc from the context, or null when the rule is off or the context names none. */
    public static PaymentInitiationSource1 initiationSource(MappingContext context) {
        var fixed = context.initiationSource();
        if (fixed == null || !context.rules().header().emitInitiationSource()) {
            return null;
        }
        var path = "context.initiationSource";
        var source = new PaymentInitiationSource1();
        source.setNm(Text.bounded(fixed.name(), Text.MAX_140, path + ".name"));
        Text.boundedOptional(fixed.provider(), Text.MAX_35, path + ".provider").ifPresent(source::setPrvdr);
        Text.boundedOptional(fixed.version(), Text.MAX_35, path + ".version").ifPresent(source::setVrsn);
        return source;
    }

    // ------------------------------------------------------------------ parties

    /** Nm: accountName, else accountHolderFullName, else the name parts joined; null when there is none. */
    public static String partyName(Account account, LongTextPolicy policy) {
        var name = Text.clean(account.getAccountName())
                .or(() -> Text.clean(account.getAccountHolderFullName()))
                .or(() -> Stream.of(account.getAccountPrefixName(), account.getAccountFirstName(),
                                account.getAccountMiddleName(), account.getAccountLastName(), account.getAccountSuffixName())
                        .flatMap(part -> Text.clean(part).stream())
                        .reduce((left, right) -> left + " " + right));
        return name.map(value -> boundedName(value, "accountName", policy)).orElse(null);
    }

    /** A Max140Text name under the name policy; null for a blank value. */
    public static String boundedName(String value, String path, LongTextPolicy policy) {
        return switch (policy) {
            case TRUNCATE -> Text.truncated(value, Text.MAX_140).orElse(null);
            case REJECT, SPLIT -> Text.boundedOptional(value, Text.MAX_140, path).orElse(null);
        };
    }

    /**
     * Id: a choice. A party with an organisation identifier (organisation id number, LEI or BIC) is
     * written as OrgId and its private identifiers are ignored; otherwise its private identification
     * (identification number, date and place of birth) is written as PrvtId. Null when it has neither.
     */
    public static Party38Choice partyIdentification(Account account) {
        var organisation = organisationIdentification(account);
        if (organisation != null) {
            var choice = new Party38Choice();
            choice.setOrgId(organisation);
            return choice;
        }
        var person = personIdentification(account);
        if (person != null) {
            var choice = new Party38Choice();
            choice.setPrvtId(person);
            return choice;
        }
        return null;
    }

    private static OrganisationIdentification29 organisationIdentification(Account account) {
        var organisation = new OrganisationIdentification29();
        boolean any = false;
        var bic = Text.clean(account.getBankIdentifierCode()).map(v -> Text.bic(v, "bankIdentifierCode"));
        if (bic.isPresent()) {
            organisation.setAnyBIC(bic.get());
            any = true;
        }
        var lei = Text.clean(account.getLegalEntityIdentifier()).map(v -> Text.lei(v, "legalEntityIdentifier"));
        if (lei.isPresent()) {
            organisation.setLEI(lei.get());
            any = true;
        }
        var number = Text.clean(account.getOrganizationIdentificationNumber());
        if (number.isPresent()) {
            var other = new GenericOrganisationIdentification1();
            other.setId(Text.bounded(number.get(), Text.MAX_35, "organizationIdentificationNumber"));
            Text.clean(account.getOrganizationIdentificationNumberType()).ifPresent(type -> {
                var scheme = new OrganisationIdentificationSchemeName1Choice();
                codeOrProprietary(type, "organizationIdentificationNumberType", scheme::setCd, scheme::setPrtry);
                other.setSchmeNm(scheme);
            });
            organisation.getOthr().add(other);
            any = true;
        }
        return any ? organisation : null;
    }

    private static PersonIdentification13 personIdentification(Account account) {
        var person = new PersonIdentification13();
        boolean any = false;
        var number = Text.clean(account.getIdentificationNumber());
        if (number.isPresent()) {
            var other = new GenericPersonIdentification1();
            other.setId(Text.bounded(number.get(), Text.MAX_35, "identificationNumber"));
            Text.clean(account.getIdentificationNumberType()).ifPresent(type -> {
                var scheme = new PersonIdentificationSchemeName1Choice();
                codeOrProprietary(type, "identificationNumberType", scheme::setCd, scheme::setPrtry);
                other.setSchmeNm(scheme);
            });
            person.getOthr().add(other);
            any = true;
        }
        var birth = dateAndPlaceOfBirth(account.getCustomerPersonalInfo());
        if (birth != null) {
            person.setDtAndPlcOfBirth(birth);
            any = true;
        }
        return any ? person : null;
    }

    /** Only when the date, city and country are all present; the payload spells the country {@code countryofbirth}. */
    private static DateAndPlaceOfBirth1 dateAndPlaceOfBirth(CustomerPersonalInfo info) {
        if (info == null || Text.isBlank(info.getDateOfBirth()) || Text.isBlank(info.getCityOfBirth())
                || Text.isBlank(info.getCountryofbirth())) {
            return null;
        }
        var birth = new DateAndPlaceOfBirth1();
        birth.setBirthDt(IsoDates.date(IsoDates.parse(info.getDateOfBirth(), "customerPersonalInfo.dateOfBirth")));
        birth.setCityOfBirth(Text.bounded(info.getCityOfBirth(), Text.MAX_35, "customerPersonalInfo.cityOfBirth"));
        birth.setCtryOfBirth(Text.country(info.getCountryofbirth(), "customerPersonalInfo.countryofbirth"));
        return birth;
    }

    // ------------------------------------------------------------------ accounts

    /** Acct/Id: IBAN when accountIdType says so, otherwise Othr/Id with the scheme the rule prescribes. */
    public static AccountIdentification4Choice accountIdentification(Account account, AccountScheme scheme) {
        var number = Text.clean(account.getAccountNumber());
        if (number.isEmpty()) {
            return null;
        }
        var identification = new AccountIdentification4Choice();
        var idType = Text.clean(account.getAccountIdType()).map(Text::upper);
        if (idType.filter(IBAN_TYPES::contains).isPresent()) {
            identification.setIBAN(Text.iban(number.get(), "accountNumber"));
            return identification;
        }
        var other = new GenericAccountIdentification1();
        other.setId(Text.bounded(number.get(), Text.MAX_34, "accountNumber"));
        switch (scheme) {
            case NONE -> { }
            case BBAN -> {
                var name = new AccountSchemeName1Choice();
                name.setCd("BBAN");
                other.setSchmeNm(name);
            }
            case PROPRIETARY -> {
                var name = new AccountSchemeName1Choice();
                name.setPrtry("Proprietary");
                other.setSchmeNm(name);
            }
        }
        identification.setOthr(other);
        return identification;
    }

    /** Acct/Tp under the account type rule; null when the rule writes none. */
    public static CashAccountType2Choice accountType(String accountIdType, AccountType type) {
        var idType = Text.clean(accountIdType).map(Text::upper);
        var choice = new CashAccountType2Choice();
        switch (type) {
            case NONE -> {
                return null;
            }
            case CACC -> choice.setCd("CACC");
            case FROM_ACCOUNT_ID_TYPE -> choice.setCd(idType.map(WireMapperCommon::externalAccountType).orElse("OTHR"));
            case PROPRIETARY_RAW -> {
                if (idType.isEmpty()) {
                    return null;
                }
                choice.setPrtry(idType.get());
            }
        }
        return choice;
    }

    private static String externalAccountType(String idType) {
        if (CURRENT_ACCOUNT_TYPES.contains(idType)) {
            return "CACC";
        }
        return SAVINGS_TYPES.contains(idType) ? "SVGS" : "OTHR";
    }

    /** An agent's account: Othr/Id only; null for a blank number. */
    public static CashAccount40 agentAccount(String number) {
        return Text.clean(number).map(value -> {
            var other = new GenericAccountIdentification1();
            other.setId(Text.bounded(value, Text.MAX_34, "bankAccountNumber"));
            var identification = new AccountIdentification4Choice();
            identification.setOthr(other);
            var account = new CashAccount40();
            account.setId(identification);
            return account;
        }).orElse(null);
    }

    // ------------------------------------------------------------------ agents

    /** True when the bank carries something an agent can be built from. */
    public static boolean hasContent(Bank bank) {
        return bank != null && (Text.hasText(bank.getSwiftBankIdentifierCode()) || Text.hasText(bank.getBankCode())
                || Text.hasText(bank.getBankName()));
    }

    /**
     * FinInstnId/ClrSysMmbId: the member code with its clearing system. A nine-digit code without a
     * system identifier is taken as USABA when the rule allows. Null when the bank has no member code.
     */
    public static ClearingSystemMemberIdentification2 clearingSystemMember(Bank bank, MappingRules rules) {
        var code = Text.clean(bank.getBankCode());
        if (code.isEmpty()) {
            return null;
        }
        var member = new ClearingSystemMemberIdentification2();
        member.setMmbId(Text.bounded(code.get(), Text.MAX_35, "bankCode"));
        var system = Text.clean(bank.getBankSystemIdentifier());
        if (system.isPresent()) {
            member.setClrSysId(clearingSystem(system.get()));
        } else if (rules.codes().inferUsabaFromNineDigitBankCode() && NINE_DIGITS.matcher(code.get()).matches()) {
            member.setClrSysId(clearingSystem(USABA));
        }
        return member;
    }

    private static ClearingSystemIdentification2Choice clearingSystem(String value) {
        var choice = new ClearingSystemIdentification2Choice();
        var code = Text.upper(value);
        if (code.length() <= CLEARING_SYSTEM_CODE_MAX) {
            choice.setCd(code);
        } else {
            choice.setPrtry(Text.bounded(code, Text.MAX_35, "bankSystemIdentifier"));
        }
        return choice;
    }

    /** A fixed institution from the {@link MappingContext}. */
    public static BranchAndFinancialInstitutionIdentification6 contextAgent(FinancialInstitution fixed) {
        var path = "context.debtorAgent";
        var institution = new FinancialInstitutionIdentification18();
        Text.clean(fixed.bicfi()).map(value -> Text.bic(value, path + ".bicfi")).ifPresent(institution::setBICFI);
        Text.clean(fixed.memberId()).ifPresent(code -> {
            var member = new ClearingSystemMemberIdentification2();
            member.setMmbId(Text.bounded(code, Text.MAX_35, path + ".memberId"));
            Text.clean(fixed.clearingSystemCode()).map(WireMapperCommon::clearingSystem).ifPresent(member::setClrSysId);
            institution.setClrSysMmbId(member);
        });
        Text.boundedOptional(fixed.name(), Text.MAX_140, path + ".name").ifPresent(institution::setNm);
        var agent = new BranchAndFinancialInstitutionIdentification6();
        agent.setFinInstnId(institution);
        return agent;
    }

    /**
     * An agent with an empty FinInstnId: the schema requires PmtInf/DbtrAgt, and the wire layer adds no
     * agent of its own when the payment object and the context carry none.
     */
    public static BranchAndFinancialInstitutionIdentification6 emptyAgent() {
        var agent = new BranchAndFinancialInstitutionIdentification6();
        agent.setFinInstnId(new FinancialInstitutionIdentification18());
        return agent;
    }

    // ------------------------------------------------------------------ addresses

    public static boolean hasContent(Address address) {
        return address != null && Stream.of(
                        address.getDepartment(), address.getSubDepartment(), address.getStreetName(),
                        address.getBuildingNumber(), address.getBuildingName(), address.getFloor(), address.getPostalBox(),
                        address.getRoom(), address.getPostalCode(), address.getCity(), address.getTownName(),
                        address.getTownLocationName(), address.getDistrictName(), address.getStateCode(),
                        address.getStateProvince(), address.getCountryCode(), address.getAddressLine1(),
                        address.getAddressLine2(), address.getAddressLine3(), address.getAddressLine4())
                .anyMatch(Text::hasText);
    }

    /** AdrLine: addressLine1 to addressLine4, the populated ones, in order. */
    public static List<String> addressLines(Address address) {
        return Stream.of(address.getAddressLine1(), address.getAddressLine2(), address.getAddressLine3(),
                        address.getAddressLine4())
                .flatMap(line -> Text.clean(line).stream())
                .toList();
    }

    /** TwnNm: city, else townName. */
    public static String townName(Address address) {
        return Text.clean(address.getCity()).or(() -> Text.clean(address.getTownName())).orElse(null);
    }

    /** CtrySubDvsn: stateCode, else stateProvince. */
    public static String countrySubDivision(Address address) {
        return Text.clean(address.getStateCode()).or(() -> Text.clean(address.getStateProvince())).orElse(null);
    }

    /** Drops the address lines or the structured fields when the address style asks for one form only. */
    public static void applyAddressStyle(PostalAddress24 address, AddressStyle style) {
        switch (style) {
            case STRUCTURED_AND_LINES -> { }
            case STRUCTURED_ONLY -> address.getAdrLine().clear();
            case LINES_ONLY -> {
                address.setDept(null);
                address.setSubDept(null);
                address.setStrtNm(null);
                address.setBldgNb(null);
                address.setBldgNm(null);
                address.setFlr(null);
                address.setPstBx(null);
                address.setRoom(null);
                address.setPstCd(null);
                address.setTwnNm(null);
                address.setTwnLctnNm(null);
                address.setDstrctNm(null);
                address.setCtrySubDvsn(null);
                address.setCtry(null);
            }
        }
    }

    // ------------------------------------------------------------------ codes

    /**
     * PmtTpInf/LclInstrm from paymentTypeCode: BTRC becomes BTR and CTRC becomes CTR (the ISO external
     * local instrument codes); a value that is already an ISO code passes through.
     */
    public static LocalInstrument2Choice localInstrument(String paymentTypeCode, CodeRules rules) {
        var raw = Text.upper(paymentTypeCode);
        var code = LOCAL_INSTRUMENT_CODES.getOrDefault(raw, raw);
        var choice = new LocalInstrument2Choice();
        if (rules.localInstrumentStyle() == CodeStyle.EXTERNAL_CODE && Text.isExternalCode(code)) {
            choice.setCd(code);
        } else {
            choice.setPrtry(Text.bounded(code, Text.MAX_35, "payload.paymentTypeCode"));
        }
        return choice;
    }

    /** PmtTpInf/SvcLvl: a repeating element; one entry from serviceLevelCd. */
    public static List<ServiceLevel8Choice> serviceLevels(String serviceLevelCd) {
        var choice = new ServiceLevel8Choice();
        codeOrProprietary(serviceLevelCd, "payload.serviceLevelCd", choice::setCd, choice::setPrtry);
        return List.of(choice);
    }

    public static CategoryPurpose1Choice categoryPurpose(String categoryPurpose) {
        var choice = new CategoryPurpose1Choice();
        codeOrProprietary(categoryPurpose, "payload.categoryPurpose", choice::setCd, choice::setPrtry);
        return choice;
    }

    public static Purpose2Choice purpose(String transactionReasonCd) {
        var choice = new Purpose2Choice();
        codeOrProprietary(transactionReasonCd, "payload.transactionReasonCd", choice::setCd, choice::setPrtry);
        return choice;
    }

    /**
     * ChrgBr from chargedTo: whatever the payment object carries, nothing defaulted. The ISO codes and
     * the usual words for them are accepted; an unknown value is rejected or left out per the rule.
     */
    public static ChargeBearerType1Code chargeBearer(String chargedTo, CodeRules rules) {
        var bearer = CHARGE_BEARERS.get(Text.upper(chargedTo));
        if (bearer == null && rules.chargeBearerPolicy() == MappingRules.UnknownCodePolicy.REJECT) {
            throw new MappingException("payload.chargedTo", "is not a known charge bearer (DEBT, CRED, SHAR, SLEV)");
        }
        return bearer;
    }

    private static ExchangeRateType1Code rateType(String foreignExchangeTrade, CodeRules rules) {
        try {
            return ExchangeRateType1Code.fromValue(Text.upper(foreignExchangeTrade));
        } catch (IllegalArgumentException e) {
            if (rules.rateTypePolicy() == MappingRules.UnknownCodePolicy.REJECT) {
                throw new MappingException("payload.exchangeRate.foreignExchangeTrade", "is not one of SPOT, SALE, AGRD", e);
            }
            return null;
        }
    }

    /** A value shaped like an ISO external code (1 to 4 upper-case letters or digits) goes to Cd, anything else to Prtry. */
    private static void codeOrProprietary(String value, String path, Consumer<String> code, Consumer<String> proprietary) {
        var text = Text.required(value, path);
        var upper = Text.upper(text);
        if (Text.isExternalCode(upper)) {
            code.accept(upper);
        } else {
            proprietary.accept(Text.bounded(text, Text.MAX_35, path));
        }
    }

    // ------------------------------------------------------------------ amounts and FX

    /**
     * @param amount                  CdtTrfTxInf/Amt
     * @param controlSum              the value written, for GrpHdr/CtrlSum and PmtInf/CtrlSum
     * @param currencyOfTransfer      the currency the creditor receives
     * @param exchangeRateInformation CdtTrfTxInf/XchgRateInf, or null
     */
    public record MappedAmount(AmountType4Choice amount, BigDecimal controlSum, String currencyOfTransfer,
                               ExchangeRate1 exchangeRateInformation) {
    }

    /**
     * Amount, currency and FX. No exchangeRate (or one without a foreign currency): InstdAmt is
     * transactionAmount in currencyCode. With a foreign currency: when transactionAmount is absent or
     * zero, InstdAmt is exchangeRate.instructedAmount in the foreign currency; otherwise the FX amount
     * style decides between EqvtAmt (debit amount plus currency of transfer) and InstdAmt in the foreign
     * currency. Amounts are rounded to the currency's minor unit; the control sum is the amount written.
     */
    public static MappedAmount amount(SDPPayload payload, MappingRules rules) {
        var fx = payload.getExchangeRate();
        var foreignCurrency = fx == null ? Optional.<String>empty()
                : Text.clean(fx.getForeignExchangeCurrencyCode())
                        .map(value -> Amounts.currency(value, "payload.exchangeRate.foreignExchangeCurrencyCode"));
        var choice = new AmountType4Choice();

        if (foreignCurrency.isEmpty()) {
            var currency = Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode");
            var amount = Amounts.positive(payload.getTransactionAmount(), currency, "payload.transactionAmount");
            choice.setInstdAmt(money(amount, currency));
            return new MappedAmount(choice, amount, currency, exchangeRateInformation(fx, rules));
        }

        var foreign = foreignCurrency.get();
        if (!Amounts.isPositive(payload.getTransactionAmount())) {
            var amount = Amounts.positive(fx.getInstructedAmount(), foreign, "payload.exchangeRate.instructedAmount");
            choice.setInstdAmt(money(amount, foreign));
            return new MappedAmount(choice, amount, foreign, exchangeRateInformation(fx, rules));
        }

        var amount = switch (rules.amounts().fxAmountStyle()) {
            case EQUIVALENT_AMOUNT -> {
                var currency = Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode");
                var debit = Amounts.positive(payload.getTransactionAmount(), currency, "payload.transactionAmount");
                var equivalent = new EquivalentAmount2();
                equivalent.setAmt(money(debit, currency));
                equivalent.setCcyOfTrf(foreign);
                choice.setEqvtAmt(equivalent);
                yield debit;
            }
            case INSTRUCTED_AMOUNT_ONLY -> {
                if (!Amounts.isPositive(fx.getInstructedAmount())) {
                    throw new MappingException("payload.exchangeRate.instructedAmount",
                            "is required for an FX payment when the amount style is INSTRUCTED_AMOUNT_ONLY");
                }
                var instructed = Amounts.positive(fx.getInstructedAmount(), foreign, "payload.exchangeRate.instructedAmount");
                choice.setInstdAmt(money(instructed, foreign));
                yield instructed;
            }
        };
        return new MappedAmount(choice, amount, foreign, exchangeRateInformation(fx, rules));
    }

    private static ExchangeRate1 exchangeRateInformation(ExchangeRate fx, MappingRules rules) {
        if (fx == null) {
            return null;
        }
        var information = new ExchangeRate1();
        boolean any = false;
        var rate = Text.clean(fx.getExchangeRate());
        if (rate.isPresent()) {
            try {
                information.setXchgRate(new BigDecimal(rate.get()));
            } catch (NumberFormatException e) {
                throw new MappingException("payload.exchangeRate.exchangeRate", "is not a number", e);
            }
            any = true;
        }
        if (Text.hasText(fx.getForeignExchangeTrade())) {
            var type = rateType(fx.getForeignExchangeTrade(), rules.codes());
            if (type != null) {
                information.setRateTp(type);
                any = true;
            }
        }
        var contract = Text.boundedOptional(fx.getContractId(), Text.MAX_35, "payload.exchangeRate.contractId");
        if (contract.isPresent()) {
            information.setCtrctId(contract.get());
            any = true;
        }
        return any ? information : null;
    }

    private static ActiveOrHistoricCurrencyAndAmount money(BigDecimal amount, String currency) {
        var money = new ActiveOrHistoricCurrencyAndAmount();
        money.setValue(amount);
        money.setCcy(currency);
        return money;
    }

    // ------------------------------------------------------------------ instructions and remittance

    /** InstrForCdtrAgt: bankToBank, one InstrInf per line and per 140 characters, after the optional slash clean-up. */
    public static List<InstructionForCreditorAgent3> instructionsForCreditorAgent(SDPPayload payload, MappingRules rules) {
        var text = Text.clean(payload.getBankToBank());
        if (text.isEmpty()) {
            return List.of();
        }
        var value = text.get();
        if (rules.texts().bankToBankSlashCleanup() && slashCleanupApplies(payload, value)) {
            value = value.replace('/', ' ');
        }
        var instructions = new ArrayList<InstructionForCreditorAgent3>();
        for (var piece : Text.chunks(value, Text.MAX_140)) {
            var instruction = new InstructionForCreditorAgent3();
            instruction.setInstrInf(piece);
            instructions.add(instruction);
        }
        return instructions;
    }

    private static boolean slashCleanupApplies(SDPPayload payload, String text) {
        var sender = Optional.ofNullable(payload.getOptionalHeaderInfo())
                .flatMap(header -> Text.clean(header.getSenderMemberId()))
                .map(Text::upper);
        return sender.filter(SLASH_CLEANUP_SENDERS::contains).isPresent() && text.chars().filter(c -> c == '/').count() > 1;
    }

    /**
     * RmtInf: Ustrd from unstructuredInfo under the remittance policy (one element per line, split at
     * 140); Strd with the invoicer and invoicee identifications when present. Null when there is nothing.
     */
    public static RemittanceInformation21 remittanceInformation(RemitterInfo info, MappingRules rules) {
        if (info == null) {
            return null;
        }
        var remittance = new RemittanceInformation21();
        var path = "payload.remitterInfo.unstructuredInfo";
        Text.clean(info.getUnstructuredInfo()).ifPresent(text -> remittance.getUstrd().addAll(
                switch (rules.texts().remittancePolicy()) {
                    case SPLIT -> Text.chunks(text, Text.MAX_140);
                    case TRUNCATE -> List.of(Text.truncated(text, Text.MAX_140).orElseThrow());
                    case REJECT -> List.of(Text.bounded(text, Text.MAX_140, path));
                }));
        var invoicer = organisationParty(info.getInvoicerIdentification(), "payload.remitterInfo.invoicerIdentification");
        var invoicee = organisationParty(info.getInvoiceeIdentification(), "payload.remitterInfo.invoiceeIdentification");
        if (invoicer != null || invoicee != null) {
            var structured = new StructuredRemittanceInformation17();
            structured.setInvcr(invoicer);
            structured.setInvcee(invoicee);
            remittance.getStrd().add(structured);
        }
        return remittance.getUstrd().isEmpty() && remittance.getStrd().isEmpty() ? null : remittance;
    }

    /** A party known by an organisation identifier only (Id/OrgId/Othr/Id). */
    private static PartyIdentification135 organisationParty(String identifier, String path) {
        return Text.clean(identifier).map(value -> {
            var other = new GenericOrganisationIdentification1();
            other.setId(Text.bounded(value, Text.MAX_35, path));
            var organisation = new OrganisationIdentification29();
            organisation.getOthr().add(other);
            var choice = new Party38Choice();
            choice.setOrgId(organisation);
            var party = new PartyIdentification135();
            party.setId(choice);
            return party;
        }).orElse(null);
    }

    // ------------------------------------------------------------------ FIS supplementary data

    /**
     * CstmrCdtTrfInitn/SplmtryData: the FIS payment information supplement, with the message id as the
     * first instruction receipt and trace identification and the extension block (internationalPayment
     * derived from the payment; the other values from the context).
     */
    public static List<SupplementaryData1> fisPaymentInformationSupplement(SDPPayload payload, MappingContext context) {
        if (!context.rules().supplements().emitFisSupplements()) {
            return List.of();
        }
        var trace = Text.bounded(payload.getClientTransactionId(), Text.MAX_35, "payload.clientTransactionId");
        var values = new LinkedHashMap<String, String>();
        values.put("firstInstructionReceiptIdentification", trace);
        values.put("firstInstructionTraceIdentification", trace);

        var extension = new LinkedHashMap<String, String>();
        extension.put("internationalPayment", isInternational(payload, amount(payload, context.rules()).currencyOfTransfer()) ? "Y" : "N");
        var fixed = context.fisExtension();
        Text.clean(fixed.instMethod()).ifPresent(v -> extension.put("instMethod", v));
        Text.clean(fixed.templateName()).ifPresent(v -> extension.put("templateName", v));
        Text.clean(fixed.accountType()).ifPresent(v -> extension.put("accountType", v));
        Text.clean(fixed.waiveFees()).ifPresent(v -> extension.put("waiveFees", v));

        var supplement = new SupplementaryData1();
        supplement.setPlcAndNm(FIS_PAYMENT_INFORMATION_PLACE);
        supplement.setEnvlp(envelope(FIS_PAYMENT_INFORMATION_SCHEMA, "paymentInformationSupplement", values, extension));
        return List.of(supplement);
    }

    /** CdtTrfTxInf/SplmtryData: the FIS transaction supplement, with the message id as the transaction trace identification. */
    public static List<SupplementaryData1> fisTransactionSupplement(SDPPayload payload, MappingContext context) {
        if (!context.rules().supplements().emitFisSupplements()) {
            return List.of();
        }
        var values = new LinkedHashMap<String, String>();
        values.put("transactionTraceIdentification",
                Text.bounded(payload.getClientTransactionId(), Text.MAX_35, "payload.clientTransactionId"));
        var supplement = new SupplementaryData1();
        supplement.setEnvlp(envelope(FIS_TRANSACTION_SCHEMA, "transactionInformationSupplement", values, Map.of()));
        return List.of(supplement);
    }

    /** International when the clearing system is SWIFT, the payment object carries internationalPayment, or the transfer is not in USD. */
    private static boolean isInternational(SDPPayload payload, String currencyOfTransfer) {
        var clearing = Text.clean(payload.getClearingSystem()).map(Text::upper);
        return clearing.filter(INTERNATIONAL_CLEARING_SYSTEMS::contains).isPresent()
                || payload.getInternationalPayment() != null
                || !DOMESTIC_CURRENCY.equals(currencyOfTransfer);
    }

    private static SupplementaryDataEnvelope1 envelope(String schema, String rootName, Map<String, String> values,
                                                      Map<String, String> extension) {
        Document document;
        try {
            var factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            document = factory.newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            throw new IllegalStateException("Cannot create a DOM document for the supplement", e);
        }
        var root = document.createElementNS(schema, rootName);
        document.appendChild(root);
        values.forEach((name, value) -> root.appendChild(textElement(document, schema, name, value)));
        if (!extension.isEmpty()) {
            var block = document.createElementNS(schema, "extension");
            extension.forEach((name, value) -> block.appendChild(textElement(document, schema, name, value)));
            root.appendChild(block);
        }
        var envelope = new SupplementaryDataEnvelope1();
        envelope.setAny(root);
        return envelope;
    }

    private static Element textElement(Document document, String namespace, String name, String value) {
        var element = document.createElementNS(namespace, name);
        element.setTextContent(value);
        return element;
    }
}
