package com.capitalone.bank.wire.object.mapper.util;

import com.capitalone.bank.wire.object.mapper.common.Amounts;
import com.capitalone.bank.wire.object.mapper.common.IsoDates;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.commercial.payx.sdp.payload.model.Address;
import com.capitalone.commercial.payx.sdp.payload.model.Bank;
import javax.xml.datatype.XMLGregorianCalendar;
import org.mapstruct.Condition;
import org.mapstruct.Named;

/**
 * Value-level qualifiers shared by the wire mappers: how a single payment-object value becomes a single
 * ISO 20022 value. Referenced from {@code @Mapping(qualifiedByName = ...)}; the two unqualified methods
 * ({@link #hasText} and {@link #trim}) apply to every String mapping, so a blank value is never written
 * and every text is trimmed.
 */
public final class WireQualifierUtil {

    private WireQualifierUtil() {
    }

    /** Presence check for every String source: null and blank are treated as absent. */
    @Condition
    public static boolean hasText(String value) {
        return Text.hasText(value);
    }

    /** Applied to every direct String-to-String mapping. */
    public static String trim(String value) {
        return value == null ? null : value.strip();
    }

    /** BICFIDec2014Identifier / AnyBICDec2014Identifier: upper case, 8 or 11 characters. */
    @Named("bic")
    public static String bic(String value) {
        return Text.bic(value, "BIC");
    }

    /** LEIIdentifier: upper case, 20 characters. */
    @Named("lei")
    public static String lei(String value) {
        return Text.lei(value, "LEI");
    }

    /** CountryCode: ISO 3166 alpha-2, upper case. */
    @Named("countryCode")
    public static String countryCode(String value) {
        return Text.country(value, "countryCode");
    }

    /** ActiveOrHistoricCurrencyCode: ISO 4217, upper case. */
    @Named("currencyCode")
    public static String currencyCode(String value) {
        return Amounts.currency(value, "currencyCode");
    }

    /** ISODate from valueDate, which must already be yyyy-MM-dd; written as a date only. */
    @Named("valueDate")
    public static XMLGregorianCalendar valueDate(String value) {
        return IsoDates.date(IsoDates.parse(value, "payload.valueDate"));
    }

    /** UUIDv4Identifier: lower case. */
    @Named("uetr")
    public static String uetr(String value) {
        return Text.uetr(value, "payload.swiftEndToEndTransactionReference");
    }

    /** An address is mapped only when it carries at least one value; an empty PstlAdr is never written. */
    @Condition
    @Named("hasAddressContent")
    public static boolean hasAddressContent(Address address) {
        return WireMapperCommon.hasContent(address);
    }

    /** An optional agent is mapped only when the bank carries a BIC, a member code or a name. */
    @Condition
    @Named("hasBankContent")
    public static boolean hasBankContent(Bank bank) {
        return WireMapperCommon.hasContent(bank);
    }
}
