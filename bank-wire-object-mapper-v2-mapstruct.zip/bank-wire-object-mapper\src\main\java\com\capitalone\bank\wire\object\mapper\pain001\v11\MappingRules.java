package com.capitalone.bank.wire.object.mapper.pain001.v11;

import java.util.Objects;

/**
 * The named, configurable rules of the mapping. The field-to-field mapping itself is declared in
 * {@code mappers.WireCreditTransferPain001V11}; a rule lives here only where a decision is still open
 * with FIS or may differ per deployment, so the answer changes one value and not the mapping.
 * {@link #defaults()} holds the current answers.
 */
public record MappingRules(
        IdentifierRules identifiers,
        PartyRules parties,
        AccountRules accounts,
        CodeRules codes,
        AmountRules amounts,
        TextRules texts,
        HeaderRules header,
        SupplementRules supplements) {

    public MappingRules {
        Objects.requireNonNull(identifiers, "identifiers");
        Objects.requireNonNull(parties, "parties");
        Objects.requireNonNull(accounts, "accounts");
        Objects.requireNonNull(codes, "codes");
        Objects.requireNonNull(amounts, "amounts");
        Objects.requireNonNull(texts, "texts");
        Objects.requireNonNull(header, "header");
        Objects.requireNonNull(supplements, "supplements");
    }

    /** The current rules: the mapping review decisions and the FIS sample requests. */
    public static MappingRules defaults() {
        return new MappingRules(IdentifierRules.defaults(), PartyRules.defaults(), AccountRules.defaults(),
                CodeRules.defaults(), AmountRules.defaults(), TextRules.defaults(), HeaderRules.defaults(),
                SupplementRules.defaults());
    }

    public MappingRules withIdentifiers(IdentifierRules value) {
        return new MappingRules(value, parties, accounts, codes, amounts, texts, header, supplements);
    }

    public MappingRules withParties(PartyRules value) {
        return new MappingRules(identifiers, value, accounts, codes, amounts, texts, header, supplements);
    }

    public MappingRules withAccounts(AccountRules value) {
        return new MappingRules(identifiers, parties, value, codes, amounts, texts, header, supplements);
    }

    public MappingRules withCodes(CodeRules value) {
        return new MappingRules(identifiers, parties, accounts, value, amounts, texts, header, supplements);
    }

    public MappingRules withAmounts(AmountRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, value, texts, header, supplements);
    }

    public MappingRules withTexts(TextRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, amounts, value, header, supplements);
    }

    public MappingRules withHeader(HeaderRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, amounts, texts, value, supplements);
    }

    public MappingRules withSupplements(SupplementRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, amounts, texts, header, value);
    }

    /** @param uetrRequired reject a payment without a UETR (swiftEndToEndTransactionReference) */
    public record IdentifierRules(boolean uetrRequired) {

        public static IdentifierRules defaults() {
            return new IdentifierRules(true);
        }
    }

    /** Which address elements are written (open with FIS). */
    public enum AddressStyle {
        /** Structured fields and address lines, whatever the payment object carries. */
        STRUCTURED_AND_LINES,
        /** Structured fields only; address lines dropped. */
        STRUCTURED_ONLY,
        /** Address lines only; structured fields dropped. */
        LINES_ONLY
    }

    /** What to do with a text longer than its Max<i>n</i>Text. */
    public enum LongTextPolicy {
        REJECT,
        TRUNCATE,
        /** Only for repeating elements such as RmtInf/Ustrd: one element per 140-character piece. */
        SPLIT
    }

    /**
     * @param addressStyle which address elements are written
     * @param namePolicy   a name over 140 characters: rejected (the external API already rejects it) or truncated
     */
    public record PartyRules(AddressStyle addressStyle, LongTextPolicy namePolicy) {

        public PartyRules {
            if (namePolicy == LongTextPolicy.SPLIT) {
                throw new IllegalArgumentException("a name cannot be split");
            }
        }

        public static PartyRules defaults() {
            return new PartyRules(AddressStyle.STRUCTURED_AND_LINES, LongTextPolicy.REJECT);
        }

        public PartyRules withAddressStyle(AddressStyle value) {
            return new PartyRules(value, namePolicy);
        }

        public PartyRules withNamePolicy(LongTextPolicy value) {
            return new PartyRules(addressStyle, value);
        }
    }

    /** The scheme name written with a non-IBAN account identification (Othr/SchmeNm). */
    public enum AccountScheme {
        /** No scheme name, as the FIS samples show for the debtor account. */
        NONE,
        /** SchmeNm/Cd = BBAN (ISO external code). */
        BBAN,
        /** SchmeNm/Prtry = "Proprietary", as the FIS samples show for the creditor account. */
        PROPRIETARY
    }

    /** The account type written as *Acct/Tp. */
    public enum AccountType {
        /** Nothing, as the FIS samples show for the creditor account. */
        NONE,
        /** Tp/Cd from accountIdType: DDA becomes CACC, savings SVGS, anything else OTHR (FIS debtor account). */
        FROM_ACCOUNT_ID_TYPE,
        /** Tp/Cd = CACC always. */
        CACC,
        /** Tp/Prtry = the raw accountIdType (DDA, IBAN), as the existing PIE messages carry it. */
        PROPRIETARY_RAW
    }

    /** How the debtor and creditor accounts are written; the defaults follow the FIS sample requests. */
    public record AccountRules(
            AccountScheme debtorScheme,
            AccountType debtorType,
            AccountScheme creditorScheme,
            AccountType creditorType) {

        public static AccountRules defaults() {
            return new AccountRules(AccountScheme.NONE, AccountType.FROM_ACCOUNT_ID_TYPE,
                    AccountScheme.PROPRIETARY, AccountType.NONE);
        }

        public AccountRules withDebtor(AccountScheme scheme, AccountType type) {
            return new AccountRules(scheme, type, creditorScheme, creditorType);
        }

        public AccountRules withCreditor(AccountScheme scheme, AccountType type) {
            return new AccountRules(debtorScheme, debtorType, scheme, type);
        }
    }

    /** Whether a code is written into the ISO external-code slot or the proprietary slot. */
    public enum CodeStyle {
        EXTERNAL_CODE,
        PROPRIETARY
    }

    /** What to do with a payment-object value that is not in the ISO code list. */
    public enum UnknownCodePolicy {
        /** Fail the payment, naming the field. */
        REJECT,
        /** Leave the element out. */
        OMIT
    }

    /**
     * @param localInstrumentStyle    PmtTpInf/LclInstrm: Cd (FIS samples) or Prtry for the converted payment type code
     * @param chargeBearerPolicy      unknown chargedTo value: reject, or omit ChrgBr
     * @param rateTypePolicy          unknown foreignExchangeTrade value: reject, or omit RateTp
     * @param inferUsabaFromNineDigitBankCode a nine-digit bankCode without bankSystemIdentifier is a USABA number
     */
    public record CodeRules(
            CodeStyle localInstrumentStyle,
            UnknownCodePolicy chargeBearerPolicy,
            UnknownCodePolicy rateTypePolicy,
            boolean inferUsabaFromNineDigitBankCode) {

        public static CodeRules defaults() {
            return new CodeRules(CodeStyle.EXTERNAL_CODE, UnknownCodePolicy.REJECT, UnknownCodePolicy.REJECT, true);
        }

        public CodeRules withLocalInstrumentStyle(CodeStyle value) {
            return new CodeRules(value, chargeBearerPolicy, rateTypePolicy, inferUsabaFromNineDigitBankCode);
        }

        public CodeRules withChargeBearerPolicy(UnknownCodePolicy value) {
            return new CodeRules(localInstrumentStyle, value, rateTypePolicy, inferUsabaFromNineDigitBankCode);
        }

        public CodeRules withRateTypePolicy(UnknownCodePolicy value) {
            return new CodeRules(localInstrumentStyle, chargeBearerPolicy, value, inferUsabaFromNineDigitBankCode);
        }
    }

    /** How an FX payment's amount is written (open with FIS). */
    public enum FxAmountStyle {
        /** Amt/EqvtAmt: the debit amount in the account currency plus the currency of transfer. */
        EQUIVALENT_AMOUNT,
        /** Amt/InstdAmt in the foreign currency from exchangeRate.instructedAmount; EqvtAmt never used. */
        INSTRUCTED_AMOUNT_ONLY
    }

    public record AmountRules(FxAmountStyle fxAmountStyle) {

        public static AmountRules defaults() {
            return new AmountRules(FxAmountStyle.EQUIVALENT_AMOUNT);
        }
    }

    /**
     * @param remittancePolicy        remitterInfo.unstructuredInfo over 140 characters: split, truncate or reject
     * @param bankToBankSlashCleanup  replace every slash with a space when the sender is TMOBS, TMOBSDOM or OBS and the
     *                                text has more than one slash (a PIE work-around)
     */
    public record TextRules(LongTextPolicy remittancePolicy, boolean bankToBankSlashCleanup) {

        public static TextRules defaults() {
            return new TextRules(LongTextPolicy.SPLIT, false);
        }

        public TextRules withRemittancePolicy(LongTextPolicy value) {
            return new TextRules(value, bankToBankSlashCleanup);
        }
    }

    /** @param emitInitiationSource write GrpHdr/InitnSrc from the context (not in the FIS samples, so off) */
    public record HeaderRules(boolean emitInitiationSource) {

        public static HeaderRules defaults() {
            return new HeaderRules(false);
        }
    }

    /**
     * The FIS supplementary data envelopes seen in every FIS sample request, written as SplmtryData.
     *
     * @param emitFisSupplements write the two envelopes
     */
    public record SupplementRules(boolean emitFisSupplements) {

        public static SupplementRules defaults() {
            return new SupplementRules(true);
        }
    }
}
