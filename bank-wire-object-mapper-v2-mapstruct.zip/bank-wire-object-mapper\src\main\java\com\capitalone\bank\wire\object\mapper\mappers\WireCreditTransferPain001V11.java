package com.capitalone.bank.wire.object.mapper.mappers;

import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AccountIdentification4Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AmountType4Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.BranchAndFinancialInstitutionIdentification6;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccount40;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccountType2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CategoryPurpose1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ChargeBearerType1Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ClearingSystemMemberIdentification2;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CreditTransferTransaction54;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CustomerCreditTransferInitiationV11;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ExchangeRate1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.FinancialInstitutionIdentification18;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GroupHeader95;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.InstructionForCreditorAgent3;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.LocalInstrument2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Party38Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PartyIdentification135;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentIdentification6;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentInitiationSource1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentInstruction40;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentTypeInformation26;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PostalAddress24;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Purpose2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.RemittanceInformation21;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ServiceLevel8Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.SupplementaryData1;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext;
import com.capitalone.bank.wire.object.mapper.util.WireMapperCommon;
import com.capitalone.bank.wire.object.mapper.util.WireQualifierUtil;
import com.capitalone.commercial.payx.sdp.payload.model.Account;
import com.capitalone.commercial.payx.sdp.payload.model.Address;
import com.capitalone.commercial.payx.sdp.payload.model.Bank;
import com.capitalone.commercial.payx.sdp.payload.model.RemitterInfo;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.math.BigDecimal;
import java.util.List;
import javax.xml.datatype.XMLGregorianCalendar;
import org.mapstruct.AfterMapping;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * MapStruct mapper for outbound wires: the Payment Exchange payment object ({@link SDPPayload}) to an
 * ISO 20022 pain.001.001.11 customer credit transfer initiation ({@code CustomerCreditTransferInitiationV11}),
 * one group header, one payment information block and one credit transfer transaction.
 *
 * <p><b>How to read it.</b> The mapping is declared top-down, one method per ISO block, in the order of
 * the message: {@code Document}, {@code CstmrCdtTrfInitn}, {@code GrpHdr}, {@code PmtInf},
 * {@code CdtTrfTxInf} (with {@code PmtId} and {@code PmtTpInf}), then the reusable types: party,
 * postal address, agent, financial institution and cash account. Every {@code @Mapping} line names an
 * ISO element ({@code target}) and the payment-object field it comes from ({@code source}); a line with
 * {@code source = "."} is derived from more than one field and names the rule in {@code qualifiedByName}.
 * ISO elements with no line are not written.
 *
 * <p>The {@code @Named} methods below the declarations are the rules those lines refer to. Each is a
 * choice, a code translation or a derived value and delegates to {@link WireMapperCommon}; value-level
 * qualifiers (BIC, LEI, country, currency, dates, UETR) are in {@link WireQualifierUtil}, which also
 * trims every text and skips blank values.
 *
 * <p>The {@link MappingContext} travels through every method as {@code @Context}: it carries the clock,
 * the fixed initiating party and the {@code MappingRules}.
 */
@Mapper(uses = WireQualifierUtil.class, unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface WireCreditTransferPain001V11 {

    WireCreditTransferPain001V11 INSTANCE = Mappers.getMapper(WireCreditTransferPain001V11.class);

    // ====================================================================================== Document

    @Mapping(target = "cstmrCdtTrfInitn", source = ".")
    Document sdpPayloadToPain001(SDPPayload payload, @Context MappingContext context);

    // ============================================================================== CstmrCdtTrfInitn

    @Mapping(target = "grpHdr", source = ".")
    @Mapping(target = "pmtInf", source = ".", qualifiedByName = "paymentInformation")
    @Mapping(target = "splmtryData", source = ".", qualifiedByName = "fisPaymentInformationSupplement")
    CustomerCreditTransferInitiationV11 toCustomerCreditTransferInitiation(SDPPayload payload, @Context MappingContext context);

    // ======================================================================================== GrpHdr

    @Mapping(target = "msgId", source = "clientTransactionId")
    @Mapping(target = "creDtTm", source = ".", qualifiedByName = "creationDateTime")
    @Mapping(target = "nbOfTxs", constant = WireMapperCommon.ONE_TRANSACTION)
    @Mapping(target = "ctrlSum", source = ".", qualifiedByName = "controlSum")
    @Mapping(target = "initgPty", source = ".", qualifiedByName = "initiatingParty")
    @Mapping(target = "initnSrc", source = ".", qualifiedByName = "initiationSource")
    GroupHeader95 toGroupHeader(SDPPayload payload, @Context MappingContext context);

    // ======================================================================================== PmtInf

    @Mapping(target = "pmtInfId", source = "clientTransactionId")
    @Mapping(target = "pmtMtd", constant = "TRF")
    @Mapping(target = "btchBookg", constant = "false")
    @Mapping(target = "nbOfTxs", constant = WireMapperCommon.ONE_TRANSACTION)
    @Mapping(target = "ctrlSum", source = ".", qualifiedByName = "controlSum")
    @Mapping(target = "reqdExctnDt.dt", source = "valueDate", qualifiedByName = "valueDate")
    @Mapping(target = "dbtr", source = "payer", qualifiedByName = "toParty")
    @Mapping(target = "dbtrAcct", source = "payer", qualifiedByName = "toDebtorAccount")
    @Mapping(target = "dbtrAgt", source = ".", qualifiedByName = "debtorAgent")
    @Mapping(target = "cdtTrfTxInf", source = ".", qualifiedByName = "creditTransferTransaction")
    PaymentInstruction40 toPaymentInformation(SDPPayload payload, @Context MappingContext context);

    // =================================================================================== CdtTrfTxInf

    @Mapping(target = "pmtId", source = ".")
    @Mapping(target = "pmtTpInf", source = ".")
    @Mapping(target = "amt", source = ".", qualifiedByName = "amount")
    @Mapping(target = "xchgRateInf", source = ".", qualifiedByName = "exchangeRateInformation")
    @Mapping(target = "chrgBr", source = "chargedTo", qualifiedByName = "chargeBearer")
    @Mapping(target = "ultmtDbtr", source = "ultimateDebtor", qualifiedByName = "toParty")
    @Mapping(target = "intrmyAgt1", source = "firstIntermediaryBank", qualifiedByName = "toAgent",
            conditionQualifiedByName = "hasBankContent")
    @Mapping(target = "intrmyAgt1Acct", source = "firstIntermediaryBank.bankAccountNumber", qualifiedByName = "toAgentAccount")
    @Mapping(target = "intrmyAgt2", source = "secondaryIntermediaryBank", qualifiedByName = "toAgent",
            conditionQualifiedByName = "hasBankContent")
    @Mapping(target = "intrmyAgt2Acct", source = "secondaryIntermediaryBank.bankAccountNumber", qualifiedByName = "toAgentAccount")
    @Mapping(target = "cdtrAgt", source = "payeeBank", qualifiedByName = "toAgent",
            conditionQualifiedByName = "hasBankContent")
    @Mapping(target = "cdtrAgtAcct", source = "payeeBank.bankAccountNumber", qualifiedByName = "toAgentAccount")
    @Mapping(target = "cdtr", source = "payee", qualifiedByName = "toParty")
    @Mapping(target = "cdtrAcct", source = "payee", qualifiedByName = "toCreditorAccount")
    @Mapping(target = "ultmtCdtr", source = "ultimateCreditor", qualifiedByName = "toParty")
    @Mapping(target = "instrForCdtrAgt", source = ".", qualifiedByName = "instructionsForCreditorAgent")
    @Mapping(target = "purp", source = "transactionReasonCd", qualifiedByName = "purpose")
    @Mapping(target = "rmtInf", source = "remitterInfo", qualifiedByName = "remittanceInformation")
    @Mapping(target = "splmtryData", source = ".", qualifiedByName = "fisTransactionSupplement")
    CreditTransferTransaction54 toCreditTransferTransaction(SDPPayload payload, @Context MappingContext context);

    // ----------------------------------------------------------------------------- CdtTrfTxInf/PmtId

    @Mapping(target = "instrId", source = "instructionId",
            defaultExpression = "java(WireQualifierUtil.trim(payload.getClientTransactionId()))")
    @Mapping(target = "endToEndId", source = "endToEndId",
            defaultExpression = "java(WireQualifierUtil.trim(payload.getClientTransactionId()))")
    @Mapping(target = "UETR", source = "swiftEndToEndTransactionReference", qualifiedByName = "uetr")
    PaymentIdentification6 toPaymentIdentification(SDPPayload payload, @Context MappingContext context);

    // -------------------------------------------------------------------------- CdtTrfTxInf/PmtTpInf

    @Mapping(target = "instrPrty", constant = "HIGH")
    @Mapping(target = "svcLvl", source = "serviceLevelCd", qualifiedByName = "serviceLevels")
    @Mapping(target = "lclInstrm", source = "paymentTypeCode", qualifiedByName = "localInstrument")
    @Mapping(target = "ctgyPurp", source = "categoryPurpose", qualifiedByName = "categoryPurpose")
    PaymentTypeInformation26 toPaymentTypeInformation(SDPPayload payload, @Context MappingContext context);

    // ============================================================== Party (PartyIdentification135)
    // Used for Dbtr, Cdtr, UltmtDbtr, UltmtCdtr and InitgPty.

    @Named("toParty")
    @Mapping(target = "nm", source = ".", qualifiedByName = "partyName")
    @Mapping(target = "pstlAdr", source = "address", qualifiedByName = "toPostalAddress",
            conditionQualifiedByName = "hasAddressContent")
    @Mapping(target = "id", source = ".", qualifiedByName = "partyIdentification")
    PartyIdentification135 toParty(Account account, @Context MappingContext context);

    // ============================================================== Postal address (PostalAddress24)

    @Named("toPostalAddress")
    @Mapping(target = "dept", source = "department")
    @Mapping(target = "subDept", source = "subDepartment")
    @Mapping(target = "strtNm", source = "streetName")
    @Mapping(target = "bldgNb", source = "buildingNumber")
    @Mapping(target = "bldgNm", source = "buildingName")
    @Mapping(target = "flr", source = "floor")
    @Mapping(target = "pstBx", source = "postalBox")
    @Mapping(target = "room", source = "room")
    @Mapping(target = "pstCd", source = "postalCode")
    @Mapping(target = "twnNm", source = ".", qualifiedByName = "townName")
    @Mapping(target = "twnLctnNm", source = "townLocationName")
    @Mapping(target = "dstrctNm", source = "districtName")
    @Mapping(target = "ctrySubDvsn", source = ".", qualifiedByName = "countrySubDivision")
    @Mapping(target = "ctry", source = "countryCode", qualifiedByName = "countryCode")
    @Mapping(target = "adrLine", source = ".", qualifiedByName = "addressLines")
    PostalAddress24 toPostalAddress(Address address, @Context MappingContext context);

    // ============================== Agent (BranchAndFinancialInstitutionIdentification6 / FinInstnId)
    // Used for DbtrAgt, CdtrAgt, IntrmyAgt1 and IntrmyAgt2.

    @Named("toAgent")
    @Mapping(target = "finInstnId", source = ".")
    BranchAndFinancialInstitutionIdentification6 toAgent(Bank bank, @Context MappingContext context);

    @Mapping(target = "BICFI", source = "swiftBankIdentifierCode", qualifiedByName = "bic")
    @Mapping(target = "clrSysMmbId", source = ".", qualifiedByName = "clearingSystemMember")
    @Mapping(target = "LEI", source = "legalEntityIdentifier", qualifiedByName = "lei")
    @Mapping(target = "nm", source = "bankName", qualifiedByName = "institutionName")
    @Mapping(target = "pstlAdr", source = "address", qualifiedByName = "toPostalAddress",
            conditionQualifiedByName = "hasAddressContent")
    FinancialInstitutionIdentification18 toFinancialInstitution(Bank bank, @Context MappingContext context);

    // ===================================================================== Cash account (CashAccount40)

    @Named("toDebtorAccount")
    @Mapping(target = "id", source = ".", qualifiedByName = "debtorAccountIdentification")
    @Mapping(target = "tp", source = "accountIdType", qualifiedByName = "debtorAccountType")
    @Mapping(target = "ccy", source = "currencyCode", qualifiedByName = "currencyCode")
    CashAccount40 toDebtorAccount(Account account, @Context MappingContext context);

    @Named("toCreditorAccount")
    @Mapping(target = "id", source = ".", qualifiedByName = "creditorAccountIdentification")
    @Mapping(target = "tp", source = "accountIdType", qualifiedByName = "creditorAccountType")
    @Mapping(target = "ccy", source = "currencyCode", qualifiedByName = "currencyCode")
    CashAccount40 toCreditorAccount(Account account, @Context MappingContext context);

    // ==================================================================================================
    // Rules referenced by qualifiedByName above. Each delegates to WireMapperCommon.
    // ==================================================================================================

    /** CstmrCdtTrfInitn/PmtInf: one payment information block per payment object. */
    @Named("paymentInformation")
    default List<PaymentInstruction40> paymentInformation(SDPPayload payload, @Context MappingContext context) {
        return List.of(toPaymentInformation(payload, context));
    }

    /** PmtInf/CdtTrfTxInf: one transaction per payment object. */
    @Named("creditTransferTransaction")
    default List<CreditTransferTransaction54> creditTransferTransaction(SDPPayload payload, @Context MappingContext context) {
        return List.of(toCreditTransferTransaction(payload, context));
    }

    /** GrpHdr/CreDtTm: now, UTC, from the context clock. */
    @Named("creationDateTime")
    static XMLGregorianCalendar creationDateTime(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.creationDateTime(context);
    }

    /** GrpHdr/CtrlSum and PmtInf/CtrlSum: the amount written in CdtTrfTxInf/Amt. */
    @Named("controlSum")
    static BigDecimal controlSum(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.amount(payload, context.rules()).controlSum();
    }

    /** GrpHdr/InitgPty: initiatingParty when it has a name, otherwise the fixed party of the context. */
    @Named("initiatingParty")
    default PartyIdentification135 initiatingParty(SDPPayload payload, @Context MappingContext context) {
        var party = payload.getInitiatingParty();
        return party != null && Text.hasText(party.getAccountName())
                ? toParty(party, context)
                : WireMapperCommon.contextInitiatingParty(context);
    }

    /** GrpHdr/InitnSrc: from the context when the header rule asks for it. */
    @Named("initiationSource")
    static PaymentInitiationSource1 initiationSource(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.initiationSource(context);
    }

    /**
     * PmtInf/DbtrAgt: payerBank as the payment object carries it. The wire layer adds no agent of its
     * own: when payerBank is absent, the fixed agent of the context is used if one is configured,
     * otherwise the element is written with an empty FinInstnId because the schema requires it.
     */
    @Named("debtorAgent")
    default BranchAndFinancialInstitutionIdentification6 debtorAgent(SDPPayload payload, @Context MappingContext context) {
        if (WireMapperCommon.hasContent(payload.getPayerBank())) {
            return toAgent(payload.getPayerBank(), context);
        }
        return context.debtorAgent() != null
                ? WireMapperCommon.contextAgent(context.debtorAgent())
                : WireMapperCommon.emptyAgent();
    }

    /** CdtTrfTxInf/Amt: InstdAmt, or EqvtAmt for an FX payment, per the FX amount rule. */
    @Named("amount")
    static AmountType4Choice amount(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.amount(payload, context.rules()).amount();
    }

    /** CdtTrfTxInf/XchgRateInf: rate, rate type and contract id from exchangeRate. */
    @Named("exchangeRateInformation")
    static ExchangeRate1 exchangeRateInformation(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.amount(payload, context.rules()).exchangeRateInformation();
    }

    /** CdtTrfTxInf/ChrgBr: chargedTo as the payment object carries it; nothing is defaulted. */
    @Named("chargeBearer")
    static ChargeBearerType1Code chargeBearer(String chargedTo, @Context MappingContext context) {
        return WireMapperCommon.chargeBearer(chargedTo, context.rules().codes());
    }

    /** PmtTpInf/LclInstrm: paymentTypeCode converted to the ISO external code (BTRC to BTR, CTRC to CTR). */
    @Named("localInstrument")
    static LocalInstrument2Choice localInstrument(String paymentTypeCode, @Context MappingContext context) {
        return WireMapperCommon.localInstrument(paymentTypeCode, context.rules().codes());
    }

    /** PmtTpInf/SvcLvl: Cd for an ISO external code, otherwise Prtry. */
    @Named("serviceLevels")
    static List<ServiceLevel8Choice> serviceLevels(String serviceLevelCd) {
        return WireMapperCommon.serviceLevels(serviceLevelCd);
    }

    /** PmtTpInf/CtgyPurp: Cd for an ISO external code, otherwise Prtry. */
    @Named("categoryPurpose")
    static CategoryPurpose1Choice categoryPurpose(String categoryPurpose) {
        return WireMapperCommon.categoryPurpose(categoryPurpose);
    }

    /** CdtTrfTxInf/Purp: Cd for an ISO external code, otherwise Prtry. */
    @Named("purpose")
    static Purpose2Choice purpose(String transactionReasonCd) {
        return WireMapperCommon.purpose(transactionReasonCd);
    }

    /** CdtTrfTxInf/InstrForCdtrAgt: bankToBank, one InstrInf per line and per 140 characters. */
    @Named("instructionsForCreditorAgent")
    static List<InstructionForCreditorAgent3> instructionsForCreditorAgent(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.instructionsForCreditorAgent(payload, context.rules());
    }

    /** CdtTrfTxInf/RmtInf: Ustrd from unstructuredInfo; Strd with the invoicer and invoicee identifications. */
    @Named("remittanceInformation")
    static RemittanceInformation21 remittanceInformation(RemitterInfo remitterInfo, @Context MappingContext context) {
        return WireMapperCommon.remittanceInformation(remitterInfo, context.rules());
    }

    /** CstmrCdtTrfInitn/SplmtryData: the FIS payment information supplement. */
    @Named("fisPaymentInformationSupplement")
    static List<SupplementaryData1> fisPaymentInformationSupplement(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.fisPaymentInformationSupplement(payload, context);
    }

    /** CdtTrfTxInf/SplmtryData: the FIS transaction supplement. */
    @Named("fisTransactionSupplement")
    static List<SupplementaryData1> fisTransactionSupplement(SDPPayload payload, @Context MappingContext context) {
        return WireMapperCommon.fisTransactionSupplement(payload, context);
    }

    /** Party/Nm: accountName, else accountHolderFullName, else the name parts joined. */
    @Named("partyName")
    static String partyName(Account account, @Context MappingContext context) {
        return WireMapperCommon.partyName(account, context.rules().parties().namePolicy());
    }

    /** Party/Id: OrgId when the party has an organisation identifier, otherwise PrvtId; never both. */
    @Named("partyIdentification")
    static Party38Choice partyIdentification(Account account) {
        return WireMapperCommon.partyIdentification(account);
    }

    /** PstlAdr/TwnNm: city, else townName. */
    @Named("townName")
    static String townName(Address address) {
        return WireMapperCommon.townName(address);
    }

    /** PstlAdr/CtrySubDvsn: stateCode, else stateProvince. */
    @Named("countrySubDivision")
    static String countrySubDivision(Address address) {
        return WireMapperCommon.countrySubDivision(address);
    }

    /** PstlAdr/AdrLine: addressLine1 to addressLine4. */
    @Named("addressLines")
    static List<String> addressLines(Address address) {
        return WireMapperCommon.addressLines(address);
    }

    /** Keeps only the address form the address rule asks for. */
    @AfterMapping
    default void applyAddressStyle(@MappingTarget PostalAddress24 address, @Context MappingContext context) {
        WireMapperCommon.applyAddressStyle(address, context.rules().parties().addressStyle());
    }

    /** FinInstnId/ClrSysMmbId: bankCode with its clearing system (bankSystemIdentifier, or USABA for a nine-digit code). */
    @Named("clearingSystemMember")
    static ClearingSystemMemberIdentification2 clearingSystemMember(Bank bank, @Context MappingContext context) {
        return WireMapperCommon.clearingSystemMember(bank, context.rules());
    }

    /** FinInstnId/Nm: bankName under the name rule. */
    @Named("institutionName")
    static String institutionName(String bankName, @Context MappingContext context) {
        return WireMapperCommon.boundedName(bankName, "bankName", context.rules().parties().namePolicy());
    }

    /** Agent account: Othr/Id from bankAccountNumber. */
    @Named("toAgentAccount")
    static CashAccount40 toAgentAccount(String bankAccountNumber) {
        return WireMapperCommon.agentAccount(bankAccountNumber);
    }

    /** DbtrAcct/Id: IBAN, or Othr/Id with the debtor scheme rule. */
    @Named("debtorAccountIdentification")
    static AccountIdentification4Choice debtorAccountIdentification(Account account, @Context MappingContext context) {
        return WireMapperCommon.accountIdentification(account, context.rules().accounts().debtorScheme());
    }

    /** DbtrAcct/Tp: from accountIdType under the debtor type rule. */
    @Named("debtorAccountType")
    static CashAccountType2Choice debtorAccountType(String accountIdType, @Context MappingContext context) {
        return WireMapperCommon.accountType(accountIdType, context.rules().accounts().debtorType());
    }

    /** CdtrAcct/Id: IBAN, or Othr/Id with the creditor scheme rule. */
    @Named("creditorAccountIdentification")
    static AccountIdentification4Choice creditorAccountIdentification(Account account, @Context MappingContext context) {
        return WireMapperCommon.accountIdentification(account, context.rules().accounts().creditorScheme());
    }

    /** CdtrAcct/Tp: from accountIdType under the creditor type rule. */
    @Named("creditorAccountType")
    static CashAccountType2Choice creditorAccountType(String accountIdType, @Context MappingContext context) {
        return WireMapperCommon.accountType(accountIdType, context.rules().accounts().creditorType());
    }
}
