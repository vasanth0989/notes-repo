package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import com.capitalone.bank.wire.object.mapper.mappers.WireCreditTransferPain001V11;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.util.Objects;

/**
 * Entry point of the library: maps one Payment Exchange payment object ({@link SDPPayload}, an outbound
 * GPN or corporate wire after OFAC) to a pain.001.001.11 {@link Document}.
 *
 * <p>Two steps. The payment is validated first ({@link PayloadPreconditions}) so that a payment missing
 * several things is rejected with every reason at once, each naming the payment-object field. The
 * mapping itself is the MapStruct mapper {@link WireCreditTransferPain001V11}, where every pain.001
 * element is declared against the payment-object field it comes from.
 *
 * <p>Thread-safe; one instance per configuration is enough.
 */
public final class Pain001V11Mapper {

    private final MappingContext context;
    private final WireCreditTransferPain001V11 mapper;
    private final Pain001V11Marshaller marshaller;

    public Pain001V11Mapper(MappingContext context) {
        this.context = Objects.requireNonNull(context, "context");
        this.mapper = WireCreditTransferPain001V11.INSTANCE;
        this.marshaller = new Pain001V11Marshaller();
    }

    /** The JAXB document for one payment. Throws {@link MappingException} with every problem found. */
    public Document map(SDPPayload payload) {
        Objects.requireNonNull(payload, "payload");
        PayloadPreconditions.check(payload, context).throwIfAny();
        return mapper.sdpPayloadToPain001(payload, context);
    }

    /** The pain.001.001.11 XML for one payment, validated against the schema before it is returned. */
    public String mapToXml(SDPPayload payload) {
        return marshaller.toXml(map(payload), true);
    }

    public MappingContext context() {
        return context;
    }
}
