package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"transactionAmount", "currencyCode", "paymentTypeCode", "chargedTo", "valueDate", "bankToBank", "instructionId", "messageTransmissionId", "transactionId", "endToEndId", "swiftEndToEndTransactionReference", "batchId", "clientTransactionId", "paymentSourceChannelId", "paymentSourceChannelDescription", "paymentStatus", "previousPaymentStatus", "transactionDirectionName", "messageFormat", "paymentType", "clearingSystem", "clearingSystemReferenceNumber", "clearingSystemOutputReferenceNumber", "serviceLevelCd", "transactionReasonCd", "localInstrumentCode", "categoryPurpose", "exchangeRate", "domesticPayment", "internationalPayment", "payer", "payee", "initiatingParty", "payeeBank", "creditorAgentAccount", "payerBank", "debtorAgentAccount", "firstIntermediaryBank", "secondaryIntermediaryBank", "tertiaryIntermediaryBank", "senderCorrespondentBank", "receiverCorrespondentBank", "instructingAgent", "relatedRemitterInfo", "remitterInfo", "instructedAgent", "previousInstructingAgent1", "previousInstructingAgent2", "previousInstructingAgent3", "supplementaryData", "onBehalfOfPayer", "ultimateCreditor", "ultimateDebtor", "optionalHeaderInfo", "relatedReference", "transactionEventType"})
public class SDPPayload {
    @JsonProperty("transactionAmount")
    private java.math.BigDecimal transactionAmount;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("paymentTypeCode")
    private String paymentTypeCode;
    @JsonProperty("chargedTo")
    private String chargedTo;
    @JsonProperty("valueDate")
    private String valueDate;
    @JsonProperty("bankToBank")
    private String bankToBank;
    @JsonProperty("instructionId")
    private String instructionId;
    @JsonProperty("messageTransmissionId")
    private String messageTransmissionId;
    @JsonProperty("transactionId")
    private String transactionId;
    @JsonProperty("endToEndId")
    private String endToEndId;
    @JsonProperty("swiftEndToEndTransactionReference")
    private String swiftEndToEndTransactionReference;
    @JsonProperty("batchId")
    private String batchId;
    @JsonProperty("clientTransactionId")
    private String clientTransactionId;
    @JsonProperty("paymentSourceChannelId")
    private String paymentSourceChannelId;
    @JsonProperty("paymentSourceChannelDescription")
    private String paymentSourceChannelDescription;
    @JsonProperty("paymentStatus")
    private String paymentStatus;
    @JsonProperty("previousPaymentStatus")
    private String previousPaymentStatus;
    @JsonProperty("transactionDirectionName")
    private String transactionDirectionName;
    @JsonProperty("messageFormat")
    private String messageFormat;
    @JsonProperty("paymentType")
    private String paymentType;
    @JsonProperty("clearingSystem")
    private String clearingSystem;
    @JsonProperty("clearingSystemReferenceNumber")
    private String clearingSystemReferenceNumber;
    @JsonProperty("clearingSystemOutputReferenceNumber")
    private String clearingSystemOutputReferenceNumber;
    @JsonProperty("serviceLevelCd")
    private String serviceLevelCd;
    @JsonProperty("transactionReasonCd")
    private String transactionReasonCd;
    @JsonProperty("localInstrumentCode")
    private String localInstrumentCode;
    @JsonProperty("categoryPurpose")
    private String categoryPurpose;
    @JsonProperty("exchangeRate")
    private ExchangeRate exchangeRate;
    @JsonProperty("domesticPayment")
    private PaymentType domesticPayment;
    @JsonProperty("internationalPayment")
    private PaymentType internationalPayment;
    @JsonProperty("payer")
    private Account payer;
    @JsonProperty("payee")
    private Account payee;
    @JsonProperty("initiatingParty")
    private Account initiatingParty;
    @JsonProperty("payeeBank")
    private Bank payeeBank;
    @JsonProperty("creditorAgentAccount")
    private Agent creditorAgentAccount;
    @JsonProperty("payerBank")
    private Bank payerBank;
    @JsonProperty("debtorAgentAccount")
    private Agent debtorAgentAccount;
    @JsonProperty("firstIntermediaryBank")
    private Bank firstIntermediaryBank;
    @JsonProperty("secondaryIntermediaryBank")
    private Bank secondaryIntermediaryBank;
    @JsonProperty("tertiaryIntermediaryBank")
    private Bank tertiaryIntermediaryBank;
    @JsonProperty("senderCorrespondentBank")
    private Bank senderCorrespondentBank;
    @JsonProperty("receiverCorrespondentBank")
    private Bank receiverCorrespondentBank;
    @JsonProperty("instructingAgent")
    private Bank instructingAgent;
    @JsonProperty("relatedRemitterInfo")
    private RelatedRemitterInfo relatedRemitterInfo;
    @JsonProperty("remitterInfo")
    private RemitterInfo remitterInfo;
    @JsonProperty("instructedAgent")
    private Bank instructedAgent;
    @JsonProperty("previousInstructingAgent1")
    private Agent previousInstructingAgent1;
    @JsonProperty("previousInstructingAgent2")
    private Agent previousInstructingAgent2;
    @JsonProperty("previousInstructingAgent3")
    private Agent previousInstructingAgent3;
    @JsonProperty("supplementaryData")
    private SupplementaryData supplementaryData;
    @JsonProperty("onBehalfOfPayer")
    private Account onBehalfOfPayer;
    @JsonProperty("ultimateCreditor")
    private Account ultimateCreditor;
    @JsonProperty("ultimateDebtor")
    private Account ultimateDebtor;
    @JsonProperty("optionalHeaderInfo")
    private OptionalHeaderInfo optionalHeaderInfo;
    @JsonProperty("relatedReference")
    private String relatedReference;
    @JsonProperty("transactionEventType")
    private String transactionEventType;

    public java.math.BigDecimal getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(java.math.BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getPaymentTypeCode() {
        return paymentTypeCode;
    }

    public void setPaymentTypeCode(String paymentTypeCode) {
        this.paymentTypeCode = paymentTypeCode;
    }

    public String getChargedTo() {
        return chargedTo;
    }

    public void setChargedTo(String chargedTo) {
        this.chargedTo = chargedTo;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    public String getBankToBank() {
        return bankToBank;
    }

    public void setBankToBank(String bankToBank) {
        this.bankToBank = bankToBank;
    }

    public String getInstructionId() {
        return instructionId;
    }

    public void setInstructionId(String instructionId) {
        this.instructionId = instructionId;
    }

    public String getMessageTransmissionId() {
        return messageTransmissionId;
    }

    public void setMessageTransmissionId(String messageTransmissionId) {
        this.messageTransmissionId = messageTransmissionId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getEndToEndId() {
        return endToEndId;
    }

    public void setEndToEndId(String endToEndId) {
        this.endToEndId = endToEndId;
    }

    public String getSwiftEndToEndTransactionReference() {
        return swiftEndToEndTransactionReference;
    }

    public void setSwiftEndToEndTransactionReference(String swiftEndToEndTransactionReference) {
        this.swiftEndToEndTransactionReference = swiftEndToEndTransactionReference;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getClientTransactionId() {
        return clientTransactionId;
    }

    public void setClientTransactionId(String clientTransactionId) {
        this.clientTransactionId = clientTransactionId;
    }

    public String getPaymentSourceChannelId() {
        return paymentSourceChannelId;
    }

    public void setPaymentSourceChannelId(String paymentSourceChannelId) {
        this.paymentSourceChannelId = paymentSourceChannelId;
    }

    public String getPaymentSourceChannelDescription() {
        return paymentSourceChannelDescription;
    }

    public void setPaymentSourceChannelDescription(String paymentSourceChannelDescription) {
        this.paymentSourceChannelDescription = paymentSourceChannelDescription;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getPreviousPaymentStatus() {
        return previousPaymentStatus;
    }

    public void setPreviousPaymentStatus(String previousPaymentStatus) {
        this.previousPaymentStatus = previousPaymentStatus;
    }

    public String getTransactionDirectionName() {
        return transactionDirectionName;
    }

    public void setTransactionDirectionName(String transactionDirectionName) {
        this.transactionDirectionName = transactionDirectionName;
    }

    public String getMessageFormat() {
        return messageFormat;
    }

    public void setMessageFormat(String messageFormat) {
        this.messageFormat = messageFormat;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getClearingSystem() {
        return clearingSystem;
    }

    public void setClearingSystem(String clearingSystem) {
        this.clearingSystem = clearingSystem;
    }

    public String getClearingSystemReferenceNumber() {
        return clearingSystemReferenceNumber;
    }

    public void setClearingSystemReferenceNumber(String clearingSystemReferenceNumber) {
        this.clearingSystemReferenceNumber = clearingSystemReferenceNumber;
    }

    public String getClearingSystemOutputReferenceNumber() {
        return clearingSystemOutputReferenceNumber;
    }

    public void setClearingSystemOutputReferenceNumber(String clearingSystemOutputReferenceNumber) {
        this.clearingSystemOutputReferenceNumber = clearingSystemOutputReferenceNumber;
    }

    public String getServiceLevelCd() {
        return serviceLevelCd;
    }

    public void setServiceLevelCd(String serviceLevelCd) {
        this.serviceLevelCd = serviceLevelCd;
    }

    public String getTransactionReasonCd() {
        return transactionReasonCd;
    }

    public void setTransactionReasonCd(String transactionReasonCd) {
        this.transactionReasonCd = transactionReasonCd;
    }

    public String getLocalInstrumentCode() {
        return localInstrumentCode;
    }

    public void setLocalInstrumentCode(String localInstrumentCode) {
        this.localInstrumentCode = localInstrumentCode;
    }

    public String getCategoryPurpose() {
        return categoryPurpose;
    }

    public void setCategoryPurpose(String categoryPurpose) {
        this.categoryPurpose = categoryPurpose;
    }

    public ExchangeRate getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(ExchangeRate exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public PaymentType getDomesticPayment() {
        return domesticPayment;
    }

    public void setDomesticPayment(PaymentType domesticPayment) {
        this.domesticPayment = domesticPayment;
    }

    public PaymentType getInternationalPayment() {
        return internationalPayment;
    }

    public void setInternationalPayment(PaymentType internationalPayment) {
        this.internationalPayment = internationalPayment;
    }

    public Account getPayer() {
        return payer;
    }

    public void setPayer(Account payer) {
        this.payer = payer;
    }

    public Account getPayee() {
        return payee;
    }

    public void setPayee(Account payee) {
        this.payee = payee;
    }

    public Account getInitiatingParty() {
        return initiatingParty;
    }

    public void setInitiatingParty(Account initiatingParty) {
        this.initiatingParty = initiatingParty;
    }

    public Bank getPayeeBank() {
        return payeeBank;
    }

    public void setPayeeBank(Bank payeeBank) {
        this.payeeBank = payeeBank;
    }

    public Agent getCreditorAgentAccount() {
        return creditorAgentAccount;
    }

    public void setCreditorAgentAccount(Agent creditorAgentAccount) {
        this.creditorAgentAccount = creditorAgentAccount;
    }

    public Bank getPayerBank() {
        return payerBank;
    }

    public void setPayerBank(Bank payerBank) {
        this.payerBank = payerBank;
    }

    public Agent getDebtorAgentAccount() {
        return debtorAgentAccount;
    }

    public void setDebtorAgentAccount(Agent debtorAgentAccount) {
        this.debtorAgentAccount = debtorAgentAccount;
    }

    public Bank getFirstIntermediaryBank() {
        return firstIntermediaryBank;
    }

    public void setFirstIntermediaryBank(Bank firstIntermediaryBank) {
        this.firstIntermediaryBank = firstIntermediaryBank;
    }

    public Bank getSecondaryIntermediaryBank() {
        return secondaryIntermediaryBank;
    }

    public void setSecondaryIntermediaryBank(Bank secondaryIntermediaryBank) {
        this.secondaryIntermediaryBank = secondaryIntermediaryBank;
    }

    public Bank getTertiaryIntermediaryBank() {
        return tertiaryIntermediaryBank;
    }

    public void setTertiaryIntermediaryBank(Bank tertiaryIntermediaryBank) {
        this.tertiaryIntermediaryBank = tertiaryIntermediaryBank;
    }

    public Bank getSenderCorrespondentBank() {
        return senderCorrespondentBank;
    }

    public void setSenderCorrespondentBank(Bank senderCorrespondentBank) {
        this.senderCorrespondentBank = senderCorrespondentBank;
    }

    public Bank getReceiverCorrespondentBank() {
        return receiverCorrespondentBank;
    }

    public void setReceiverCorrespondentBank(Bank receiverCorrespondentBank) {
        this.receiverCorrespondentBank = receiverCorrespondentBank;
    }

    public Bank getInstructingAgent() {
        return instructingAgent;
    }

    public void setInstructingAgent(Bank instructingAgent) {
        this.instructingAgent = instructingAgent;
    }

    public RelatedRemitterInfo getRelatedRemitterInfo() {
        return relatedRemitterInfo;
    }

    public void setRelatedRemitterInfo(RelatedRemitterInfo relatedRemitterInfo) {
        this.relatedRemitterInfo = relatedRemitterInfo;
    }

    public RemitterInfo getRemitterInfo() {
        return remitterInfo;
    }

    public void setRemitterInfo(RemitterInfo remitterInfo) {
        this.remitterInfo = remitterInfo;
    }

    public Bank getInstructedAgent() {
        return instructedAgent;
    }

    public void setInstructedAgent(Bank instructedAgent) {
        this.instructedAgent = instructedAgent;
    }

    public Agent getPreviousInstructingAgent1() {
        return previousInstructingAgent1;
    }

    public void setPreviousInstructingAgent1(Agent previousInstructingAgent1) {
        this.previousInstructingAgent1 = previousInstructingAgent1;
    }

    public Agent getPreviousInstructingAgent2() {
        return previousInstructingAgent2;
    }

    public void setPreviousInstructingAgent2(Agent previousInstructingAgent2) {
        this.previousInstructingAgent2 = previousInstructingAgent2;
    }

    public Agent getPreviousInstructingAgent3() {
        return previousInstructingAgent3;
    }

    public void setPreviousInstructingAgent3(Agent previousInstructingAgent3) {
        this.previousInstructingAgent3 = previousInstructingAgent3;
    }

    public SupplementaryData getSupplementaryData() {
        return supplementaryData;
    }

    public void setSupplementaryData(SupplementaryData supplementaryData) {
        this.supplementaryData = supplementaryData;
    }

    public Account getOnBehalfOfPayer() {
        return onBehalfOfPayer;
    }

    public void setOnBehalfOfPayer(Account onBehalfOfPayer) {
        this.onBehalfOfPayer = onBehalfOfPayer;
    }

    public Account getUltimateCreditor() {
        return ultimateCreditor;
    }

    public void setUltimateCreditor(Account ultimateCreditor) {
        this.ultimateCreditor = ultimateCreditor;
    }

    public Account getUltimateDebtor() {
        return ultimateDebtor;
    }

    public void setUltimateDebtor(Account ultimateDebtor) {
        this.ultimateDebtor = ultimateDebtor;
    }

    public OptionalHeaderInfo getOptionalHeaderInfo() {
        return optionalHeaderInfo;
    }

    public void setOptionalHeaderInfo(OptionalHeaderInfo optionalHeaderInfo) {
        this.optionalHeaderInfo = optionalHeaderInfo;
    }

    public String getRelatedReference() {
        return relatedReference;
    }

    public void setRelatedReference(String relatedReference) {
        this.relatedReference = relatedReference;
    }

    public String getTransactionEventType() {
        return transactionEventType;
    }

    public void setTransactionEventType(String transactionEventType) {
        this.transactionEventType = transactionEventType;
    }
}
