package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"remiterId", "methodOfRequest", "electronicValue"})
public class RelatedRemitterInfo {
    @JsonProperty("remiterId")
    private String remiterId;
    @JsonProperty("methodOfRequest")
    private String methodOfRequest;
    @JsonProperty("electronicValue")
    private String electronicValue;

    public String getRemiterId() {
        return remiterId;
    }

    public void setRemiterId(String remiterId) {
        this.remiterId = remiterId;
    }

    public String getMethodOfRequest() {
        return methodOfRequest;
    }

    public void setMethodOfRequest(String methodOfRequest) {
        this.methodOfRequest = methodOfRequest;
    }

    public String getElectronicValue() {
        return electronicValue;
    }

    public void setElectronicValue(String electronicValue) {
        this.electronicValue = electronicValue;
    }
}
