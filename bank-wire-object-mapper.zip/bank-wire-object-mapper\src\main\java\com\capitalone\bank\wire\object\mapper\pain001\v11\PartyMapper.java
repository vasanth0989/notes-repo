package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.IsoDates;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.DateAndPlaceOfBirth1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GenericOrganisationIdentification1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GenericPersonIdentification1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.OrganisationIdentification29;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.OrganisationIdentificationSchemeName1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Party38Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PartyIdentification135;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PersonIdentification13;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PersonIdentificationSchemeName1Choice;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.LongTextPolicy;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.PartyRules;
import com.capitalone.commercial.payx.sdp.payload.model.Account;
import com.capitalone.commercial.payx.sdp.payload.model.CustomerPersonalInfo;
import java.util.Optional;
import java.util.stream.Stream;
import org.jspecify.annotations.Nullable;

/**
 * Payment-object {@link Account} (a party: name, identification, address) to {@link PartyIdentification135}.
 * Used for the initiating party, debtor, creditor and the ultimate parties.
 *
 * <p>Identification is a choice: a party with an organisation identifier (organisation id number, LEI or
 * BIC) is written as {@code OrgId} and its private identifiers are ignored; otherwise its private
 * identification (identification number, date and place of birth) is written as {@code PrvtId}. The V9
 * converter could write both, which the schema forbids.
 */
final class PartyMapper {

    private PartyMapper() {
    }

    static PartyIdentification135 party(Account account, String path, PartyRules rules) {
        var party = new PartyIdentification135();
        name(account, path, rules.namePolicy()).ifPresent(party::setNm);
        PostalAddressMapper.map(account.getAddress(), path + ".address", rules.addressStyle()).ifPresent(party::setPstlAdr);
        identification(account, path).ifPresent(party::setId);
        Text.clean(account.getCountryOfResidence())
                .map(value -> Text.country(value, path + ".countryOfResidence"))
                .ifPresent(party::setCtryOfRes);
        return party;
    }

    /** accountName, or the name parts joined (prefix, first, middle, last, suffix). */
    static Optional<String> name(Account account, String path, LongTextPolicy policy) {
        var name = Text.clean(account.getAccountName()).or(() -> composedName(account));
        return name.flatMap(value -> boundedName(value, path + ".accountName", policy));
    }

    static Optional<String> boundedName(@Nullable String value, String path, LongTextPolicy policy) {
        return switch (policy) {
            case TRUNCATE -> Text.truncated(value, Text.MAX_140);
            case REJECT, SPLIT -> Text.boundedOptional(value, Text.MAX_140, path);
        };
    }

    private static Optional<String> composedName(Account account) {
        var joined = Stream.of(account.getAccountPrefixName(), account.getAccountFirstName(),
                        account.getAccountMiddleName(), account.getAccountLastName(), account.getAccountSuffixName())
                .flatMap(part -> Text.clean(part).stream())
                .reduce((left, right) -> left + " " + right);
        return joined;
    }

    private static Optional<Party38Choice> identification(Account account, String path) {
        var organisation = organisation(account, path);
        if (organisation.isPresent()) {
            var choice = new Party38Choice();
            choice.setOrgId(organisation.get());
            return Optional.of(choice);
        }
        return person(account, path).map(person -> {
            var choice = new Party38Choice();
            choice.setPrvtId(person);
            return choice;
        });
    }

    private static Optional<OrganisationIdentification29> organisation(Account account, String path) {
        var organisation = new OrganisationIdentification29();
        boolean any = false;
        var bic = Text.clean(account.getBankIdentifierCode()).map(v -> Text.bic(v, path + ".bankIdentifierCode"));
        if (bic.isPresent()) {
            organisation.setAnyBIC(bic.get());
            any = true;
        }
        var lei = Text.clean(account.getLegalEntityIdentifier()).map(v -> Text.lei(v, path + ".legalEntityIdentifier"));
        if (lei.isPresent()) {
            organisation.setLEI(lei.get());
            any = true;
        }
        var number = Text.clean(account.getOrganizationIdentificationNumber());
        if (number.isPresent()) {
            var other = new GenericOrganisationIdentification1();
            other.setId(Text.bounded(number.get(), Text.MAX_35, path + ".organizationIdentificationNumber"));
            Text.clean(account.getOrganizationIdentificationNumberType()).ifPresent(type -> {
                var scheme = new OrganisationIdentificationSchemeName1Choice();
                var upper = Text.upper(type);
                if (Text.isExternalCode(upper)) {
                    scheme.setCd(upper);
                } else {
                    scheme.setPrtry(Text.bounded(type, Text.MAX_35, path + ".organizationIdentificationNumberType"));
                }
                other.setSchmeNm(scheme);
            });
            Text.boundedOptional(account.getIssuer(), Text.MAX_35, path + ".issuer").ifPresent(other::setIssr);
            organisation.getOthr().add(other);
            any = true;
        }
        return any ? Optional.of(organisation) : Optional.empty();
    }

    private static Optional<PersonIdentification13> person(Account account, String path) {
        var person = new PersonIdentification13();
        boolean any = false;
        var number = Text.clean(account.getIdentificationNumber());
        if (number.isPresent()) {
            var other = new GenericPersonIdentification1();
            other.setId(Text.bounded(number.get(), Text.MAX_35, path + ".identificationNumber"));
            Text.clean(account.getIdentificationNumberType()).ifPresent(type -> {
                var scheme = new PersonIdentificationSchemeName1Choice();
                var upper = Text.upper(type);
                if (Text.isExternalCode(upper)) {
                    scheme.setCd(upper);
                } else {
                    scheme.setPrtry(Text.bounded(type, Text.MAX_35, path + ".identificationNumberType"));
                }
                other.setSchmeNm(scheme);
            });
            Text.boundedOptional(account.getIssuer(), Text.MAX_35, path + ".issuer").ifPresent(other::setIssr);
            person.getOthr().add(other);
            any = true;
        }
        var birth = dateAndPlaceOfBirth(account.getCustomerPersonalInfo(), path + ".customerPersonalInfo");
        if (birth.isPresent()) {
            person.setDtAndPlcOfBirth(birth.get());
            any = true;
        }
        return any ? Optional.of(person) : Optional.empty();
    }

    /** Only when all three mandatory parts are present; a partial record is left out rather than written invalid. */
    private static Optional<DateAndPlaceOfBirth1> dateAndPlaceOfBirth(@Nullable CustomerPersonalInfo info, String path) {
        if (info == null || Text.isBlank(info.getDateOfBirth()) || Text.isBlank(info.getCityOfBirth())
                || Text.isBlank(info.getCountryOfBirth())) {
            return Optional.empty();
        }
        var birth = new DateAndPlaceOfBirth1();
        birth.setBirthDt(IsoDates.date(IsoDates.parse(info.getDateOfBirth(), path + ".dateOfBirth")));
        birth.setCityOfBirth(Text.bounded(info.getCityOfBirth(), Text.MAX_35, path + ".cityOfBirth"));
        birth.setCtryOfBirth(Text.country(info.getCountryOfBirth(), path + ".countryOfBirth"));
        return Optional.of(birth);
    }
}
