package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"unstructuredInfo", "remitterId", "relatedDate", "relatedTime", "invoicerIdentification", "invoiceeIdentification", "rtpRemitterId", "rtpRelatedDate", "documentCode", "documentProprietary"})
public class RemitterInfo {
    @JsonProperty("unstructuredInfo")
    private String unstructuredInfo;
    @JsonProperty("remitterId")
    private String remitterId;
    @JsonProperty("relatedDate")
    private String relatedDate;
    @JsonProperty("relatedTime")
    private String relatedTime;
    @JsonProperty("invoicerIdentification")
    private String invoicerIdentification;
    @JsonProperty("invoiceeIdentification")
    private String invoiceeIdentification;
    @JsonProperty("rtpRemitterId")
    private String rtpRemitterId;
    @JsonProperty("rtpRelatedDate")
    private String rtpRelatedDate;
    @JsonProperty("documentCode")
    private String documentCode;
    @JsonProperty("documentProprietary")
    private String documentProprietary;

    public String getUnstructuredInfo() {
        return unstructuredInfo;
    }

    public void setUnstructuredInfo(String unstructuredInfo) {
        this.unstructuredInfo = unstructuredInfo;
    }

    public String getRemitterId() {
        return remitterId;
    }

    public void setRemitterId(String remitterId) {
        this.remitterId = remitterId;
    }

    public String getRelatedDate() {
        return relatedDate;
    }

    public void setRelatedDate(String relatedDate) {
        this.relatedDate = relatedDate;
    }

    public String getRelatedTime() {
        return relatedTime;
    }

    public void setRelatedTime(String relatedTime) {
        this.relatedTime = relatedTime;
    }

    public String getInvoicerIdentification() {
        return invoicerIdentification;
    }

    public void setInvoicerIdentification(String invoicerIdentification) {
        this.invoicerIdentification = invoicerIdentification;
    }

    public String getInvoiceeIdentification() {
        return invoiceeIdentification;
    }

    public void setInvoiceeIdentification(String invoiceeIdentification) {
        this.invoiceeIdentification = invoiceeIdentification;
    }

    public String getRtpRemitterId() {
        return rtpRemitterId;
    }

    public void setRtpRemitterId(String rtpRemitterId) {
        this.rtpRemitterId = rtpRemitterId;
    }

    public String getRtpRelatedDate() {
        return rtpRelatedDate;
    }

    public void setRtpRelatedDate(String rtpRelatedDate) {
        this.rtpRelatedDate = rtpRelatedDate;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getDocumentProprietary() {
        return documentProprietary;
    }

    public void setDocumentProprietary(String documentProprietary) {
        this.documentProprietary = documentProprietary;
    }
}
