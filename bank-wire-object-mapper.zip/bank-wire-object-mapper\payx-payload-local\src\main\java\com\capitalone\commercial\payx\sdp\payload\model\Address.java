package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"addressLine1", "addressLine2", "addressLine3", "addressLine4", "buildingName", "city", "countryCode", "countryName", "districtName", "floor", "postalBox", "proxyAccountIdentification", "streetName", "buildingNumber", "postalCode", "room", "townName", "stateProvince", "stateCode", "department", "subDepartment", "townLocationName"})
public class Address {
    @JsonProperty("addressLine1")
    private String addressLine1;
    @JsonProperty("addressLine2")
    private String addressLine2;
    @JsonProperty("addressLine3")
    private String addressLine3;
    @JsonProperty("addressLine4")
    private String addressLine4;
    @JsonProperty("buildingName")
    private String buildingName;
    @JsonProperty("city")
    private String city;
    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("countryName")
    private String countryName;
    @JsonProperty("districtName")
    private String districtName;
    @JsonProperty("floor")
    private String floor;
    @JsonProperty("postalBox")
    private String postalBox;
    @JsonProperty("proxyAccountIdentification")
    private String proxyAccountIdentification;
    @JsonProperty("streetName")
    private String streetName;
    @JsonProperty("buildingNumber")
    private String buildingNumber;
    @JsonProperty("postalCode")
    private String postalCode;
    @JsonProperty("room")
    private String room;
    @JsonProperty("townName")
    private String townName;
    @JsonProperty("stateProvince")
    private String stateProvince;
    @JsonProperty("stateCode")
    private String stateCode;
    @JsonProperty("department")
    private String department;
    @JsonProperty("subDepartment")
    private String subDepartment;
    @JsonProperty("townLocationName")
    private String townLocationName;

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getAddressLine3() {
        return addressLine3;
    }

    public void setAddressLine3(String addressLine3) {
        this.addressLine3 = addressLine3;
    }

    public String getAddressLine4() {
        return addressLine4;
    }

    public void setAddressLine4(String addressLine4) {
        this.addressLine4 = addressLine4;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getPostalBox() {
        return postalBox;
    }

    public void setPostalBox(String postalBox) {
        this.postalBox = postalBox;
    }

    public String getProxyAccountIdentification() {
        return proxyAccountIdentification;
    }

    public void setProxyAccountIdentification(String proxyAccountIdentification) {
        this.proxyAccountIdentification = proxyAccountIdentification;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getBuildingNumber() {
        return buildingNumber;
    }

    public void setBuildingNumber(String buildingNumber) {
        this.buildingNumber = buildingNumber;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getTownName() {
        return townName;
    }

    public void setTownName(String townName) {
        this.townName = townName;
    }

    public String getStateProvince() {
        return stateProvince;
    }

    public void setStateProvince(String stateProvince) {
        this.stateProvince = stateProvince;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getSubDepartment() {
        return subDepartment;
    }

    public void setSubDepartment(String subDepartment) {
        this.subDepartment = subDepartment;
    }

    public String getTownLocationName() {
        return townLocationName;
    }

    public void setTownLocationName(String townLocationName) {
        this.townLocationName = townLocationName;
    }
}
