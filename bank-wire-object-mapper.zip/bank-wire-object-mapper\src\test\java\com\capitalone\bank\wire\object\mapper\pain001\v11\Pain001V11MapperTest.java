package com.capitalone.bank.wire.object.mapper.pain001.v11;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.MappingProblem;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ChargeBearerType1Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ExchangeRateType1Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentMethod3Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Priority2Code;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.DebtorAgentSource;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.FxAmountStyle;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

/** Block-by-block checks of the mapping against the four valid samples. */
class Pain001V11MapperTest {

    private final Pain001V11Mapper mapper = new Pain001V11Mapper(Samples.context());

    @Test
    void groupHeaderCarriesMessageIdCreationTimeControlSumAndInitiatingParty() {
        var header = mapper.map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn().getGrpHdr();

        assertThat(header.getMsgId()).isEqualTo("DFSC2026102313560501");
        assertThat(header.getCreDtTm().toXMLFormat()).isEqualTo("2026-10-23T13:56:05.000Z");
        assertThat(header.getNbOfTxs()).isEqualTo("1");
        assertThat(header.getCtrlSum()).isEqualByComparingTo("48750.00");
        assertThat(header.getInitgPty().getNm()).isEqualTo("Discover Bank");
        assertThat(header.getInitgPty().getCtryOfRes()).isEqualTo("US");
        // Not in the FIS samples, so off by default.
        assertThat(header.getInitnSrc()).isNull();
    }

    @Test
    void initiationSourceIsWrittenWhenTheHeaderRuleIsOn() {
        var rules = MappingRules.defaults().withHeader(new MappingRules.HeaderRules(true));
        var header = new Pain001V11Mapper(Samples.context().withRules(rules))
                .map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn().getGrpHdr();

        assertThat(header.getInitnSrc().getNm()).isEqualTo("Payment Exchange Wire Rail II");
        assertThat(header.getInitnSrc().getPrvdr()).isEqualTo("Capital One");
    }

    @Test
    void paymentInformationMapsTheDebitSideOfAUsdWire() {
        var instruction = mapper.map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn().getPmtInf().getFirst();

        assertThat(instruction.getPmtInfId()).isEqualTo("DFSC2026102313560501");
        assertThat(instruction.getPmtMtd()).isEqualTo(PaymentMethod3Code.TRF);
        assertThat(instruction.isBtchBookg()).isFalse();
        assertThat(instruction.getCtrlSum()).isEqualByComparingTo("48750.00");
        assertThat(instruction.getReqdExctnDt().getDt().toXMLFormat()).isEqualTo("2026-10-23");
        assertThat(instruction.getReqdExctnDt().getDtTm()).isNull();

        var debtor = instruction.getDbtr();
        assertThat(debtor.getNm()).isEqualTo("Pinnacle Logistics Group LLC");
        assertThat(debtor.getPstlAdr().getTwnNm()).isEqualTo("Wilmington");
        assertThat(debtor.getPstlAdr().getCtrySubDvsn()).isEqualTo("DE");
        assertThat(debtor.getPstlAdr().getCtry()).isEqualTo("US");
        assertThat(debtor.getId().getOrgId().getOthr().getFirst().getId()).isEqualTo("510493877");
        assertThat(debtor.getId().getOrgId().getOthr().getFirst().getSchmeNm().getCd()).isEqualTo("TXID");
        assertThat(debtor.getId().getPrvtId()).isNull();
        assertThat(debtor.getCtryOfRes()).isEqualTo("US");

        var account = instruction.getDbtrAcct();
        assertThat(account.getId().getOthr().getId()).isEqualTo("tok_7f2c9a1e4b");
        // FIS debtor account: no scheme name, type from the account id type (DDA is a current account).
        assertThat(account.getId().getOthr().getSchmeNm()).isNull();
        assertThat(account.getTp().getCd()).isEqualTo("CACC");
        assertThat(account.getCcy()).isEqualTo("USD");

        var agent = instruction.getDbtrAgt().getFinInstnId();
        assertThat(agent.getClrSysMmbId().getClrSysId().getCd()).isEqualTo("USABA");
        assertThat(agent.getClrSysMmbId().getMmbId()).isEqualTo("031100649");
        assertThat(agent.getNm()).isEqualTo("Discover Bank");
        assertThat(instruction.getDbtrAgtAcct()).isNull();
    }

    @Test
    void creditTransferMapsTheCreditSideOfAUsdWire() {
        var transaction = mapper.map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn().getPmtInf().getFirst()
                .getCdtTrfTxInf().getFirst();

        assertThat(transaction.getPmtId().getInstrId()).isEqualTo("DFSC2026102313560501");
        assertThat(transaction.getPmtId().getEndToEndId()).isEqualTo("PLG-AP-2026-10-0931");
        assertThat(transaction.getPmtId().getUETR()).isEqualTo("699756b7-886a-4a70-8180-3e60e68dfd3e");
        assertThat(transaction.getPmtTpInf().getInstrPrty()).isEqualTo(Priority2Code.HIGH);
        // FIS carries the payment type code in localInstrument.code.
        assertThat(transaction.getPmtTpInf().getLclInstrm().getCd()).isEqualTo("CTRC");
        assertThat(transaction.getPmtTpInf().getLclInstrm().getPrtry()).isNull();
        assertThat(transaction.getPmtTpInf().getCtgyPurp().getCd()).isEqualTo("SUPP");
        assertThat(transaction.getAmt().getInstdAmt().getValue()).isEqualByComparingTo("48750.00");
        assertThat(transaction.getAmt().getInstdAmt().getCcy()).isEqualTo("USD");
        assertThat(transaction.getAmt().getEqvtAmt()).isNull();
        assertThat(transaction.getXchgRateInf()).isNull();
        assertThat(transaction.getChrgBr()).isEqualTo(ChargeBearerType1Code.SHAR);
        assertThat(transaction.getCdtrAgt().getFinInstnId().getClrSysMmbId().getMmbId()).isEqualTo("021000021");
        assertThat(transaction.getCdtr().getNm()).isEqualTo("Atlas Freight Services Inc");
        assertThat(transaction.getCdtrAcct().getId().getOthr().getId()).isEqualTo("488230117");
        // FIS creditor account: proprietary scheme name, no type.
        assertThat(transaction.getCdtrAcct().getId().getOthr().getSchmeNm().getPrtry()).isEqualTo("Proprietary");
        assertThat(transaction.getCdtrAcct().getTp()).isNull();
        assertThat(transaction.getCdtrAcct().getCcy()).isEqualTo("USD");
        assertThat(transaction.getPurp().getCd()).isEqualTo("SUPP");
        assertThat(transaction.getRmtInf().getUstrd()).containsExactly("INVOICE AFS-INV-77215 DATED 2026-10-01");
        assertThat(transaction.getSplmtryData()).hasSize(1);
    }

    @Test
    void accountStyleCanFollowTheIsoCodesOrTheV9Converter() {
        var iso = MappingRules.defaults().withAccounts(MappingRules.AccountRules.defaults()
                .withDebtor(MappingRules.AccountScheme.BBAN, MappingRules.AccountType.CACC)
                .withCreditor(MappingRules.AccountScheme.BBAN, MappingRules.AccountType.CACC));
        var instruction = new Pain001V11Mapper(Samples.context().withRules(iso))
                .map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn().getPmtInf().getFirst();
        assertThat(instruction.getDbtrAcct().getId().getOthr().getSchmeNm().getCd()).isEqualTo("BBAN");
        assertThat(instruction.getCdtTrfTxInf().getFirst().getCdtrAcct().getTp().getCd()).isEqualTo("CACC");

        var v9 = MappingRules.defaults().withAccounts(MappingRules.AccountRules.defaults()
                .withDebtor(MappingRules.AccountScheme.NONE, MappingRules.AccountType.PROPRIETARY_RAW));
        var debtorAccount = new Pain001V11Mapper(Samples.context().withRules(v9))
                .map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn().getPmtInf().getFirst().getDbtrAcct();
        assertThat(debtorAccount.getTp().getPrtry()).isEqualTo("DDA");
        assertThat(debtorAccount.getId().getOthr().getSchmeNm()).isNull();
    }

    @Test
    void fisSupplementsCarryTheTraceIdAndTheInternationalFlag() {
        var domestic = mapper.map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn();
        var international = mapper.map(Samples.load("corp-fx-eur-wire")).getCstmrCdtTrfInitn();

        var transactionSupplement = (org.w3c.dom.Element) domestic.getPmtInf().getFirst().getCdtTrfTxInf().getFirst()
                .getSplmtryData().getFirst().getEnvlp().getAny();
        assertThat(transactionSupplement.getLocalName()).isEqualTo("transactionInformationSupplement");
        assertThat(transactionSupplement.getTextContent()).isEqualTo("DFSC2026102313560501");

        var domesticSupplement = (org.w3c.dom.Element) domestic.getSplmtryData().getFirst().getEnvlp().getAny();
        assertThat(domesticSupplement.getElementsByTagNameNS("*", "internationalPayment").item(0).getTextContent()).isEqualTo("N");
        assertThat(domesticSupplement.getElementsByTagNameNS("*", "templateName").getLength()).isZero();
        var internationalSupplement = (org.w3c.dom.Element) international.getSplmtryData().getFirst().getEnvlp().getAny();
        assertThat(internationalSupplement.getElementsByTagNameNS("*", "internationalPayment").item(0).getTextContent()).isEqualTo("Y");

        var off = MappingRules.defaults().withSupplements(MappingRules.SupplementRules.defaults().withEmitFisSupplements(false));
        var plain = new Pain001V11Mapper(Samples.context().withRules(off)).map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn();
        assertThat(plain.getSplmtryData()).isEmpty();
        assertThat(plain.getPmtInf().getFirst().getCdtTrfTxInf().getFirst().getSplmtryData()).isEmpty();
    }

    @Test
    void bankToBankTextIsSplitIntoInstructionsOf140Characters() {
        var transaction = mapper.map(Samples.load("gpn-usd-wire")).getCstmrCdtTrfInitn().getPmtInf().getFirst()
                .getCdtTrfTxInf().getFirst();

        var instructions = transaction.getInstrForCdtrAgt();
        assertThat(instructions).hasSize(2);
        assertThat(instructions.getFirst().getInstrInf()).hasSize(140).startsWith("/BNF/INVOICE");
        assertThat(instructions.get(1).getInstrInf()).isEqualTo("IS PAYMENT BEFORE 5PM");
        assertThat(instructions.getFirst().getCd()).isNull();
    }

    @Test
    void fxWireUsesTheEquivalentAmountAndCarriesTheExchangeRate() {
        var document = mapper.map(Samples.load("corp-fx-eur-wire"));
        var instruction = document.getCstmrCdtTrfInitn().getPmtInf().getFirst();
        var transaction = instruction.getCdtTrfTxInf().getFirst();

        assertThat(document.getCstmrCdtTrfInitn().getGrpHdr().getCtrlSum()).isEqualByComparingTo("27180.45");
        assertThat(transaction.getAmt().getInstdAmt()).isNull();
        assertThat(transaction.getAmt().getEqvtAmt().getAmt().getValue()).isEqualByComparingTo("27180.45");
        assertThat(transaction.getAmt().getEqvtAmt().getAmt().getCcy()).isEqualTo("USD");
        assertThat(transaction.getAmt().getEqvtAmt().getCcyOfTrf()).isEqualTo("EUR");
        assertThat(transaction.getXchgRateInf().getXchgRate()).isEqualByComparingTo("1.0862");
        assertThat(transaction.getXchgRateInf().getRateTp()).isEqualTo(ExchangeRateType1Code.AGRD);
        assertThat(transaction.getXchgRateInf().getCtrctId()).isEqualTo("ACBSFX-884120");
        assertThat(transaction.getChrgBr()).isEqualTo(ChargeBearerType1Code.DEBT);
        assertThat(transaction.getPmtTpInf().getSvcLvl().getFirst().getCd()).isEqualTo("URGP");

        assertThat(instruction.getDbtr().getId().getOrgId().getLEI()).isEqualTo("5493001KJTIIGC8Y1R12");
        assertThat(instruction.getDbtr().getPstlAdr().getAdrLine()).containsExactly("2500 Lake Cook Road", "Riverwoods IL 60015 US");
        assertThat(instruction.getDbtrAgt().getFinInstnId().getBICFI()).isEqualTo("DISCUS44");
        assertThat(instruction.getDbtrAgt().getFinInstnId().getClrSysMmbId().getMmbId()).isEqualTo("031100649");

        assertThat(transaction.getCdtrAcct().getId().getIBAN()).isEqualTo("DE89370400440532013000");
        assertThat(transaction.getCdtrAcct().getId().getOthr()).isNull();
        assertThat(transaction.getCdtrAcct().getCcy()).isEqualTo("EUR");
        assertThat(transaction.getCdtrAgt().getFinInstnId().getBICFI()).isEqualTo("COBADEFFXXX");
        assertThat(transaction.getCdtrAgt().getFinInstnId().getLEI()).isEqualTo("851WYGNLUQLFZBSYGB56");
        assertThat(transaction.getIntrmyAgt1().getFinInstnId().getBICFI()).isEqualTo("BKTRUS33");
        assertThat(transaction.getIntrmyAgt1Acct().getId().getOthr().getId()).isEqualTo("04-123-456");
        assertThat(transaction.getRmtInf().getUstrd()).hasSize(2);
        assertThat(transaction.getRmtInf().getUstrd().getFirst()).hasSize(140);
    }

    @Test
    void fxWireWithInstructedAmountOnlyStyleWritesTheForeignAmount() {
        var rules = MappingRules.defaults().withAmounts(new MappingRules.AmountRules(FxAmountStyle.INSTRUCTED_AMOUNT_ONLY));
        var transaction = new Pain001V11Mapper(Samples.context().withRules(rules))
                .map(Samples.load("corp-fx-eur-wire")).getCstmrCdtTrfInitn().getPmtInf().getFirst().getCdtTrfTxInf().getFirst();

        assertThat(transaction.getAmt().getEqvtAmt()).isNull();
        assertThat(transaction.getAmt().getInstdAmt().getValue()).isEqualByComparingTo("25023.52");
        assertThat(transaction.getAmt().getInstdAmt().getCcy()).isEqualTo("EUR");
    }

    @Test
    void fxWireWithoutADebitAmountInstructsTheForeignAmountRoundedToTheMinorUnit() {
        var document = mapper.map(Samples.load("fx-instructed-amount-only"));
        var transaction = document.getCstmrCdtTrfInitn().getPmtInf().getFirst().getCdtTrfTxInf().getFirst();

        assertThat(transaction.getAmt().getInstdAmt().getValue()).isEqualByComparingTo(new BigDecimal("3500000"));
        assertThat(transaction.getAmt().getInstdAmt().getValue().scale()).isZero();
        assertThat(transaction.getAmt().getInstdAmt().getCcy()).isEqualTo("JPY");
        assertThat(document.getCstmrCdtTrfInitn().getGrpHdr().getCtrlSum()).isEqualByComparingTo("3500000");
        assertThat(transaction.getXchgRateInf().getRateTp()).isEqualTo(ExchangeRateType1Code.SPOT);
        assertThat(transaction.getCdtrAgt().getFinInstnId().getBICFI()).isEqualTo("BOTKJPJT");
        assertThat(document.getCstmrCdtTrfInitn().getPmtInf().getFirst().getDbtrAgt().getFinInstnId().getBICFI())
                .isEqualTo("DISCUS44XXX");
        assertThat(document.getCstmrCdtTrfInitn().getPmtInf().getFirst().getDbtrAcct().getCcy()).isEqualTo("USD");
    }

    @Test
    void onBehalfOfWireComposesNamesMapsPrivateIdentificationAndUltimateParties() {
        var document = mapper.map(Samples.load("corp-on-behalf-of-wire"));
        var instruction = document.getCstmrCdtTrfInitn().getPmtInf().getFirst();
        var transaction = instruction.getCdtTrfTxInf().getFirst();

        assertThat(instruction.getDbtr().getNm()).isEqualTo("Dr Maria Elena Santos");
        var privateId = instruction.getDbtr().getId().getPrvtId();
        assertThat(instruction.getDbtr().getId().getOrgId()).isNull();
        assertThat(privateId.getOthr().getFirst().getId()).isEqualTo("P123456789");
        assertThat(privateId.getOthr().getFirst().getSchmeNm().getCd()).isEqualTo("CCPT");
        assertThat(privateId.getOthr().getFirst().getIssr()).isEqualTo("US Department of State");
        assertThat(privateId.getDtAndPlcOfBirth().getBirthDt().toXMLFormat()).isEqualTo("1981-04-17");
        assertThat(privateId.getDtAndPlcOfBirth().getCityOfBirth()).isEqualTo("San Juan");
        assertThat(privateId.getDtAndPlcOfBirth().getCtryOfBirth()).isEqualTo("PR");
        assertThat(instruction.getDbtr().getPstlAdr().getCtrySubDvsn()).isEqualTo("FL");
        assertThat(instruction.getDbtr().getPstlAdr().getFlr()).isEqualTo("22");

        // A nine-digit bankCode without a system identifier is read as USABA.
        assertThat(instruction.getDbtrAgt().getFinInstnId().getClrSysMmbId().getClrSysId().getCd()).isEqualTo("USABA");
        assertThat(instruction.getDbtrAgtAcct().getId().getOthr().getId()).isEqualTo("DISC-NOSTRO-0021");

        assertThat(transaction.getPmtId().getInstrId()).isEqualTo("DFSB2026110408220013");
        assertThat(transaction.getPmtId().getEndToEndId()).isEqualTo("NOTPROVIDED");
        assertThat(transaction.getPmtTpInf().getLclInstrm().getCd()).isEqualTo("BTRC");
        assertThat(transaction.getChrgBr()).isEqualTo(ChargeBearerType1Code.SHAR);
        assertThat(transaction.getUltmtDbtr().getNm()).isEqualTo("Santos Family Trust");
        assertThat(transaction.getUltmtDbtr().getId().getOrgId().getOthr().getFirst().getId()).isEqualTo("47-1234567");
        assertThat(transaction.getUltmtCdtr().getNm()).isEqualTo("Seaside Properties Ltd");
        // Legacy single-letter account type D is not an IBAN.
        assertThat(transaction.getCdtrAcct().getId().getOthr().getId()).isEqualTo("9900112233");
        assertThat(transaction.getCdtr().getPstlAdr().getAdrLine()).hasSize(3);
        assertThat(transaction.getCdtrAgtAcct().getId().getOthr().getId()).isEqualTo("4300001122");
        assertThat(transaction.getAmt().getInstdAmt().getValue()).isEqualByComparingTo("1250000.00");
        // Slash clean-up is off by default, so the TMOBS text keeps its slashes.
        assertThat(transaction.getInstrForCdtrAgt().getFirst().getInstrInf()).startsWith("/ACC/");
        assertThat(transaction.getRmtInf()).isNull();
    }

    @Test
    void debtorAgentCanBeTakenFromTheContextInstead() {
        var rules = MappingRules.defaults().withParties(MappingRules.PartyRules.defaults().withDebtorAgentSource(DebtorAgentSource.CONTEXT));
        var instruction = new Pain001V11Mapper(Samples.context().withRules(rules))
                .map(Samples.load("corp-fx-eur-wire")).getCstmrCdtTrfInitn().getPmtInf().getFirst();

        assertThat(instruction.getDbtrAgt().getFinInstnId().getBICFI()).isNull();
        assertThat(instruction.getDbtrAgt().getFinInstnId().getClrSysMmbId().getMmbId()).isEqualTo("031100649");
        assertThat(instruction.getDbtrAgt().getFinInstnId().getNm()).isEqualTo("Discover Bank");
    }

    @Test
    void everyValidSampleProducesSchemaValidXml() {
        for (var name : new String[] {"gpn-usd-wire", "corp-fx-eur-wire", "corp-on-behalf-of-wire", "fx-instructed-amount-only",
                "fis-bank-transfer", "fis-customer-transfer", "fis-intermediary-customer-transfer", "fis-drawdown-structured"}) {
            var xml = mapper.mapToXml(Samples.load(name));
            assertThat(xml).startsWith("<?xml").contains("urn:iso:std:iso:20022:tech:xsd:pain.001.001.11");
            new Pain001V11Marshaller().validate(xml);
        }
    }

    @Test
    void invalidPaymentIsRejectedWithEveryReasonAndNoValues() {
        assertThatThrownBy(() -> mapper.map(Samples.load("invalid-missing-required-fields")))
                .isInstanceOf(MappingException.class)
                .satisfies(e -> {
                    var problems = ((MappingException) e).problems();
                    assertThat(problems).extracting(MappingProblem::path).containsExactlyInAnyOrder(
                            "payload.clientTransactionId", "payload.clientTransactionId", "payload.endToEndId",
                            "payload.swiftEndToEndTransactionReference", "payload.valueDate", "payload.currencyCode",
                            "payload.transactionAmount", "payload.payer.accountNumber", "payload.payee",
                            "payload.payeeBank");
                    assertThat(e.getMessage()).doesNotContain("Pinnacle", "US DOLLARS", "10/23/2026");
                });
    }

    @Test
    void unknownChargeBearerIsRejectedByDefaultAndDefaultedWhenTheRuleSaysSo() {
        var payload = Samples.load("gpn-usd-wire");
        payload.setChargedTo("BENEFICIARY");

        assertThatThrownBy(() -> mapper.map(payload))
                .isInstanceOf(MappingException.class)
                .hasMessageContaining("payload.chargedTo");

        var lenient = MappingRules.defaults().withCodes(
                MappingRules.CodeRules.defaults().withChargeBearerPolicy(MappingRules.UnknownCodePolicy.USE_DEFAULT));
        var transaction = new Pain001V11Mapper(Samples.context().withRules(lenient)).map(payload)
                .getCstmrCdtTrfInitn().getPmtInf().getFirst().getCdtTrfTxInf().getFirst();
        assertThat(transaction.getChrgBr()).isEqualTo(ChargeBearerType1Code.SHAR);
    }

    @Test
    void nameOver140CharactersIsRejectedUnlessTruncationIsAllowed() {
        var payload = Samples.load("gpn-usd-wire");
        payload.getPayee().setAccountName("A".repeat(141));

        assertThatThrownBy(() -> mapper.map(payload))
                .isInstanceOf(MappingException.class)
                .hasMessageContaining("payload.payee.accountName")
                .hasMessageNotContaining("AAAA");

        var truncating = MappingRules.defaults().withParties(
                MappingRules.PartyRules.defaults().withNamePolicy(MappingRules.LongTextPolicy.TRUNCATE));
        var creditor = new Pain001V11Mapper(Samples.context().withRules(truncating)).map(payload)
                .getCstmrCdtTrfInitn().getPmtInf().getFirst().getCdtTrfTxInf().getFirst().getCdtr();
        assertThat(creditor.getNm()).hasSize(140);
    }
}
