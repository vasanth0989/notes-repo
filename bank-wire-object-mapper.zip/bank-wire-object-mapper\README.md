# bank-wire-object-mapper

Maps the Payment Exchange payment object (`SDPPayload`) for an outbound GPN or corporate wire to an
ISO 20022 **pain.001.001.11** customer credit transfer initiation, as schema-valid XML. Used inside
Wire Rail II, which receives the payment from the PayX integration service after OFAC, converts it with
this library, detokenises the account numbers, calls the FIS OPF API and returns OPF's HTTP code.

The XML is the Phase 2 asset: what Capital One will send to the banks directly once OPF is gone. For
Phase 1 the same mapped data is rendered as the FIS JSON (pain.001.001.11 inside a business application
header) by Wire Rail II; that rendering is a placeholder here, see "What is not in this library".

Java 21, Gradle, Jakarta XML Binding. No Spring: the library is plain Java and is wired into a Spring
service as one bean (`new Pain001V11Mapper(context)`).

## Build and run

```bash
./gradlew build            # generates the V11 classes from the XSD, compiles, runs the tests
./gradlew renderSamples    # maps every sample payment object to XML in build/samples and validates it
./gradlew renderSamples -Psample=gpn-usd-wire
./gradlew publishToMavenLocal
```

On the Capital One network put these in `~/.gradle/gradle.properties` (never in the repository):

```
artifactoryUrl=https://artifactory.cloud.capitalone.com/artifactory/<virtual-repo>
artifactoryUser=<EID>
artifactoryToken=<token>
payxPayloadVersion=2.54-SNAPSHOT
```

`payxPayloadVersion` switches the payment object dependency to the real library
`com.capitalone.commercial:payx-payload`. Without it the build uses `payx-payload-local`, a hand-written
stand-in with the same package, class and accessor names (`com.capitalone.commercial.payx.sdp.payload.model`)
limited to the fields a wire uses, so the library builds and tests anywhere. Delete that module once the
real artifact is used everywhere; nothing else references it.

A JDK 21 is used through the Gradle toolchain; if none is installed, the Foojay resolver downloads one.

## Using it

```java
var context = new MappingContext(
        new MappingContext.InitiatingParty("Discover Bank", null, "US"),
        new MappingContext.FinancialInstitution(null, "USABA", "031100649", "Discover Bank"),
        new MappingContext.InitiationSource("Payment Exchange Wire Rail II", "Capital One", "1"),
        MappingContext.FisExtension.defaults(),   // instMethod, templateName, accountType, waiveFees
        Clock.systemUTC(),
        MappingRules.defaults());
var mapper = new Pain001V11Mapper(context);

String xml = mapper.mapToXml(payload);        // schema-validated pain.001.001.11
Document document = mapper.map(payload);      // the JAXB tree, for the JSON rendering in Wire Rail II
```

A payment that cannot be mapped throws `MappingException`. Its `problems()` list every reason at once,
each with the payment-object path that caused it (`payload.payee.accountNumber: is required`). Messages
never contain field values, so they are safe to log; the library itself logs nothing.

## How the payment object becomes pain.001

1. **Receive and validate.** The service receives the enterprise message from PayX; its `paymentObject`
   is the `SDPPayload` (the JSON is deserialised into the generated payment object classes). The mapper
   checks up front what pain.001 will need: a message id, an end-to-end id and a UETR (each at most 35
   characters, the UETR a lower-case UUID v4), a value date in `yyyy-MM-dd`, a positive amount with an
   ISO currency, a payer with an account number and a name, a payee with an account number and a name, a
   payee bank with a BIC or a clearing system member id, and a debtor agent. Any miss rejects the payment
   with the full list of reasons before anything is built.
2. **Group header.** Message id from `clientTransactionId`; creation time now, UTC, milliseconds; one
   transaction; control sum equal to the amount written; initiating party from the payment object when it
   has a name, otherwise the fixed party from the context (Discover Bank); initiation source from the
   context.
3. **Payment information (debit side).** Payment information id from `clientTransactionId`; method TRF;
   no batch booking; requested execution date from `valueDate` as a date only; debtor from `payer`
   (name, structured address, organisation or private identification, country of residence); debtor
   account from `payer` (IBAN, or the account number as `Othr/Id` with scheme BBAN and type CACC, with
   the account's currency or else the payment currency); debtor agent from `payerBank` (BIC, clearing
   system member id, LEI, name, address); debtor agent account from `debtorAgentAccount.account`.
4. **Credit transfer transaction (credit side).** Instruction id from `instructionId`, end-to-end id
   from `endToEndId`, UETR from `swiftEndToEndTransactionReference`; priority HIGH, local instrument
   from `localInstrumentCode` else `paymentTypeCode` (proprietary), service level and category purpose
   when present; the amount (see below); charge bearer from `chargedTo`, default SHAR; ultimate debtor
   from `ultimateDebtor` else `onBehalfOfPayer`; up to three intermediary agents with their accounts;
   creditor agent from `payeeBank`; creditor agent account from `creditorAgentAccount.account` else
   `payeeBank.bankAccountNumber`; creditor and creditor account from `payee`; ultimate creditor;
   `bankToBank` as instructions for the creditor agent (one per line, split at 140); purpose from
   `transactionReasonCd`; unstructured remittance from `remitterInfo.unstructuredInfo` (one per line,
   split at 140); structured remittance with the invoicer and invoicee identifications when present.
   Then the two FIS supplements: the transaction supplement (trace id) on the transaction and the
   payment information supplement (receipt and trace ids plus the extension block) on the message.
5. **Amount and FX.** No `exchangeRate`: `InstdAmt` is `transactionAmount` in `currencyCode`. With a
   foreign currency and no debit amount: `InstdAmt` is `exchangeRate.instructedAmount` in the foreign
   currency. With both: `EqvtAmt` (the debit amount plus the currency of transfer) by default, or
   `InstdAmt` in the foreign currency when the rule says so. Rate, rate type (SPOT, SALE, AGRD) and
   contract id go to `XchgRateInf`. Amounts are rounded half-up to the currency's minor unit.
6. **XML.** The document is marshalled with JAXB and validated against `pain.001.001.11.xsd`, which is
   shipped inside the jar. The JSON rendering for FIS is the next step, in Wire Rail II.

## Mapping summary

| pain.001.001.11 | Source in the payment object | Rule |
|---|---|---|
| GrpHdr/MsgId | clientTransactionId | configurable source, at most 35 characters |
| GrpHdr/CreDtTm | clock | UTC, milliseconds |
| GrpHdr/NbOfTxs, PmtInf/NbOfTxs | constant | 1 |
| GrpHdr/CtrlSum, PmtInf/CtrlSum | the amount written | equals InstdAmt or EqvtAmt/Amt |
| GrpHdr/InitgPty | initiatingParty, else context | name, address, identification, country |
| GrpHdr/InitnSrc | context | name, provider, version; off by default (not in the FIS samples) |
| PmtInf/PmtInfId | clientTransactionId | configurable source |
| PmtInf/PmtMtd, BtchBookg | constants | TRF, false |
| PmtInf/ReqdExctnDt/Dt | valueDate | strict yyyy-MM-dd, date only |
| PmtInf/Dbtr | payer | name or composed name parts; address; OrgId or PrvtId, never both; country of residence |
| PmtInf/DbtrAcct | payer | IBAN when accountIdType is IBAN or I; else Othr/Id with no scheme; Tp/Cd from accountIdType (DDA to CACC, savings to SVGS, else OTHR); account currency else payment currency |
| PmtInf/DbtrAgt | payerBank (configurable: onBehalfOfPayer, or a fixed context agent) | BICFI, ClrSysMmbId, LEI, name, address; a BIC or member id is mandatory |
| PmtInf/DbtrAgtAcct | debtorAgentAccount.account | Othr/Id |
| CdtTrfTxInf/PmtId | instructionId, endToEndId, swiftEndToEndTransactionReference | 35 characters; UETR lower-case UUID v4 |
| CdtTrfTxInf/PmtTpInf | serviceLevelCd, localInstrumentCode or paymentTypeCode, categoryPurpose | InstrPrty HIGH; external code to Cd, otherwise Prtry; the local instrument (BTR, CTR, DRC, CTRC ...) goes to Cd as in the FIS samples |
| CdtTrfTxInf/Amt, XchgRateInf | transactionAmount, currencyCode, exchangeRate | see "Amount and FX" |
| CdtTrfTxInf/ChrgBr | chargedTo | DEBT, CRED, SHAR, SLEV; default SHAR; unknown rejected by default |
| CdtTrfTxInf/UltmtDbtr | ultimateDebtor, else onBehalfOfPayer | party rule |
| CdtTrfTxInf/IntrmyAgt1..3 (+Acct) | first, secondary, tertiaryIntermediaryBank | agent rule; account from bankAccountNumber |
| CdtTrfTxInf/CdtrAgt | payeeBank | agent rule; a nine-digit bankCode without a system id is USABA |
| CdtTrfTxInf/CdtrAgtAcct | creditorAgentAccount.account, else payeeBank.bankAccountNumber | Othr/Id |
| CdtTrfTxInf/Cdtr | payee | party rule |
| CdtTrfTxInf/CdtrAcct | payee | IBAN, or Othr/Id with SchmeNm/Prtry "Proprietary" and no type, as in the FIS samples; currency of transfer when the payee has none |
| CdtTrfTxInf/UltmtCdtr | ultimateCreditor | party rule |
| CdtTrfTxInf/InstrForCdtrAgt | bankToBank | one InstrInf per line, each split at 140 |
| CdtTrfTxInf/Purp | transactionReasonCd | external code to Cd, otherwise Prtry |
| CdtTrfTxInf/RmtInf/Ustrd | remitterInfo.unstructuredInfo | one per line; split, truncate or reject at 140 (split by default) |
| CdtTrfTxInf/RmtInf/Strd/Invcr, Invcee | remitterInfo.invoicerIdentification, invoiceeIdentification | Id/OrgId/Othr/Id; no name or address source |
| CdtTrfTxInf/SplmtryData | message id | FIS transaction supplement: transactionTraceIdentification |
| CstmrCdtTrfInitn/SplmtryData | message id, context | FIS payment information supplement: firstInstructionReceiptIdentification, firstInstructionTraceIdentification, extension (internationalPayment derived; instMethod, templateName, accountType, waiveFees from the context) |

Text rules everywhere: values are trimmed; Max35Text identifiers, Max140Text names and lines, Max70Text
street names and address lines, Max16Text building numbers and post codes, Max34Text account ids; over
length is rejected unless a policy says truncate or split. Country codes are two letters upper case,
BICs 8 or 11 characters, LEIs 20. Choices are exclusive: OrgId or PrvtId, IBAN or Othr, InstdAmt or
EqvtAmt, Dt or DtTm.

## The rules (`MappingRules`)

Every open decision is a named value with a default, grouped by concern. Change the value, not the code.

| Rule | Default | Alternatives |
|---|---|---|
| identifiers.messageId, paymentInformationId | clientTransactionId | instructionId, endToEndId, messageTransmissionId, transactionId |
| identifiers.instructionId | instructionId | same list |
| identifiers.endToEndId | endToEndId | same list |
| identifiers.fallbackToClientTransactionId | true | false: a blank source rejects the payment |
| identifiers.uetrRequired | true | false |
| parties.debtorAgentSource | PAYER_BANK | ON_BEHALF_OF_PAYER (the V9 reading), CONTEXT (fixed agent) |
| parties.ultimateDebtorSource | ultimateDebtor then onBehalfOfPayer | ultimateDebtor only |
| parties.addressStyle | STRUCTURED_AND_LINES | STRUCTURED_ONLY, LINES_ONLY |
| parties.namePolicy | REJECT over 140 | TRUNCATE |
| accounts.debtorScheme, debtorType | NONE, FROM_ACCOUNT_ID_TYPE (FIS samples) | BBAN or PROPRIETARY; CACC, NONE or PROPRIETARY_RAW (V9) |
| accounts.creditorScheme, creditorType | PROPRIETARY, NONE (FIS samples) | same |
| accounts.writeCurrency | true | false |
| codes.localInstrumentStyle | EXTERNAL_CODE (FIS samples) | PROPRIETARY |
| codes.chargeBearerPolicy | REJECT unknown | USE_DEFAULT |
| codes.defaultChargeBearer | SHAR | DEBT, CRED, SLEV |
| codes.rateTypePolicy | REJECT unknown | USE_DEFAULT (omit RateTp) |
| codes.inferUsabaFromNineDigitBankCode | true | false |
| amounts.fxAmountStyle | EQUIVALENT_AMOUNT | INSTRUCTED_AMOUNT_ONLY |
| texts.remittancePolicy | SPLIT | TRUNCATE, REJECT |
| texts.bankToBankSlashCleanup | false | true (TMOBS, TMOBSDOM, OBS senders: slashes become spaces) |
| header.emitInitiationSource | false (not in the FIS samples) | true |
| supplements.emitFisSupplements | true | false |
| supplements.traceIdentifier | clientTransactionId (the message id, as in the FIS samples) | the other identifier sources |

## The FIS sample requests

FIS sent four sample requests (bank transfer, customer transfer, customer transfer with an intermediary
agent, and a drawdown with structured and hybrid addresses and structured remittance). They are bundled
under `src/main/resources/samples/fis`,
and each is rebuilt from a payment object under `src/test/resources/samples/sdp/fis-*.json`; the
equivalence test checks the mapped message against the FIS JSON value by value. What the samples settled:

- The payment type (BTR, CTR, DRC) is `localInstrument.code`, not proprietary.
- The debtor account is `other.identification` with no scheme and a `type.code` (OTHR or CACC); the
  creditor account is `other.identification` with `schemeName.proprietary: "Proprietary"` and no type.
- The debtor agent is a BIC (bank transfer, intermediary customer transfer) or a USABA member id (the
  others); the intermediary agent is a USABA member id with no account; agents may carry a structured
  address and no name.
- Addresses are either address lines only or fully structured plus address lines; both pass.
- Remittance and instructions for the creditor agent repeat as arrays of short lines.
- Every request carries the two FIS supplements with the message id as trace id and an extension block
  (internationalPayment, instMethod, templateName, accountType, waiveFees).
- The samples carry no UETR and the drawdown carries no end-to-end id; the mapper writes the UETR and
  falls back to the message id for the end-to-end id, which the schema allows.
- The business application header (sender PaymentSystemId and CoreBankIdentifier, receiver OPF with an
  endPointName, market practice "FIS EP Universal Execution, 2022 Edition 3, SuppressCallBack:Test") is
  JSON-level and belongs to Wire Rail II.

Not reproduced because the payment object has no source for them: the garnishment block of the
structured remittance, and the names and addresses of the invoicer and invoicee (only their
identifications are mapped).

## What is not in this library, and why

- **FIS JSON rendering.** `Pain001V11JsonRenderer.toFisJson` is a placeholder that throws. The FIS
  Universal Execution JSON is the FIS contract's shape (ISO long names, amount objects, the business
  application header), not a generic XML-to-JSON conversion; it is built in Wire Rail II from the
  contract models. The FIS samples are bundled so the target shape travels with the mapping; the
  supplements are already in the XML, so the rendering only copies them.
- **Detokenisation.** Account numbers arrive tokenised; Wire Rail II detokenises them through Turing.
  The mapper copies what it is given.
- **PIE supplementary data.** The V9 converter wrote a PIE-specific client-data envelope (FX debit
  currency and amount, initiator, approver). OPF does not read it; it is not written.
- **Garnishment and referred documents.** No source in the payment object.
- **Address standardisation.** The V9 converter called the ACE address service for one channel and
  payment type and blanked structured agent addresses as a PIE work-around. Neither is carried over.
- **Correspondent and instructing agents, clearing references, message format.** They belong to the
  clearing leg (pacs.008), not to pain.001.
- **Payment status, returns, ACH, card, RTP and letter fields** of the payment object are not read.

## Open questions

For the tech lead:

1. Debtor agent: `payerBank` (default), the on-behalf-of party as V9 read it, or a fixed Discover Bank agent?
2. Which payment-object fields carry the message id, payment information id, instruction id and end-to-end
   id for GPN and corporate wires, and who generates them? Today all default to `clientTransactionId`
   except the end-to-end id.
3. Local instrument: the FIS samples carry BTR, CTR and DRC as the code; confirm the full list for
   Discover's wires (BKP, NOS, BTRC, CTRC) and whether `localInstrumentCode` or `paymentTypeCode` is the
   source.
4. Are the `accountIdType` values the words (IBAN, DDA, ABA) or the letters (I, D, F)? Both are read as
   IBAN today; DDA and D become CACC, savings become SVGS, everything else OTHR.
5. Which `chargedTo` and `foreignExchangeTrade` values do the Discover channels send, and should an
   unknown value fail the payment or fall back to a default?
6. Name composition when only name parts are present, and whether a name over 140 characters is
   truncated or rejected.
7. Precedence between `ultimateDebtor` and `onBehalfOfPayer`.

For FIS:

8. Does OPF accept `EqvtAmt` for FX wires, or only `InstdAmt`?
9. Which address form does OPF require per rail (structured, hybrid, address lines), and does it reject
   structured fields combined with address lines?
10. Is `InstrForCdtrAgt/InstrInf` the right carrier for bank-to-bank text, and what chunking and line
    markers does OPF expect?
11. Which clearing system codes does OPF accept (USABA, others) and does it require a BIC for GPN agents?
12. Are service level, category purpose, purpose or regulatory reporting required for GPN wires, and
    which code lists apply?
13. Does OPF read `InitnSrc` or any supplementary data?
14. Date precision of the requested execution date and the handling of forward value dates after an OFAC hold.
15. Which V11 elements survive OPF's conversion to pain.001 V3 for the correspondent banks?
16. Does OPF keep the UETR we send all the way to the network? The samples carry none.
17. The extension block of the payment information supplement: what do instMethod ("Person"),
    accountType ("Consumer", "consumer"), templateName and waiveFees mean for Discover's wires, and which
    values does OPF expect from Capital One?
18. The creditor account scheme "Proprietary" and the debtor account type OTHR versus CACC: are these
    required as in the samples, or does OPF accept ISO codes (BBAN, CACC)?
19. Drawdown requests (DRC): the sample has no end-to-end id; confirm whether OPF requires one for
    Discover and what the drawdown request shape adds beyond a customer transfer.
20. The invoicee address in the drawdown sample uses "stateOrProvince", which is not a contract field;
    confirm the intended element.

## Samples and tests

`src/test/resources/samples/sdp` holds nine payment objects:

| Sample | What it covers |
|---|---|
| fis-bank-transfer | the FIS bank transfer sample (BTR): BIC debtor agent, OTHR account type, two remittance lines, two instructions |
| fis-customer-transfer | the FIS customer transfer sample (CTR): USABA agents, CACC debtor account |
| fis-intermediary-customer-transfer | the FIS customer transfer with intermediary sample (CTR): BIC debtor agent, USABA intermediary agent 1 without an account, two remittance lines, two instructions |
| fis-drawdown-structured | the FIS drawdown sample (DRC): structured and hybrid addresses on every party and agent, ultimate parties, intermediary agent, invoicer and invoicee |
| gpn-usd-wire | domestic USD wire, USABA agents, organisation id, category purpose, remittance, long bank-to-bank text |
| corp-fx-eur-wire | USD-to-EUR wire with equivalent amount and exchange rate, LEI, BIC agents, IBAN creditor, intermediary agent, address lines, remittance split |
| corp-on-behalf-of-wire | composed personal name, private identification with date and place of birth, on-behalf-of party as ultimate debtor, debtor and creditor agent accounts, legacy account type letter, ultimate creditor |
| fx-instructed-amount-only | FX wire with no debit amount: instructed amount in JPY rounded to no decimals, BIC-only agents |
| invalid-missing-required-fields | rejected with ten reasons at once |

`src/test/resources/golden` holds the XML of the eight valid samples with a fixed creation time; the
golden test compares the full output. After a deliberate mapping change, regenerate them with
`./gradlew renderSamples -Pclock=fixed` and copy `build/samples/*.xml` over after reviewing the diff.

## Layout

```
build.gradle, settings.gradle          Gradle 9, Java 21 toolchain, XSD code generation, renderSamples task
payx-payload-local/                    stand-in for the payment object library (off-network builds only)
src/main/resources/xsd/                pain.001.001.11.xsd (also shipped in the jar for validation)
src/main/resources/samples/fis/        the four FIS sample requests, FIS's contract example and our connectivity-test request
src/main/java/com/capitalone/bank/wire/object/mapper/
  common/                              Text, IsoDates, Amounts, MappingException, MappingProblem, Problems
  pain001/v11/                         Pain001V11Mapper, MappingContext, MappingRules, Pain001V11Marshaller,
                                       PayloadPreconditions, the block builders, the party, account, agent,
                                       address, amount and code mappers, and the FIS supplement mapper
  pain001/v11/json/                    Pain001V11JsonRenderer (placeholder)
  generated/pain001v11/                generated at build time from the XSD (not in the repository)
src/test/                              tests, sample payment objects, golden XML, SampleRenderer
docs/                                  payment object inventory, field mapping analysis, V11 element tree
```
