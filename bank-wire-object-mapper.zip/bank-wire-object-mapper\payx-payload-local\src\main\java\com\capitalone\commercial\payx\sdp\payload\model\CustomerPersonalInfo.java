package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"dateOfBirth", "cityOfBirth", "countryOfBirth"})
public class CustomerPersonalInfo {
    @JsonProperty("dateOfBirth")
    private String dateOfBirth;
    @JsonProperty("cityOfBirth")
    private String cityOfBirth;
    @JsonProperty("countryOfBirth")
    private String countryOfBirth;

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getCityOfBirth() {
        return cityOfBirth;
    }

    public void setCityOfBirth(String cityOfBirth) {
        this.cityOfBirth = cityOfBirth;
    }

    public String getCountryOfBirth() {
        return countryOfBirth;
    }

    public void setCountryOfBirth(String countryOfBirth) {
        this.countryOfBirth = countryOfBirth;
    }
}
