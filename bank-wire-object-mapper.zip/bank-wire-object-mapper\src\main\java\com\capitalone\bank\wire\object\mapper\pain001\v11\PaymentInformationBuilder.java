package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.IsoDates;
import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.BranchAndFinancialInstitutionIdentification6;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.DateAndDateTime2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentInstruction40;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentMethod3Code;
import com.capitalone.bank.wire.object.mapper.pain001.v11.AmountMapper.MappedAmount;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.util.Optional;

/**
 * PmtInf, the debit side: identification, TRF, no batch booking, one transaction, control sum, the
 * requested execution date from valueDate, debtor, debtor account and debtor agent, then the single
 * credit transfer transaction.
 */
final class PaymentInformationBuilder {

    private final MappingContext context;

    PaymentInformationBuilder(MappingContext context) {
        this.context = context;
    }

    PaymentInstruction40 build(SDPPayload payload, MappedAmount amount) {
        var rules = context.rules();
        var instruction = new PaymentInstruction40();
        instruction.setPmtInfId(Identifiers.paymentInformationId(payload, rules.identifiers()));
        instruction.setPmtMtd(PaymentMethod3Code.TRF);
        instruction.setBtchBookg(false);
        instruction.setNbOfTxs(GroupHeaderBuilder.ONE_TRANSACTION);
        instruction.setCtrlSum(amount.controlSum());
        instruction.setReqdExctnDt(requestedExecutionDate(payload));

        var payer = payload.getPayer();
        var debitCurrency = Optional.of(debitCurrency(payload, amount));
        instruction.setDbtr(PartyMapper.party(payer, "payload.payer", rules.parties()));
        instruction.setDbtrAcct(CashAccountMapper.account(payer, CashAccountMapper.Role.DEBTOR, debitCurrency,
                "payload.payer", rules.accounts()));
        instruction.setDbtrAgt(debtorAgent(payload));
        debtorAgentAccount(payload).ifPresent(instruction::setDbtrAgtAcct);

        instruction.getCdtTrfTxInf().add(new CreditTransferBuilder(context).build(payload, amount));
        return instruction;
    }

    /** ReqdExctnDt/Dt from valueDate, as a date only. */
    private static DateAndDateTime2Choice requestedExecutionDate(SDPPayload payload) {
        var choice = new DateAndDateTime2Choice();
        choice.setDt(IsoDates.date(IsoDates.parse(payload.getValueDate(), "payload.valueDate")));
        return choice;
    }

    /** The debtor account's currency when the payment object does not say: the payment currency, else the transfer currency. */
    private static String debitCurrency(SDPPayload payload, MappedAmount amount) {
        return Text.clean(payload.getCurrencyCode())
                .map(value -> com.capitalone.bank.wire.object.mapper.common.Amounts.currency(value, "payload.currencyCode"))
                .orElse(amount.currencyOfTransfer());
    }

    private BranchAndFinancialInstitutionIdentification6 debtorAgent(SDPPayload payload) {
        var rules = context.rules();
        var fromPayload = switch (rules.parties().debtorAgentSource()) {
            case PAYER_BANK -> AgentMapper.optionalAgent(payload.getPayerBank(), "payload.payerBank", rules);
            case ON_BEHALF_OF_PAYER -> AgentMapper.fromParty(payload.getOnBehalfOfPayer(), "payload.onBehalfOfPayer", rules);
            case CONTEXT -> Optional.<BranchAndFinancialInstitutionIdentification6>empty();
        };
        return fromPayload.orElseGet(() -> {
            var fixed = context.debtorAgent();
            if (fixed == null) {
                throw new MappingException("payload.payerBank", "is absent and the context names no debtor agent");
            }
            return AgentMapper.fromContext(fixed);
        });
    }

    /** DbtrAgtAcct from debtorAgentAccount.account, the field the payment object reserves for it. */
    private static Optional<com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccount40> debtorAgentAccount(
            SDPPayload payload) {
        return Optional.ofNullable(payload.getDebtorAgentAccount())
                .flatMap(agent -> Text.clean(agent.getAccount()))
                .map(number -> CashAccountMapper.agentAccount(number, "payload.debtorAgentAccount.account"));
    }
}
