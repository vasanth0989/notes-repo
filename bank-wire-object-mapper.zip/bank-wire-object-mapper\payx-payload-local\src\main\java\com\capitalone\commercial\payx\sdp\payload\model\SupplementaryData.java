package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"contractedCurrencyCode", "contractedDebitAmount", "initiatorId", "approverId"})
public class SupplementaryData {
    @JsonProperty("contractedCurrencyCode")
    private String contractedCurrencyCode;
    @JsonProperty("contractedDebitAmount")
    private String contractedDebitAmount;
    @JsonProperty("initiatorId")
    private String initiatorId;
    @JsonProperty("approverId")
    private String approverId;

    public String getContractedCurrencyCode() {
        return contractedCurrencyCode;
    }

    public void setContractedCurrencyCode(String contractedCurrencyCode) {
        this.contractedCurrencyCode = contractedCurrencyCode;
    }

    public String getContractedDebitAmount() {
        return contractedDebitAmount;
    }

    public void setContractedDebitAmount(String contractedDebitAmount) {
        this.contractedDebitAmount = contractedDebitAmount;
    }

    public String getInitiatorId() {
        return initiatorId;
    }

    public void setInitiatorId(String initiatorId) {
        this.initiatorId = initiatorId;
    }

    public String getApproverId() {
        return approverId;
    }

    public void setApproverId(String approverId) {
        this.approverId = approverId;
    }
}
