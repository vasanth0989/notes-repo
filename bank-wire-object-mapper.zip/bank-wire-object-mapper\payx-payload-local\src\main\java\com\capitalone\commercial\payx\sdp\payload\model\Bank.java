package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"accountIdType", "bankAccountNumber", "bankName", "bankSystemIdentifier", "bankCode", "legalEntityIdentifier", "swiftBankIdentifierCode", "address"})
public class Bank {
    @JsonProperty("accountIdType")
    private String accountIdType;
    @JsonProperty("bankAccountNumber")
    private String bankAccountNumber;
    @JsonProperty("bankName")
    private String bankName;
    @JsonProperty("bankSystemIdentifier")
    private String bankSystemIdentifier;
    @JsonProperty("bankCode")
    private String bankCode;
    @JsonProperty("legalEntityIdentifier")
    private String legalEntityIdentifier;
    @JsonProperty("swiftBankIdentifierCode")
    private String swiftBankIdentifierCode;
    @JsonProperty("address")
    private Address address;

    public String getAccountIdType() {
        return accountIdType;
    }

    public void setAccountIdType(String accountIdType) {
        this.accountIdType = accountIdType;
    }

    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getBankSystemIdentifier() {
        return bankSystemIdentifier;
    }

    public void setBankSystemIdentifier(String bankSystemIdentifier) {
        this.bankSystemIdentifier = bankSystemIdentifier;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getLegalEntityIdentifier() {
        return legalEntityIdentifier;
    }

    public void setLegalEntityIdentifier(String legalEntityIdentifier) {
        this.legalEntityIdentifier = legalEntityIdentifier;
    }

    public String getSwiftBankIdentifierCode() {
        return swiftBankIdentifierCode;
    }

    public void setSwiftBankIdentifierCode(String swiftBankIdentifierCode) {
        this.swiftBankIdentifierCode = swiftBankIdentifierCode;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }
}
