package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload}. Same accessors as the jsonschema2pojo output;
 * only the fields a wire uses. Replace with the real library on the Capital One network
 * ({@code -PpayxPayloadVersion}). Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"accountNumber", "accountIdType", "identificationNumber", "identificationNumberType", "accountName", "accountSuffixName", "accountFirstName", "accountMiddleName", "accountLastName", "accountPrefixName", "alsoKnownAsName", "bankIdentifierCode", "currencyCode", "legalEntityIdentifier", "organizationIdentificationNumber", "organizationIdentificationNumberType", "otherIdentifier", "postingType", "otherIdentifierType", "address", "customerPersonalInfo", "sorId", "customerId", "issuer", "countryOfResidence", "dateOfDeath", "displayAccountNumber", "lastFourAccountDigits", "sorMinusOneAccountNumber"})
public class Account {
    @JsonProperty("accountNumber")
    private String accountNumber;
    @JsonProperty("accountIdType")
    private String accountIdType;
    @JsonProperty("identificationNumber")
    private String identificationNumber;
    @JsonProperty("identificationNumberType")
    private String identificationNumberType;
    @JsonProperty("accountName")
    private String accountName;
    @JsonProperty("accountSuffixName")
    private String accountSuffixName;
    @JsonProperty("accountFirstName")
    private String accountFirstName;
    @JsonProperty("accountMiddleName")
    private String accountMiddleName;
    @JsonProperty("accountLastName")
    private String accountLastName;
    @JsonProperty("accountPrefixName")
    private String accountPrefixName;
    @JsonProperty("alsoKnownAsName")
    private String alsoKnownAsName;
    @JsonProperty("bankIdentifierCode")
    private String bankIdentifierCode;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("legalEntityIdentifier")
    private String legalEntityIdentifier;
    @JsonProperty("organizationIdentificationNumber")
    private String organizationIdentificationNumber;
    @JsonProperty("organizationIdentificationNumberType")
    private String organizationIdentificationNumberType;
    @JsonProperty("otherIdentifier")
    private String otherIdentifier;
    @JsonProperty("postingType")
    private String postingType;
    @JsonProperty("otherIdentifierType")
    private String otherIdentifierType;
    @JsonProperty("address")
    private Address address;
    @JsonProperty("customerPersonalInfo")
    private CustomerPersonalInfo customerPersonalInfo;
    @JsonProperty("sorId")
    private String sorId;
    @JsonProperty("customerId")
    private String customerId;
    @JsonProperty("issuer")
    private String issuer;
    @JsonProperty("countryOfResidence")
    private String countryOfResidence;
    @JsonProperty("dateOfDeath")
    private String dateOfDeath;
    @JsonProperty("displayAccountNumber")
    private String displayAccountNumber;
    @JsonProperty("lastFourAccountDigits")
    private String lastFourAccountDigits;
    @JsonProperty("sorMinusOneAccountNumber")
    private String sorMinusOneAccountNumber;

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountIdType() {
        return accountIdType;
    }

    public void setAccountIdType(String accountIdType) {
        this.accountIdType = accountIdType;
    }

    public String getIdentificationNumber() {
        return identificationNumber;
    }

    public void setIdentificationNumber(String identificationNumber) {
        this.identificationNumber = identificationNumber;
    }

    public String getIdentificationNumberType() {
        return identificationNumberType;
    }

    public void setIdentificationNumberType(String identificationNumberType) {
        this.identificationNumberType = identificationNumberType;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountSuffixName() {
        return accountSuffixName;
    }

    public void setAccountSuffixName(String accountSuffixName) {
        this.accountSuffixName = accountSuffixName;
    }

    public String getAccountFirstName() {
        return accountFirstName;
    }

    public void setAccountFirstName(String accountFirstName) {
        this.accountFirstName = accountFirstName;
    }

    public String getAccountMiddleName() {
        return accountMiddleName;
    }

    public void setAccountMiddleName(String accountMiddleName) {
        this.accountMiddleName = accountMiddleName;
    }

    public String getAccountLastName() {
        return accountLastName;
    }

    public void setAccountLastName(String accountLastName) {
        this.accountLastName = accountLastName;
    }

    public String getAccountPrefixName() {
        return accountPrefixName;
    }

    public void setAccountPrefixName(String accountPrefixName) {
        this.accountPrefixName = accountPrefixName;
    }

    public String getAlsoKnownAsName() {
        return alsoKnownAsName;
    }

    public void setAlsoKnownAsName(String alsoKnownAsName) {
        this.alsoKnownAsName = alsoKnownAsName;
    }

    public String getBankIdentifierCode() {
        return bankIdentifierCode;
    }

    public void setBankIdentifierCode(String bankIdentifierCode) {
        this.bankIdentifierCode = bankIdentifierCode;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getLegalEntityIdentifier() {
        return legalEntityIdentifier;
    }

    public void setLegalEntityIdentifier(String legalEntityIdentifier) {
        this.legalEntityIdentifier = legalEntityIdentifier;
    }

    public String getOrganizationIdentificationNumber() {
        return organizationIdentificationNumber;
    }

    public void setOrganizationIdentificationNumber(String organizationIdentificationNumber) {
        this.organizationIdentificationNumber = organizationIdentificationNumber;
    }

    public String getOrganizationIdentificationNumberType() {
        return organizationIdentificationNumberType;
    }

    public void setOrganizationIdentificationNumberType(String organizationIdentificationNumberType) {
        this.organizationIdentificationNumberType = organizationIdentificationNumberType;
    }

    public String getOtherIdentifier() {
        return otherIdentifier;
    }

    public void setOtherIdentifier(String otherIdentifier) {
        this.otherIdentifier = otherIdentifier;
    }

    public String getPostingType() {
        return postingType;
    }

    public void setPostingType(String postingType) {
        this.postingType = postingType;
    }

    public String getOtherIdentifierType() {
        return otherIdentifierType;
    }

    public void setOtherIdentifierType(String otherIdentifierType) {
        this.otherIdentifierType = otherIdentifierType;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public CustomerPersonalInfo getCustomerPersonalInfo() {
        return customerPersonalInfo;
    }

    public void setCustomerPersonalInfo(CustomerPersonalInfo customerPersonalInfo) {
        this.customerPersonalInfo = customerPersonalInfo;
    }

    public String getSorId() {
        return sorId;
    }

    public void setSorId(String sorId) {
        this.sorId = sorId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getCountryOfResidence() {
        return countryOfResidence;
    }

    public void setCountryOfResidence(String countryOfResidence) {
        this.countryOfResidence = countryOfResidence;
    }

    public String getDateOfDeath() {
        return dateOfDeath;
    }

    public void setDateOfDeath(String dateOfDeath) {
        this.dateOfDeath = dateOfDeath;
    }

    public String getDisplayAccountNumber() {
        return displayAccountNumber;
    }

    public void setDisplayAccountNumber(String displayAccountNumber) {
        this.displayAccountNumber = displayAccountNumber;
    }

    public String getLastFourAccountDigits() {
        return lastFourAccountDigits;
    }

    public void setLastFourAccountDigits(String lastFourAccountDigits) {
        this.lastFourAccountDigits = lastFourAccountDigits;
    }

    public String getSorMinusOneAccountNumber() {
        return sorMinusOneAccountNumber;
    }

    public void setSorMinusOneAccountNumber(String sorMinusOneAccountNumber) {
        this.sorMinusOneAccountNumber = sorMinusOneAccountNumber;
    }
}
