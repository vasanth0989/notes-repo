package com.capitalone.bank.wire.object.mapper.common;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import org.jspecify.annotations.Nullable;

/** ISODate and ISODateTime conversions. Dates carry no time and no zone; date-times are UTC with milliseconds. */
public final class IsoDates {

    private static final DatatypeFactory FACTORY;

    static {
        try {
            FACTORY = DatatypeFactory.newInstance();
        } catch (DatatypeConfigurationException e) {
            throw new IllegalStateException("No JAXP datatype factory available", e);
        }
    }

    private IsoDates() {
    }

    /** ISODate: {@code 2026-10-23}, nothing else. */
    public static XMLGregorianCalendar date(LocalDate date) {
        return FACTORY.newXMLGregorianCalendarDate(
                date.getYear(), date.getMonthValue(), date.getDayOfMonth(), DatatypeConstants.FIELD_UNDEFINED);
    }

    /** ISODateTime in UTC with millisecond precision: {@code 2026-10-23T13:56:05.000Z}. */
    public static XMLGregorianCalendar dateTime(OffsetDateTime dateTime) {
        var utc = dateTime.withOffsetSameInstant(ZoneOffset.UTC).truncatedTo(ChronoUnit.MILLIS);
        return FACTORY.newXMLGregorianCalendar(GregorianCalendar.from(utc.toZonedDateTime()));
    }

    /** Parses a payment-object date that must already be {@code yyyy-MM-dd}; anything else is rejected. */
    public static LocalDate parse(@Nullable String value, String path) {
        var text = Text.required(value, path);
        try {
            return LocalDate.parse(text, DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (DateTimeParseException e) {
            throw new MappingException(path, "must be a date in the form yyyy-MM-dd", e);
        }
    }
}
