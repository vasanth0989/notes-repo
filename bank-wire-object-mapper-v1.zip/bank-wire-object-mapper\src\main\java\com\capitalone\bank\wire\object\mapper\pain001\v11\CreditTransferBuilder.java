package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccount40;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CreditTransferTransaction54;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GenericOrganisationIdentification1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.InstructionForCreditorAgent3;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.OrganisationIdentification29;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Party38Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PartyIdentification135;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentIdentification6;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentTypeInformation26;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Priority2Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.RemittanceInformation21;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.StructuredRemittanceInformation17;
import com.capitalone.bank.wire.object.mapper.pain001.v11.AmountMapper.MappedAmount;
import com.capitalone.commercial.payx.sdp.payload.model.Account;
import com.capitalone.commercial.payx.sdp.payload.model.Bank;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.jspecify.annotations.Nullable;

/**
 * CdtTrfTxInf, the credit side: payment identification, payment type, amount and FX, charge bearer,
 * ultimate debtor, intermediary agents 1 and 2, creditor agent (its account from payeeBank), creditor,
 * creditor account, ultimate creditor, bank-to-bank instructions, purpose and remittance information.
 * The third intermediary agent and a separate creditor agent account need payload fields that
 * version 2.16-beta does not have.
 */
final class CreditTransferBuilder {

    /** Sender member ids whose bank-to-bank text gets the slash clean-up when the rule is on. */
    private static final Set<String> SLASH_CLEANUP_SENDERS = Set.of("TMOBS", "TMOBSDOM", "OBS");

    private final MappingContext context;

    CreditTransferBuilder(MappingContext context) {
        this.context = context;
    }

    CreditTransferTransaction54 build(SDPPayload payload, MappedAmount amount) {
        var rules = context.rules();
        var transaction = new CreditTransferTransaction54();
        transaction.setPmtId(paymentIdentification(payload));
        transaction.setPmtTpInf(paymentTypeInformation(payload));
        transaction.setAmt(amount.amount());
        if (amount.exchangeRateInformation() != null) {
            transaction.setXchgRateInf(amount.exchangeRateInformation());
        }
        transaction.setChrgBr(CodeTables.chargeBearer(payload.getChargedTo(), rules.codes()));

        ultimateDebtor(payload).ifPresent(transaction::setUltmtDbtr);

        AgentMapper.optionalAgent(payload.getFirstIntermediaryBank(), "payload.firstIntermediaryBank", rules)
                .ifPresent(transaction::setIntrmyAgt1);
        agentAccount(payload.getFirstIntermediaryBank(), "payload.firstIntermediaryBank").ifPresent(transaction::setIntrmyAgt1Acct);
        AgentMapper.optionalAgent(payload.getSecondaryIntermediaryBank(), "payload.secondaryIntermediaryBank", rules)
                .ifPresent(transaction::setIntrmyAgt2);
        agentAccount(payload.getSecondaryIntermediaryBank(), "payload.secondaryIntermediaryBank").ifPresent(transaction::setIntrmyAgt2Acct);
        // IntrmyAgt3: payload 2.16-beta has no tertiaryIntermediaryBank.

        transaction.setCdtrAgt(AgentMapper.agent(payload.getPayeeBank(), "payload.payeeBank", rules));
        agentAccount(payload.getPayeeBank(), "payload.payeeBank").ifPresent(transaction::setCdtrAgtAcct);

        var payee = payload.getPayee();
        transaction.setCdtr(PartyMapper.party(payee, "payload.payee", rules.parties()));
        transaction.setCdtrAcct(CashAccountMapper.account(payee, CashAccountMapper.Role.CREDITOR,
                Optional.of(amount.currencyOfTransfer()), "payload.payee", rules.accounts()));
        Optional.ofNullable(payload.getUltimateCreditor())
                .map(party -> PartyMapper.party(party, "payload.ultimateCreditor", rules.parties()))
                .ifPresent(transaction::setUltmtCdtr);

        bankToBankInstructions(payload).forEach(text -> {
            var instruction = new InstructionForCreditorAgent3();
            instruction.setInstrInf(text);
            transaction.getInstrForCdtrAgt().add(instruction);
        });
        Text.clean(payload.getTransactionReasonCd())
                .map(value -> CodeTables.purpose(value, "payload.transactionReasonCd"))
                .ifPresent(transaction::setPurp);
        remittance(payload).ifPresent(transaction::setRmtInf);
        return transaction;
    }

    private PaymentIdentification6 paymentIdentification(SDPPayload payload) {
        var rules = context.rules().identifiers();
        var identification = new PaymentIdentification6();
        Identifiers.instructionId(payload, rules).ifPresent(identification::setInstrId);
        identification.setEndToEndId(Identifiers.endToEndId(payload, rules));
        Identifiers.uetr(payload, rules).ifPresent(identification::setUETR);
        return identification;
    }

    /** HIGH priority; service level, local instrument (localInstrumentCode, else paymentTypeCode) and category purpose when present. */
    private PaymentTypeInformation26 paymentTypeInformation(SDPPayload payload) {
        var rules = context.rules();
        var information = new PaymentTypeInformation26();
        information.setInstrPrty(Priority2Code.HIGH);
        Text.clean(payload.getServiceLevelCd())
                .map(value -> CodeTables.serviceLevel(value, "payload.serviceLevelCd"))
                .ifPresent(information.getSvcLvl()::add);
        Text.clean(payload.getLocalInstrumentCode())
                .map(value -> CodeTables.localInstrument(value, "payload.localInstrumentCode", rules.codes().localInstrumentStyle()))
                .or(() -> Text.clean(payload.getPaymentTypeCode())
                        .map(value -> CodeTables.localInstrument(value, "payload.paymentTypeCode", rules.codes().localInstrumentStyle())))
                .ifPresent(information::setLclInstrm);
        Text.clean(payload.getCategoryPurpose())
                .map(value -> CodeTables.categoryPurpose(value, "payload.categoryPurpose"))
                .ifPresent(information::setCtgyPurp);
        return information;
    }

    private Optional<PartyIdentification135> ultimateDebtor(SDPPayload payload) {
        var parties = context.rules().parties();
        Optional<Account> source = Optional.ofNullable(payload.getUltimateDebtor());
        var path = "payload.ultimateDebtor";
        if (source.isEmpty() && parties.ultimateDebtorSource() == MappingRules.UltimateDebtorSource.ULTIMATE_DEBTOR_THEN_ON_BEHALF_OF_PAYER) {
            source = Optional.ofNullable(payload.getOnBehalfOfPayer());
            path = "payload.onBehalfOfPayer";
        }
        var finalPath = path;
        return source.map(party -> PartyMapper.party(party, finalPath, parties));
    }

    private static Optional<CashAccount40> agentAccount(@Nullable Bank bank, String path) {
        return Optional.ofNullable(bank)
                .flatMap(value -> Text.clean(value.getBankAccountNumber()))
                .map(number -> CashAccountMapper.agentAccount(number, path + ".bankAccountNumber"));
    }

    /** bankToBank in 140-character pieces, one InstrForCdtrAgt each, after the optional slash clean-up. */
    private List<String> bankToBankInstructions(SDPPayload payload) {
        var text = Text.clean(payload.getBankToBank());
        if (text.isEmpty()) {
            return List.of();
        }
        var value = text.get();
        if (context.rules().texts().bankToBankSlashCleanup() && slashCleanupApplies(payload, value)) {
            value = value.replace('/', ' ');
        }
        return Text.chunks(value, Text.MAX_140);
    }

    private static boolean slashCleanupApplies(SDPPayload payload, String text) {
        var sender = Optional.ofNullable(payload.getOptionalHeaderInfo())
                .flatMap(header -> Text.clean(header.getSenderMemberId()))
                .map(Text::upper);
        return sender.filter(SLASH_CLEANUP_SENDERS::contains).isPresent() && text.chars().filter(c -> c == '/').count() > 1;
    }

    /**
     * RmtInf: Ustrd from remitterInfo.unstructuredInfo under the remittance policy (one element per line,
     * split at 140); Strd with the invoicer and invoicee identifications when the payment object carries
     * them. Garnishment and referred-document details have no source in the payment object.
     */
    private Optional<RemittanceInformation21> remittance(SDPPayload payload) {
        var info = payload.getRemitterInfo();
        if (info == null) {
            return Optional.empty();
        }
        var remittance = new RemittanceInformation21();
        var path = "payload.remitterInfo.unstructuredInfo";
        Text.clean(info.getUnstructuredInfo()).ifPresent(text -> {
            var lines = switch (context.rules().texts().remittancePolicy()) {
                case SPLIT -> Text.chunks(text, Text.MAX_140);
                case TRUNCATE -> List.of(Text.truncated(text, Text.MAX_140).orElseThrow());
                case REJECT -> List.of(Text.bounded(text, Text.MAX_140, path));
            };
            remittance.getUstrd().addAll(lines);
        });

        var invoicer = organisationParty(info.getInvoicerIdentification(), "payload.remitterInfo.invoicerIdentification");
        var invoicee = organisationParty(info.getInvoiceeIdentification(), "payload.remitterInfo.invoiceeIdentification");
        if (invoicer.isPresent() || invoicee.isPresent()) {
            var structured = new StructuredRemittanceInformation17();
            invoicer.ifPresent(structured::setInvcr);
            invoicee.ifPresent(structured::setInvcee);
            remittance.getStrd().add(structured);
        }
        return remittance.getUstrd().isEmpty() && remittance.getStrd().isEmpty() ? Optional.empty() : Optional.of(remittance);
    }

    /** A party known by an organisation identifier only (Id/OrgId/Othr/Id); no name or address source exists. */
    private static Optional<PartyIdentification135> organisationParty(@Nullable String identifier, String path) {
        return Text.clean(identifier).map(value -> {
            var other = new GenericOrganisationIdentification1();
            other.setId(Text.bounded(value, Text.MAX_35, path));
            var organisation = new OrganisationIdentification29();
            organisation.getOthr().add(other);
            var choice = new Party38Choice();
            choice.setOrgId(organisation);
            var party = new PartyIdentification135();
            party.setId(choice);
            return party;
        });
    }
}
