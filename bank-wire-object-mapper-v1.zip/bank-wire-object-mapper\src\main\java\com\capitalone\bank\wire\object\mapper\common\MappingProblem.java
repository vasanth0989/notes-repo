package com.capitalone.bank.wire.object.mapper.common;

/**
 * One reason a payment object cannot be mapped: the payment-object path that caused it and a message
 * that describes the rule, never the value (account numbers, names and amounts must not leak into
 * exceptions or logs).
 */
public record MappingProblem(String path, String message) {

    public MappingProblem {
        if (path == null || path.isBlank()) {
            throw new IllegalArgumentException("path is required");
        }
        if (message == null || message.isBlank()) {
            throw new IllegalArgumentException("message is required");
        }
    }

    @Override
    public String toString() {
        return path + ": " + message;
    }
}
