package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload:2.16-beta}. Field names, order and types follow that
 * version's sources; the stand-in carries the fields the wire mapper reads and leaves out nested objects it
 * never touches. Replace with the real library on the Capital One network ({@code -PpayxPayloadVersion}).
 * Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"senderMemberId", "receiverMemberId", "senderBranchId", "receiverBranchId", "businessMsgId", "fromClearingSystemMemberId", "toClearingSystemMemberId", "businessService"})
public class OptionalHeaderInfo {
    @JsonProperty("senderMemberId")
    private String senderMemberId;
    @JsonProperty("receiverMemberId")
    private String receiverMemberId;
    @JsonProperty("senderBranchId")
    private String senderBranchId;
    @JsonProperty("receiverBranchId")
    private String receiverBranchId;
    @JsonProperty("businessMsgId")
    private String businessMsgId;
    @JsonProperty("fromClearingSystemMemberId")
    private String fromClearingSystemMemberId;
    @JsonProperty("toClearingSystemMemberId")
    private String toClearingSystemMemberId;
    @JsonProperty("businessService")
    private String businessService;

    public String getSenderMemberId() {
        return senderMemberId;
    }

    public void setSenderMemberId(String senderMemberId) {
        this.senderMemberId = senderMemberId;
    }

    public String getReceiverMemberId() {
        return receiverMemberId;
    }

    public void setReceiverMemberId(String receiverMemberId) {
        this.receiverMemberId = receiverMemberId;
    }

    public String getSenderBranchId() {
        return senderBranchId;
    }

    public void setSenderBranchId(String senderBranchId) {
        this.senderBranchId = senderBranchId;
    }

    public String getReceiverBranchId() {
        return receiverBranchId;
    }

    public void setReceiverBranchId(String receiverBranchId) {
        this.receiverBranchId = receiverBranchId;
    }

    public String getBusinessMsgId() {
        return businessMsgId;
    }

    public void setBusinessMsgId(String businessMsgId) {
        this.businessMsgId = businessMsgId;
    }

    public String getFromClearingSystemMemberId() {
        return fromClearingSystemMemberId;
    }

    public void setFromClearingSystemMemberId(String fromClearingSystemMemberId) {
        this.fromClearingSystemMemberId = fromClearingSystemMemberId;
    }

    public String getToClearingSystemMemberId() {
        return toClearingSystemMemberId;
    }

    public void setToClearingSystemMemberId(String toClearingSystemMemberId) {
        this.toClearingSystemMemberId = toClearingSystemMemberId;
    }

    public String getBusinessService() {
        return businessService;
    }

    public void setBusinessService(String businessService) {
        this.businessService = businessService;
    }
}
