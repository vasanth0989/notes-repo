package com.capitalone.bank.wire.object.mapper.pain001.v11;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.capitalone.bank.wire.object.mapper.common.IsoDates;
import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CustomerCreditTransferInitiationV11;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GroupHeader95;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PartyIdentification135;
import com.capitalone.bank.wire.object.mapper.pain001.v11.json.Pain001V11JsonRenderer;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import org.junit.jupiter.api.Test;

class Pain001V11MarshallerTest {

    private final Pain001V11Marshaller marshaller = new Pain001V11Marshaller();

    @Test
    void marshalsToTheV11NamespaceWithoutValidation() {
        var xml = marshaller.toXml(documentWithHeaderOnly(), false);

        assertThat(xml)
                .contains("urn:iso:std:iso:20022:tech:xsd:pain.001.001.11")
                .contains("<MsgId>MSG-0001</MsgId>")
                .contains("<CreDtTm>2026-10-14T09:30:00.000Z</CreDtTm>");
    }

    @Test
    void validationRejectsADocumentWithoutPaymentInformation() {
        assertThatThrownBy(() -> marshaller.toXml(documentWithHeaderOnly(), true))
                .isInstanceOf(MappingException.class)
                .hasMessageContaining("PmtInf");
    }

    @Test
    void validateRejectsTextThatIsNotAPain001Message() {
        assertThatThrownBy(() -> marshaller.validate("<Document xmlns=\"urn:iso:std:iso:20022:tech:xsd:pain.001.001.11\"/>"))
                .isInstanceOf(MappingException.class)
                .hasMessageContaining("CstmrCdtTrfInitn");
    }

    @Test
    void jsonRenderingIsAPlaceholderAndTheFisSamplesAreBundled() {
        var renderer = new Pain001V11JsonRenderer();

        assertThatThrownBy(() -> renderer.toFisJson(documentWithHeaderOnly()))
                .isInstanceOf(UnsupportedOperationException.class)
                .hasMessageContaining("bank-wire-rail-ii-api");
        assertThat(Pain001V11JsonRenderer.sample(Pain001V11JsonRenderer.FIS_EXAMPLE_REQUEST))
                .contains("\"messageDefinitionIdentifier\": \"pain.001.001.11\"")
                .contains("customerCreditTransferInitiation");
        assertThat(Pain001V11JsonRenderer.sample(Pain001V11JsonRenderer.FIS_USD_WIRE_REQUEST))
                .contains("businessApplicationHeader");
    }

    private static Document documentWithHeaderOnly() {
        var initiatingParty = new PartyIdentification135();
        initiatingParty.setNm("Capital One");

        var header = new GroupHeader95();
        header.setMsgId("MSG-0001");
        header.setCreDtTm(IsoDates.dateTime(OffsetDateTime.of(2026, 10, 14, 9, 30, 0, 0, ZoneOffset.UTC)));
        header.setNbOfTxs("1");
        header.setInitgPty(initiatingParty);

        var initiation = new CustomerCreditTransferInitiationV11();
        initiation.setGrpHdr(header);

        var document = new Document();
        document.setCstmrCdtTrfInitn(initiation);
        return document;
    }
}
