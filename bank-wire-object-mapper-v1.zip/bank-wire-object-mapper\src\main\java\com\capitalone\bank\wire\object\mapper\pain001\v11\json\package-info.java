/** The FIS JSON rendering of pain.001.001.11 (placeholder; implemented in Wire Rail II). */
@org.jspecify.annotations.NullMarked
package com.capitalone.bank.wire.object.mapper.pain001.v11.json;
