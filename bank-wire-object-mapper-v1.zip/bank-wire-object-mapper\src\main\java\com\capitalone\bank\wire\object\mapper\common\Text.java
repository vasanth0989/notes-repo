package com.capitalone.bank.wire.object.mapper.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import org.jspecify.annotations.Nullable;

/**
 * Text rules of ISO 20022: trimming, the Max<i>n</i>Text lengths, external code shapes and the fixed
 * 140-character chunking used for bank-to-bank instructions. The payment object enforces none of these.
 */
public final class Text {

    /** Max35Text: identifiers, member ids, proprietary codes. */
    public static final int MAX_35 = 35;
    /** Max34Text: an account identification written as Othr/Id. */
    public static final int MAX_34 = 34;
    /** Max70Text: street names, address lines, account names. */
    public static final int MAX_70 = 70;
    /** Max16Text: building number, post code, post box. */
    public static final int MAX_16 = 16;
    /** Max140Text: party and agent names, remittance lines, instructions. */
    public static final int MAX_140 = 140;

    private static final Pattern EXTERNAL_CODE = Pattern.compile("[A-Z0-9]{1,4}");
    private static final Pattern COUNTRY = Pattern.compile("[A-Z]{2}");
    private static final Pattern BIC = Pattern.compile("[A-Z0-9]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?");
    private static final Pattern LEI = Pattern.compile("[A-Z0-9]{18}[0-9]{2}");
    private static final Pattern UUID_V4 =
            Pattern.compile("[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}");
    private static final Pattern IBAN = Pattern.compile("[A-Z]{2}[0-9]{2}[a-zA-Z0-9]{1,30}");

    private Text() {
    }

    /** The trimmed value, or empty when the value is null or blank. */
    public static Optional<String> clean(@Nullable String value) {
        return value == null || value.isBlank() ? Optional.empty() : Optional.of(value.strip());
    }

    public static boolean isBlank(@Nullable String value) {
        return value == null || value.isBlank();
    }

    public static boolean hasText(@Nullable String value) {
        return !isBlank(value);
    }

    /** The trimmed value; rejects null or blank. */
    public static String required(@Nullable String value, String path) {
        return clean(value).orElseThrow(() -> new MappingException(path, "is required"));
    }

    /** The trimmed value, rejected when longer than {@code max}. Use {@link #truncated} to cut instead. */
    public static String bounded(@Nullable String value, int max, String path) {
        var text = required(value, path);
        if (text.length() > max) {
            throw new MappingException(path, "exceeds " + max + " characters (" + text.length() + ")");
        }
        return text;
    }

    /** As {@link #bounded}, for an optional field. */
    public static Optional<String> boundedOptional(@Nullable String value, int max, String path) {
        return clean(value).map(text -> bounded(text, max, path));
    }

    /** The trimmed value cut to {@code max} characters, or empty. */
    public static Optional<String> truncated(@Nullable String value, int max) {
        return clean(value).map(text -> text.length() <= max ? text : text.substring(0, max));
    }

    /**
     * The text as repeating-element pieces: each line of the trimmed text (split on line breaks) is cut
     * into fixed-size pieces, in order; blank lines are dropped. Empty for a blank value.
     */
    public static List<String> chunks(@Nullable String value, int size) {
        var pieces = new ArrayList<String>();
        for (var line : clean(value).orElse("").split("\\R")) {
            var text = line.strip();
            for (int start = 0; start < text.length(); start += size) {
                pieces.add(text.substring(start, Math.min(text.length(), start + size)));
            }
        }
        return List.copyOf(pieces);
    }

    /** True when the value has the shape of an ISO external code (1 to 4 upper-case letters or digits). */
    public static boolean isExternalCode(String value) {
        return EXTERNAL_CODE.matcher(value).matches();
    }

    public static String upper(String value) {
        return value.strip().toUpperCase(java.util.Locale.ROOT);
    }

    /** ISO 3166 alpha-2, upper-cased. */
    public static String country(@Nullable String value, String path) {
        var code = upper(required(value, path));
        if (!COUNTRY.matcher(code).matches()) {
            throw new MappingException(path, "is not a two-letter country code");
        }
        return code;
    }

    public static String bic(@Nullable String value, String path) {
        var code = upper(required(value, path));
        if (!BIC.matcher(code).matches()) {
            throw new MappingException(path, "is not an 8 or 11 character BIC");
        }
        return code;
    }

    public static String lei(@Nullable String value, String path) {
        var code = upper(required(value, path));
        if (!LEI.matcher(code).matches()) {
            throw new MappingException(path, "is not a 20 character LEI");
        }
        return code;
    }

    /** UETR: a lower-case UUID version 4, as the UUIDv4Identifier pattern of the schema demands. */
    public static String uetr(@Nullable String value, String path) {
        var id = required(value, path).toLowerCase(java.util.Locale.ROOT);
        if (!UUID_V4.matcher(id).matches()) {
            throw new MappingException(path, "is not a UUID version 4");
        }
        return id;
    }

    public static String iban(@Nullable String value, String path) {
        var id = required(value, path).replace(" ", "");
        if (!IBAN.matcher(id).matches()) {
            throw new MappingException(path, "is not an IBAN");
        }
        return id;
    }
}
