package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ObjectFactory;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Objects;
import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.xml.sax.SAXException;

/**
 * Renders a pain.001.001.11 {@link Document} as XML and validates it against the schema shipped in the
 * jar. The XML is the Phase 2 asset (what Capital One sends to the banks once OPF is gone); the FIS JSON
 * rendering for Phase 1 is a separate step, see {@code json.Pain001V11JsonRenderer}.
 *
 * <p>Thread-safe: {@link JAXBContext} and {@link Schema} are immutable; a marshaller is created per call.
 */
public final class Pain001V11Marshaller {

    public static final String SCHEMA_RESOURCE = "/xsd/pain.001.001.11.xsd";

    private final JAXBContext context;
    private final Schema schema;
    private final ObjectFactory factory = new ObjectFactory();

    public Pain001V11Marshaller() {
        try {
            this.context = JAXBContext.newInstance(Document.class);
            var schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            schemaFactory.setProperty(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            try (var xsd = Objects.requireNonNull(Pain001V11Marshaller.class.getResourceAsStream(SCHEMA_RESOURCE),
                    "schema resource " + SCHEMA_RESOURCE)) {
                this.schema = schemaFactory.newSchema(new StreamSource(xsd));
            }
        } catch (JAXBException | SAXException | java.io.IOException e) {
            throw new IllegalStateException("Cannot initialise the pain.001.001.11 marshaller", e);
        }
    }

    /** Marshals the document to XML. With {@code validate} set, a schema violation throws {@link MappingException}. */
    public String toXml(Document document, boolean validate) {
        try {
            var marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
            if (validate) {
                marshaller.setSchema(schema);
            }
            var writer = new StringWriter();
            marshaller.marshal(factory.createDocument(document), writer);
            return writer.toString();
        } catch (JAXBException e) {
            throw new MappingException("Document", "pain.001.001.11 message is not schema-valid: " + rootMessage(e), e);
        }
    }

    /** Validates XML text against the schema; throws {@link MappingException} naming the first violation. */
    public void validate(String xml) {
        try {
            schema.newValidator().validate(new StreamSource(new StringReader(xml)));
        } catch (SAXException | java.io.IOException e) {
            throw new MappingException("Document", "pain.001.001.11 message is not schema-valid: " + rootMessage(e), e);
        }
    }

    public Schema schema() {
        return schema;
    }

    private static String rootMessage(Throwable t) {
        var cause = t;
        while (cause.getCause() != null) {
            cause = cause.getCause();
        }
        return String.valueOf(cause.getMessage());
    }
}
