package com.capitalone.bank.wire.object.mapper.common;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Currency;
import org.jspecify.annotations.Nullable;

/** Amount and currency rules: ISO 4217 codes and rounding to the currency's minor unit. */
public final class Amounts {

    /** ActiveOrHistoricCurrencyAndAmount allows 18 digits in all. */
    private static final int MAX_DIGITS = 18;

    private Amounts() {
    }

    /** Upper-cased ISO 4217 code; rejects anything the JDK does not know as a currency. */
    public static String currency(@Nullable String value, String path) {
        var code = Text.upper(Text.required(value, path));
        try {
            Currency.getInstance(code);
        } catch (IllegalArgumentException e) {
            throw new MappingException(path, "is not an ISO 4217 currency code", e);
        }
        return code;
    }

    /**
     * The amount rounded (half up) to the currency's minor unit, for example two decimals for USD and
     * none for JPY. Rejects null, zero, negative and amounts with more than 18 digits.
     */
    public static BigDecimal positive(@Nullable BigDecimal amount, String currency, String path) {
        if (amount == null) {
            throw new MappingException(path, "is required");
        }
        if (amount.signum() <= 0) {
            throw new MappingException(path, "must be greater than zero");
        }
        var scaled = amount.setScale(Currency.getInstance(currency).getDefaultFractionDigits(), RoundingMode.HALF_UP);
        if (scaled.precision() > MAX_DIGITS) {
            throw new MappingException(path, "exceeds 18 digits");
        }
        return scaled;
    }

    public static boolean isPositive(@Nullable BigDecimal amount) {
        return amount != null && amount.signum() > 0;
    }
}
