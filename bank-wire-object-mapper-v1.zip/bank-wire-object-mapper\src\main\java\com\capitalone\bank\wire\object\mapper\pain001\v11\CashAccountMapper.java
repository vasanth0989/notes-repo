package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.Amounts;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AccountIdentification4Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AccountSchemeName1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccount40;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CashAccountType2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GenericAccountIdentification1;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.AccountRules;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.AccountScheme;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.AccountType;
import com.capitalone.commercial.payx.sdp.payload.model.Account;
import java.util.Optional;
import java.util.Set;

/**
 * Payment-object {@link Account} to {@link CashAccount40}: IBAN when accountIdType says so, otherwise the
 * account number as Othr/Id with the scheme and type the {@link AccountRules} prescribe for the role
 * (debtor or creditor). The currency is the account's own currencyCode when present, else the one the
 * caller passes in.
 *
 * <p>The account number arrives tokenised from PayX; detokenisation (Turing) is the calling service's
 * job before or after mapping, not this library's.
 */
final class CashAccountMapper {

    enum Role { DEBTOR, CREDITOR }

    /** accountIdType values that mean IBAN: the word and the legacy single-letter code. */
    private static final Set<String> IBAN_TYPES = Set.of("IBAN", "I");
    private static final Set<String> CURRENT_ACCOUNT_TYPES = Set.of("DDA", "D", "CHK", "CACC", "CHECKING");
    private static final Set<String> SAVINGS_TYPES = Set.of("SVGS", "SAV", "SAVINGS");
    private static final String SCHEME_BBAN = "BBAN";
    private static final String SCHEME_PROPRIETARY = "Proprietary";
    private static final String TYPE_CURRENT_ACCOUNT = "CACC";
    private static final String TYPE_SAVINGS = "SVGS";
    private static final String TYPE_OTHER = "OTHR";

    private CashAccountMapper() {
    }

    static CashAccount40 account(Account account, Role role, Optional<String> currencyFallback, String path,
                                 AccountRules rules) {
        var number = Text.required(account.getAccountNumber(), path + ".accountNumber");
        var idType = Text.clean(account.getAccountIdType()).map(Text::upper);
        var scheme = role == Role.DEBTOR ? rules.debtorScheme() : rules.creditorScheme();
        var type = role == Role.DEBTOR ? rules.debtorType() : rules.creditorType();
        var target = new CashAccount40();

        var identification = new AccountIdentification4Choice();
        if (idType.filter(IBAN_TYPES::contains).isPresent()) {
            identification.setIBAN(Text.iban(number, path + ".accountNumber"));
        } else {
            var other = new GenericAccountIdentification1();
            other.setId(Text.bounded(number, Text.MAX_34, path + ".accountNumber"));
            schemeName(scheme).ifPresent(other::setSchmeNm);
            identification.setOthr(other);
        }
        target.setId(identification);

        accountType(type, idType).ifPresent(target::setTp);

        if (rules.writeCurrency()) {
            Text.clean(account.getCurrencyCode())
                    .map(value -> Amounts.currency(value, path + ".currencyCode"))
                    .or(() -> currencyFallback)
                    .ifPresent(target::setCcy);
        }
        return target;
    }

    /** An agent's account: Othr/Id only, as the payment object carries no more for it. */
    static CashAccount40 agentAccount(String number, String path) {
        var other = new GenericAccountIdentification1();
        other.setId(Text.bounded(number, Text.MAX_34, path));
        var identification = new AccountIdentification4Choice();
        identification.setOthr(other);
        var target = new CashAccount40();
        target.setId(identification);
        return target;
    }

    private static Optional<AccountSchemeName1Choice> schemeName(AccountScheme scheme) {
        var choice = new AccountSchemeName1Choice();
        switch (scheme) {
            case NONE -> {
                return Optional.empty();
            }
            case BBAN -> choice.setCd(SCHEME_BBAN);
            case PROPRIETARY -> choice.setPrtry(SCHEME_PROPRIETARY);
        }
        return Optional.of(choice);
    }

    private static Optional<CashAccountType2Choice> accountType(AccountType type, Optional<String> idType) {
        var choice = new CashAccountType2Choice();
        switch (type) {
            case NONE -> {
                return Optional.empty();
            }
            case CACC -> choice.setCd(TYPE_CURRENT_ACCOUNT);
            case FROM_ACCOUNT_ID_TYPE -> choice.setCd(idType.map(CashAccountMapper::externalType).orElse(TYPE_OTHER));
            case PROPRIETARY_RAW -> {
                if (idType.isEmpty()) {
                    return Optional.empty();
                }
                choice.setPrtry(idType.get());
            }
        }
        return Optional.of(choice);
    }

    private static String externalType(String idType) {
        if (CURRENT_ACCOUNT_TYPES.contains(idType)) {
            return TYPE_CURRENT_ACCOUNT;
        }
        if (SAVINGS_TYPES.contains(idType)) {
            return TYPE_SAVINGS;
        }
        return TYPE_OTHER;
    }
}
