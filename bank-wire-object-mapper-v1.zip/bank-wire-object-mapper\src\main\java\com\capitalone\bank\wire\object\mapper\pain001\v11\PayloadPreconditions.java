package com.capitalone.bank.wire.object.mapper.pain001.v11;

import static com.capitalone.bank.wire.object.mapper.common.Text.hasText;
import static com.capitalone.bank.wire.object.mapper.common.Text.isBlank;

import com.capitalone.bank.wire.object.mapper.common.Amounts;
import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Problems;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.DebtorAgentSource;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.IdentifierSource;
import com.capitalone.commercial.payx.sdp.payload.model.Bank;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * The "receive and validate" step: everything pain.001.001.11 makes mandatory, or that the rules
 * require, checked up front so the payment is rejected with the complete list of reasons.
 */
final class PayloadPreconditions {

    private PayloadPreconditions() {
    }

    static Problems check(SDPPayload payload, MappingContext context) {
        var rules = context.rules();
        var ids = rules.identifiers();
        var problems = new Problems();

        identifier(problems, payload, ids.messageId(), ids.fallbackToClientTransactionId(), "GrpHdr/MsgId");
        identifier(problems, payload, ids.paymentInformationId(), ids.fallbackToClientTransactionId(), "PmtInf/PmtInfId");
        identifier(problems, payload, ids.endToEndId(), ids.fallbackToClientTransactionId(), "CdtTrfTxInf/PmtId/EndToEndId");
        if (ids.uetrRequired()) {
            attempt(problems, () -> Text.uetr(payload.getSwiftEndToEndTransactionReference(),
                    "payload.swiftEndToEndTransactionReference"));
        }

        if (isBlank(payload.getValueDate())) {
            problems.add("payload.valueDate", "is required (PmtInf/ReqdExctnDt)");
        } else {
            try {
                DateTimeFormatter.ISO_LOCAL_DATE.parse(payload.getValueDate().strip());
            } catch (DateTimeParseException e) {
                problems.add("payload.valueDate", "must be a date in the form yyyy-MM-dd");
            }
        }

        amount(problems, payload);

        var payer = payload.getPayer();
        if (payer == null) {
            problems.add("payload.payer", "is required (PmtInf/Dbtr)");
        } else {
            if (isBlank(payer.getAccountNumber())) {
                problems.add("payload.payer.accountNumber", "is required (PmtInf/DbtrAcct)");
            }
            if (isBlank(payer.getAccountName()) && isBlank(payer.getAccountLastName())) {
                problems.add("payload.payer.accountName", "is required (PmtInf/Dbtr/Nm)");
            }
        }

        debtorAgent(problems, payload, context);

        var payee = payload.getPayee();
        if (payee == null) {
            problems.add("payload.payee", "is required (CdtTrfTxInf/Cdtr)");
        } else {
            if (isBlank(payee.getAccountNumber())) {
                problems.add("payload.payee.accountNumber", "is required (CdtTrfTxInf/CdtrAcct)");
            }
            if (isBlank(payee.getAccountName()) && isBlank(payee.getAccountLastName())) {
                problems.add("payload.payee.accountName", "is required (CdtTrfTxInf/Cdtr/Nm)");
            }
        }

        if (!identifiesABank(payload.getPayeeBank())) {
            problems.add("payload.payeeBank", "needs a BIC or a clearing system member id (CdtTrfTxInf/CdtrAgt)");
        }
        return problems;
    }

    private static void identifier(Problems problems, SDPPayload payload, IdentifierSource source,
                                   boolean fallback, String target) {
        var value = source.read(payload);
        if (isBlank(value) && fallback) {
            value = payload.getClientTransactionId();
        }
        if (isBlank(value)) {
            problems.add(source.path(), "is required (" + target + ")");
        } else if (value.strip().length() > Text.MAX_35) {
            problems.add(source.path(), "exceeds 35 characters (" + target + ")");
        }
    }

    private static void amount(Problems problems, SDPPayload payload) {
        var fx = payload.getExchangeRate();
        var foreignCurrency = fx == null ? null : fx.getForeignExchangeCurrencyCode();
        if (hasText(foreignCurrency)) {
            attempt(problems, () -> Amounts.currency(foreignCurrency, "payload.exchangeRate.foreignExchangeCurrencyCode"));
            if (Amounts.isPositive(payload.getTransactionAmount())) {
                attempt(problems, () -> Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode"));
            } else if (!Amounts.isPositive(fx.getInstructedAmount())) {
                problems.add("payload.transactionAmount",
                        "or payload.exchangeRate.instructedAmount must be greater than zero (CdtTrfTxInf/Amt)");
            }
        } else {
            attempt(problems, () -> Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode"));
            if (!Amounts.isPositive(payload.getTransactionAmount())) {
                problems.add("payload.transactionAmount", "must be greater than zero (CdtTrfTxInf/Amt)");
            }
        }
    }

    private static void debtorAgent(Problems problems, SDPPayload payload, MappingContext context) {
        boolean present = switch (context.rules().parties().debtorAgentSource()) {
            case PAYER_BANK -> identifiesABank(payload.getPayerBank());
            case ON_BEHALF_OF_PAYER -> payload.getOnBehalfOfPayer() != null
                    && hasText(payload.getOnBehalfOfPayer().getBankIdentifierCode());
            case CONTEXT -> false;
        };
        if (!present && context.debtorAgent() == null) {
            var source = context.rules().parties().debtorAgentSource();
            var field = source == DebtorAgentSource.ON_BEHALF_OF_PAYER ? "payload.onBehalfOfPayer" : "payload.payerBank";
            problems.add(field, "needs a BIC or a clearing system member id, or the context must name the debtor agent (PmtInf/DbtrAgt)");
        }
    }

    private static boolean identifiesABank(Bank bank) {
        return bank != null && (hasText(bank.getSwiftBankIdentifierCode()) || hasText(bank.getBankCode()));
    }

    private static void attempt(Problems problems, Runnable check) {
        try {
            check.run();
        } catch (MappingException e) {
            e.problems().forEach(p -> problems.add(p.path(), p.message()));
        }
    }
}
