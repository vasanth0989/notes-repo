package com.capitalone.bank.wire.object.mapper.pain001.v11.json;

import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * Placeholder for the Phase 1 rendering of the mapped message as the FIS Universal Execution JSON
 * (pain.001.001.11 with ISO long element names, inside the business application header).
 *
 * <p>Not implemented here on purpose: the JSON is the FIS API contract's shape, not a generic
 * XML-to-JSON conversion, and it belongs with the FIS client in Wire Rail II (bank-wire-rail-ii-api),
 * which owns the contract models and the header values. The FIS samples are kept under
 * {@code /samples/fis} in this jar so the target shape travels with the mapping.
 */
public final class Pain001V11JsonRenderer {

    /** FIS's own example request from the EP-POM-CCTI contract (customer credit transfer initiation, UC01). */
    public static final String FIS_EXAMPLE_REQUEST = "/samples/fis/fis-customer-credit-transfer-initiation-UC01.json";
    /** A USD wire request in the FIS shape, used for the Code Connect connectivity test. */
    public static final String FIS_USD_WIRE_REQUEST = "/samples/fis/fis-usd-wire-request-2026-10-22.json";

    /**
     * @throws UnsupportedOperationException always, until the FIS JSON story is implemented
     */
    public String toFisJson(Document document) {
        Objects.requireNonNull(document, "document");
        throw new UnsupportedOperationException(
                "FIS JSON rendering is not implemented in bank-wire-object-mapper; "
                        + "it is built in bank-wire-rail-ii-api from the FIS contract models. "
                        + "See the samples under /samples/fis.");
    }

    /** The text of one of the bundled FIS samples, for tests and stubs. */
    public static String sample(String resource) {
        try (InputStream in = Pain001V11JsonRenderer.class.getResourceAsStream(resource)) {
            if (in == null) {
                throw new IllegalArgumentException("No bundled sample " + resource);
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
