package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload:2.16-beta}. Field names, order and types follow that
 * version's sources; the stand-in carries the fields the wire mapper reads and leaves out nested objects it
 * never touches. Replace with the real library on the Capital One network ({@code -PpayxPayloadVersion}).
 * Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"remiterId", "methodOfRequest", "electronicValue"})
public class RelatedRemitterInfo {
    @JsonProperty("remiterId")
    private String remiterId;
    @JsonProperty("methodOfRequest")
    private String methodOfRequest;
    @JsonProperty("electronicValue")
    private String electronicValue;

    public String getRemiterId() {
        return remiterId;
    }

    public void setRemiterId(String remiterId) {
        this.remiterId = remiterId;
    }

    public String getMethodOfRequest() {
        return methodOfRequest;
    }

    public void setMethodOfRequest(String methodOfRequest) {
        this.methodOfRequest = methodOfRequest;
    }

    public String getElectronicValue() {
        return electronicValue;
    }

    public void setElectronicValue(String electronicValue) {
        this.electronicValue = electronicValue;
    }
}
