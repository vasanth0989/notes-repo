package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PostalAddress24;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.AddressStyle;
import com.capitalone.commercial.payx.sdp.payload.model.Address;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import org.jspecify.annotations.Nullable;

/**
 * Payment-object {@link Address} to {@link PostalAddress24}. Structured fields are copied one to one
 * (city or townName to TwnNm, stateCode or stateProvince to CtrySubDvsn); addressLine1 to 4 become
 * AdrLine. An address with nothing to say is omitted rather than written empty.
 */
final class PostalAddressMapper {

    /** PostalAddress24 allows up to seven address lines. */
    private static final int MAX_LINES = 7;

    private PostalAddressMapper() {
    }

    static Optional<PostalAddress24> map(@Nullable Address address, String path, AddressStyle style) {
        if (address == null) {
            return Optional.empty();
        }
        var target = new PostalAddress24();
        boolean any = false;

        if (style != AddressStyle.LINES_ONLY) {
            any |= set(address.getDepartment(), Text.MAX_70, path + ".department", target::setDept);
            any |= set(address.getSubDepartment(), Text.MAX_70, path + ".subDepartment", target::setSubDept);
            any |= set(address.getStreetName(), Text.MAX_70, path + ".streetName", target::setStrtNm);
            any |= set(address.getBuildingNumber(), Text.MAX_16, path + ".buildingNumber", target::setBldgNb);
            any |= set(address.getBuildingName(), Text.MAX_35, path + ".buildingName", target::setBldgNm);
            any |= set(address.getFloor(), Text.MAX_70, path + ".floor", target::setFlr);
            any |= set(address.getPostalBox(), Text.MAX_16, path + ".postalBox", target::setPstBx);
            any |= set(address.getRoom(), Text.MAX_70, path + ".room", target::setRoom);
            any |= set(address.getPostalCode(), Text.MAX_16, path + ".postalCode", target::setPstCd);
            any |= set(Text.clean(address.getCity()).orElse(address.getTownName()), Text.MAX_35,
                    path + ".city", target::setTwnNm);
            any |= set(address.getTownLocationName(), Text.MAX_35, path + ".townLocationName", target::setTwnLctnNm);
            any |= set(address.getDistrictName(), Text.MAX_35, path + ".districtName", target::setDstrctNm);
            any |= set(Text.clean(address.getStateCode()).orElse(address.getStateProvince()), Text.MAX_35,
                    path + ".stateCode", target::setCtrySubDvsn);
            var country = Text.clean(address.getCountryCode()).map(c -> Text.country(c, path + ".countryCode"));
            if (country.isPresent()) {
                target.setCtry(country.get());
                any = true;
            }
        }

        if (style != AddressStyle.STRUCTURED_ONLY) {
            var lines = List.of(
                    Text.clean(address.getAddressLine1()), Text.clean(address.getAddressLine2()),
                    Text.clean(address.getAddressLine3()), Text.clean(address.getAddressLine4()));
            int index = 0;
            for (var line : lines) {
                index++;
                if (line.isPresent()) {
                    target.getAdrLine().add(Text.bounded(line.get(), Text.MAX_70, path + ".addressLine" + index));
                    any = true;
                }
            }
            if (target.getAdrLine().size() > MAX_LINES) {
                throw new MappingException(path, "has more than " + MAX_LINES + " address lines");
            }
        }
        return any ? Optional.of(target) : Optional.empty();
    }

    private static boolean set(@Nullable String value, int max, String path, Consumer<String> setter) {
        var text = Text.boundedOptional(value, max, path);
        text.ifPresent(setter);
        return text.isPresent();
    }
}
