package com.capitalone.bank.wire.object.mapper.pain001.v11;

import java.time.Clock;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

/**
 * Values the mapping needs that do not come from the payment object. Supplied by the calling service
 * (Wire Rail II) from its configuration; the library reads no environment itself.
 *
 * @param initiatingParty  GrpHdr/InitgPty when the payment object carries no initiating party name
 * @param debtorAgent      PmtInf/DbtrAgt when the rules say {@code CONTEXT}, or when the chosen source is absent
 * @param initiationSource GrpHdr/InitnSrc, the initiating software (null to omit)
 * @param clock            source of GrpHdr/CreDtTm
 * @param rules            the named mapping rules
 */
public record MappingContext(
        InitiatingParty initiatingParty,
        @Nullable FinancialInstitution debtorAgent,
        @Nullable InitiationSource initiationSource,
        FisExtension fisExtension,
        Clock clock,
        MappingRules rules) {

    public MappingContext {
        Objects.requireNonNull(initiatingParty, "initiatingParty");
        Objects.requireNonNull(fisExtension, "fisExtension");
        Objects.requireNonNull(clock, "clock");
        Objects.requireNonNull(rules, "rules");
    }

    /** A context with the default rules, the system UTC clock, the FIS extension defaults and no fixed debtor agent. */
    public static MappingContext of(String initiatingPartyName) {
        return new MappingContext(new InitiatingParty(initiatingPartyName, null, null), null, null,
                FisExtension.defaults(), Clock.systemUTC(), MappingRules.defaults());
    }

    public MappingContext withRules(MappingRules value) {
        return new MappingContext(initiatingParty, debtorAgent, initiationSource, fisExtension, clock, value);
    }

    public MappingContext withClock(Clock value) {
        return new MappingContext(initiatingParty, debtorAgent, initiationSource, fisExtension, value, rules);
    }

    public MappingContext withDebtorAgent(@Nullable FinancialInstitution value) {
        return new MappingContext(initiatingParty, value, initiationSource, fisExtension, clock, rules);
    }

    public MappingContext withInitiationSource(@Nullable InitiationSource value) {
        return new MappingContext(initiatingParty, debtorAgent, value, fisExtension, clock, rules);
    }

    public MappingContext withFisExtension(FisExtension value) {
        return new MappingContext(initiatingParty, debtorAgent, initiationSource, value, clock, rules);
    }

    /**
     * The fixed values of the FIS payment-information supplement's {@code extension} block, as the FIS
     * sample requests show them. Their meaning for Discover's wires is an open question with FIS; a null
     * value is left out.
     *
     * @param instMethod   the samples carry "Person"
     * @param templateName the samples carry a placeholder; null omits it
     * @param accountType  the samples carry "Consumer"
     * @param waiveFees    "Y" or "N"
     */
    public record FisExtension(
            @Nullable String instMethod,
            @Nullable String templateName,
            @Nullable String accountType,
            @Nullable String waiveFees) {

        public static FisExtension defaults() {
            return new FisExtension("Person", null, "Consumer", "N");
        }
    }

    /**
     * @param name             Max140Text
     * @param anyBic           the BIC that identifies Capital One towards OPF (the V9 converter's wire entity id), or null
     * @param countryOfResidence ISO 3166 alpha-2, or null
     */
    public record InitiatingParty(String name, @Nullable String anyBic, @Nullable String countryOfResidence) {

        public InitiatingParty {
            if (name == null || name.isBlank()) {
                throw new IllegalArgumentException("initiating party name is required");
            }
        }
    }

    /** A fixed financial institution: a BIC, a clearing system member id (for example USABA + ABA number), or both. */
    public record FinancialInstitution(
            @Nullable String bicfi,
            @Nullable String clearingSystemCode,
            @Nullable String memberId,
            @Nullable String name) {

        public FinancialInstitution {
            if ((bicfi == null || bicfi.isBlank()) && (memberId == null || memberId.isBlank())) {
                throw new IllegalArgumentException("a BIC or a clearing system member id is required");
            }
        }
    }

    /** GrpHdr/InitnSrc: the software or channel that produced the message. */
    public record InitiationSource(String name, @Nullable String provider, @Nullable String version) {

        public InitiationSource {
            if (name == null || name.isBlank()) {
                throw new IllegalArgumentException("initiation source name is required");
            }
        }
    }
}
