/** Rules shared by every ISO 20022 mapping in this library: text lengths, dates, amounts, problem reporting. */
@org.jspecify.annotations.NullMarked
package com.capitalone.bank.wire.object.mapper.common;
