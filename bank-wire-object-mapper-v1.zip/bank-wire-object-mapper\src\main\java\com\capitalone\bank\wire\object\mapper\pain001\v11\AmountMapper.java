package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.Amounts;
import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ActiveOrHistoricCurrencyAndAmount;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.AmountType4Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.EquivalentAmount2;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ExchangeRate1;
import com.capitalone.commercial.payx.sdp.payload.model.ExchangeRate;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.math.BigDecimal;
import java.util.Optional;
import org.jspecify.annotations.Nullable;

/**
 * Amount, currency and FX. No exchangeRate (or one without a foreign currency): InstdAmt is
 * transactionAmount in currencyCode. With a foreign currency: when transactionAmount is absent or zero,
 * InstdAmt is exchangeRate.instructedAmount in the foreign currency; otherwise the FX amount style
 * decides between EqvtAmt (debit amount plus currency of transfer) and InstdAmt in the foreign currency.
 * Amounts are rounded to the currency's minor unit; the control sum is the amount written.
 */
final class AmountMapper {

    /**
     * @param amount       CdtTrfTxInf/Amt
     * @param controlSum   the value written, for GrpHdr/CtrlSum and PmtInf/CtrlSum
     * @param currencyOfTransfer the currency the creditor receives
     * @param exchangeRateInformation CdtTrfTxInf/XchgRateInf, or null
     */
    record MappedAmount(AmountType4Choice amount, BigDecimal controlSum, String currencyOfTransfer,
                        @Nullable ExchangeRate1 exchangeRateInformation) {
    }

    private AmountMapper() {
    }

    static MappedAmount map(SDPPayload payload, MappingRules rules) {
        var fx = payload.getExchangeRate();
        var foreignCurrency = fx == null ? Optional.<String>empty()
                : Text.clean(fx.getForeignExchangeCurrencyCode())
                        .map(value -> Amounts.currency(value, "payload.exchangeRate.foreignExchangeCurrencyCode"));
        var choice = new AmountType4Choice();

        if (foreignCurrency.isEmpty()) {
            var currency = Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode");
            var amount = Amounts.positive(payload.getTransactionAmount(), currency, "payload.transactionAmount");
            choice.setInstdAmt(money(amount, currency));
            return new MappedAmount(choice, amount, currency, exchangeRateInformation(fx, rules).orElse(null));
        }

        var foreign = foreignCurrency.get();
        if (!Amounts.isPositive(payload.getTransactionAmount())) {
            var amount = Amounts.positive(fx.getInstructedAmount(), foreign, "payload.exchangeRate.instructedAmount");
            choice.setInstdAmt(money(amount, foreign));
            return new MappedAmount(choice, amount, foreign, exchangeRateInformation(fx, rules).orElse(null));
        }

        var amount = switch (rules.amounts().fxAmountStyle()) {
            case EQUIVALENT_AMOUNT -> {
                var currency = Amounts.currency(payload.getCurrencyCode(), "payload.currencyCode");
                var debit = Amounts.positive(payload.getTransactionAmount(), currency, "payload.transactionAmount");
                var equivalent = new EquivalentAmount2();
                equivalent.setAmt(money(debit, currency));
                equivalent.setCcyOfTrf(foreign);
                choice.setEqvtAmt(equivalent);
                yield debit;
            }
            case INSTRUCTED_AMOUNT_ONLY -> {
                if (!Amounts.isPositive(fx.getInstructedAmount())) {
                    throw new MappingException("payload.exchangeRate.instructedAmount",
                            "is required for an FX payment when the amount style is INSTRUCTED_AMOUNT_ONLY");
                }
                var instructed = Amounts.positive(fx.getInstructedAmount(), foreign, "payload.exchangeRate.instructedAmount");
                choice.setInstdAmt(money(instructed, foreign));
                yield instructed;
            }
        };
        return new MappedAmount(choice, amount, foreign, exchangeRateInformation(fx, rules).orElse(null));
    }

    private static Optional<ExchangeRate1> exchangeRateInformation(@Nullable ExchangeRate fx, MappingRules rules) {
        if (fx == null) {
            return Optional.empty();
        }
        var information = new ExchangeRate1();
        boolean any = false;
        var rate = Text.clean(fx.getExchangeRate());
        if (rate.isPresent()) {
            try {
                information.setXchgRate(new BigDecimal(rate.get()));
            } catch (NumberFormatException e) {
                throw new MappingException("payload.exchangeRate.exchangeRate", "is not a number", e);
            }
            any = true;
        }
        var rateType = CodeTables.rateType(fx.getForeignExchangeTrade(), rules.codes());
        if (rateType.isPresent()) {
            information.setRateTp(rateType.get());
            any = true;
        }
        var contract = Text.boundedOptional(fx.getContractId(), Text.MAX_35, "payload.exchangeRate.contractId");
        if (contract.isPresent()) {
            information.setCtrctId(contract.get());
            any = true;
        }
        return any ? Optional.of(information) : Optional.empty();
    }

    private static ActiveOrHistoricCurrencyAndAmount money(BigDecimal amount, String currency) {
        var money = new ActiveOrHistoricCurrencyAndAmount();
        money.setValue(amount);
        money.setCcy(currency);
        return money;
    }
}
