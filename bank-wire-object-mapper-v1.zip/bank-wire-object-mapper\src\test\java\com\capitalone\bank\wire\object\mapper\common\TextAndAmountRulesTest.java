package com.capitalone.bank.wire.object.mapper.common;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;

class TextAndAmountRulesTest {

    @Test
    void chunksCutFixedPiecesAndIgnoreBlankText() {
        assertThat(Text.chunks("a".repeat(300), 140)).extracting(String::length).containsExactly(140, 140, 20);
        assertThat(Text.chunks("  short ", 140)).containsExactly("short");
        assertThat(Text.chunks("line one\r\nline two\n\n" + "x".repeat(150), 140))
                .containsExactly("line one", "line two", "x".repeat(140), "x".repeat(10));
        assertThat(Text.chunks("   ", 140)).isEmpty();
        assertThat(Text.chunks(null, 140)).isEmpty();
    }

    @Test
    void boundedRejectsLongTextWithoutRevealingIt() {
        assertThatThrownBy(() -> Text.bounded("x".repeat(36), Text.MAX_35, "payload.clientTransactionId"))
                .isInstanceOf(MappingException.class)
                .hasMessage("payload.clientTransactionId: exceeds 35 characters (36)");
        assertThat(Text.bounded("  ok  ", Text.MAX_35, "p")).isEqualTo("ok");
    }

    @Test
    void identifiersAreCheckedForShape() {
        assertThat(Text.uetr("699756B7-886A-4A70-8180-3E60E68DFD3E", "p")).isEqualTo("699756b7-886a-4a70-8180-3e60e68dfd3e");
        assertThatThrownBy(() -> Text.uetr("not-a-uuid", "p")).hasMessageContaining("UUID version 4");
        assertThat(Text.bic("cobadeffxxx", "p")).isEqualTo("COBADEFFXXX");
        assertThatThrownBy(() -> Text.bic("COBA", "p")).hasMessageContaining("BIC");
        assertThat(Text.iban("DE89 3704 0044 0532 0130 00", "p")).isEqualTo("DE89370400440532013000");
        assertThat(Text.country("us", "p")).isEqualTo("US");
        assertThatThrownBy(() -> Text.country("USA", "p")).hasMessageContaining("two-letter");
        assertThat(Text.isExternalCode("SUPP")).isTrue();
        assertThat(Text.isExternalCode("Same Day")).isFalse();
    }

    @Test
    void amountsAreRoundedToTheCurrencyMinorUnit() {
        assertThat(Amounts.positive(new BigDecimal("48750"), "USD", "p")).isEqualTo(new BigDecimal("48750.00"));
        assertThat(Amounts.positive(new BigDecimal("10.005"), "USD", "p")).isEqualTo(new BigDecimal("10.01"));
        assertThat(Amounts.positive(new BigDecimal("3500000.4"), "JPY", "p")).isEqualTo(new BigDecimal("3500000"));
        assertThatThrownBy(() -> Amounts.positive(BigDecimal.ZERO, "USD", "p")).hasMessageContaining("greater than zero");
        assertThatThrownBy(() -> Amounts.positive(null, "USD", "p")).hasMessageContaining("required");
        assertThat(Amounts.currency(" eur ", "p")).isEqualTo("EUR");
        assertThatThrownBy(() -> Amounts.currency("US DOLLARS", "p")).hasMessageContaining("ISO 4217");
    }

    @Test
    void datesAreStrictIsoAndDateOnly() {
        assertThat(IsoDates.parse("2026-10-23", "p")).isEqualTo(LocalDate.of(2026, 10, 23));
        assertThatThrownBy(() -> IsoDates.parse("10/23/2026", "p")).hasMessageContaining("yyyy-MM-dd");
        assertThat(IsoDates.date(LocalDate.of(2026, 10, 23)).toXMLFormat()).isEqualTo("2026-10-23");
    }

    @Test
    void mappingExceptionListsEveryProblem() {
        var problems = new Problems().add("payload.a", "is required").add("payload.b", "is required");

        assertThatThrownBy(problems::throwIfAny)
                .isInstanceOf(MappingException.class)
                .hasMessage("2 mapping problems: payload.a: is required; payload.b: is required");
        assertThat(new Problems().isEmpty()).isTrue();
    }
}
