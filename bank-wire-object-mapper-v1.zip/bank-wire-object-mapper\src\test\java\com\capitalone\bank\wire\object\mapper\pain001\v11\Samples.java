package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.FinancialInstitution;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.InitiatingParty;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.InitiationSource;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

/** The sample payment objects under src/test/resources/samples/sdp and the context the tests map them with. */
final class Samples {

    /** Fixed creation time so golden files are stable: 2026-10-23T13:56:05Z. */
    static final Clock FIXED_CLOCK = Clock.fixed(Instant.parse("2026-10-23T13:56:05Z"), ZoneOffset.UTC);

    private static final ObjectMapper JSON = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private Samples() {
    }

    /** The context Wire Rail II would supply: Discover Bank as initiating party and fallback debtor agent. */
    static MappingContext context(Clock clock) {
        return new MappingContext(
                new InitiatingParty("Discover Bank", null, "US"),
                new FinancialInstitution(null, "USABA", "031100649", "Discover Bank"),
                new InitiationSource("Payment Exchange Wire Rail II", "Capital One", "1"),
                MappingContext.FisExtension.defaults(),
                clock,
                MappingRules.defaults());
    }

    static MappingContext context() {
        return context(FIXED_CLOCK);
    }

    static SDPPayload load(String name) {
        try (InputStream in = Samples.class.getResourceAsStream("/samples/sdp/" + name + ".json")) {
            if (in == null) {
                throw new IllegalArgumentException("No sample " + name);
            }
            return JSON.readValue(in, SDPPayload.class);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    static SDPPayload load(Path file) {
        try {
            return JSON.readValue(Files.readAllBytes(file), SDPPayload.class);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
