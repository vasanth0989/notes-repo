package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.IdentifierRules;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.IdentifierSource;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.util.Optional;

/** Reads the Max35Text identifiers from the payment-object fields the rules name. */
final class Identifiers {

    private Identifiers() {
    }

    static String messageId(SDPPayload payload, IdentifierRules rules) {
        return read(payload, rules.messageId(), rules);
    }

    static String paymentInformationId(SDPPayload payload, IdentifierRules rules) {
        return read(payload, rules.paymentInformationId(), rules);
    }

    static String endToEndId(SDPPayload payload, IdentifierRules rules) {
        return read(payload, rules.endToEndId(), rules);
    }

    /** InstrId is optional in the schema: empty when the source (and the fallback) is blank. */
    static Optional<String> instructionId(SDPPayload payload, IdentifierRules rules) {
        var source = rules.instructionId();
        return Text.clean(source.read(payload))
                .or(() -> rules.fallbackToClientTransactionId()
                        ? Text.clean(payload.getClientTransactionId()) : Optional.empty())
                .map(value -> Text.bounded(value, Text.MAX_35, source.path()));
    }

    static Optional<String> uetr(SDPPayload payload, IdentifierRules rules) {
        var path = "payload.swiftEndToEndTransactionReference";
        if (rules.uetrRequired()) {
            return Optional.of(Text.uetr(payload.getSwiftEndToEndTransactionReference(), path));
        }
        return Text.clean(payload.getSwiftEndToEndTransactionReference()).map(value -> Text.uetr(value, path));
    }

    private static String read(SDPPayload payload, IdentifierSource source, IdentifierRules rules) {
        var value = Text.clean(source.read(payload));
        if (value.isEmpty() && rules.fallbackToClientTransactionId()) {
            value = Text.clean(payload.getClientTransactionId());
        }
        return Text.bounded(value.orElse(null), Text.MAX_35, source.path());
    }
}
