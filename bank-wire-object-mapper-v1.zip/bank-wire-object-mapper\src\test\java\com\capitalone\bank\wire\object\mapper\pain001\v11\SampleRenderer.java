package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.util.List;
import java.util.stream.Stream;

/**
 * Maps every SDPPayload sample in a directory to pain.001.001.11 XML, validates it against the schema
 * and writes it next to a summary. Run with {@code ./gradlew renderSamples [-Psample=<name>]}.
 *
 * <p>Arguments: the sample directory, the output directory, and optionally one sample name (without
 * {@code .json}). Samples whose name starts with {@code invalid-} are expected to be rejected; the
 * rejection reasons are printed and written as {@code <name>.rejected.txt}.
 */
public final class SampleRenderer {

    private SampleRenderer() {
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 2) {
            System.err.println("usage: SampleRenderer <sample-dir> <out-dir> [sample-name]");
            System.exit(2);
        }
        var sampleDir = Path.of(args[0]);
        var outDir = Path.of(args[1]);
        Files.createDirectories(outDir);
        var only = args.length > 2 ? args[2] : null;

        List<Path> samples;
        try (Stream<Path> files = Files.list(sampleDir)) {
            samples = files.filter(p -> p.getFileName().toString().endsWith(".json"))
                    .filter(p -> only == null || p.getFileName().toString().equals(only + ".json"))
                    .sorted()
                    .toList();
        }
        if (samples.isEmpty()) {
            System.err.println("No sample found in " + sampleDir + (only == null ? "" : " named " + only));
            System.exit(2);
        }

        // -Dsample.clock=fixed renders with the test clock, which is how the golden files are produced.
        var clock = "fixed".equals(System.getProperty("sample.clock")) ? Samples.FIXED_CLOCK : Clock.systemUTC();
        var mapper = new Pain001V11Mapper(Samples.context(clock));
        int failures = 0;
        for (var sample : samples) {
            var name = sample.getFileName().toString().replace(".json", "");
            var expectedToFail = name.startsWith("invalid-");
            try {
                var xml = mapper.mapToXml(Samples.load(sample));
                var target = outDir.resolve(name + ".xml");
                Files.writeString(target, xml, StandardCharsets.UTF_8);
                System.out.println("OK       " + name + " -> " + target + " (" + xml.lines().count() + " lines, schema-valid)");
                if (expectedToFail) {
                    failures++;
                    System.out.println("         expected a rejection but the sample mapped");
                }
            } catch (MappingException e) {
                var target = outDir.resolve(name + ".rejected.txt");
                var reasons = String.join(System.lineSeparator(),
                        e.problems().stream().map(Object::toString).toList());
                Files.writeString(target, reasons, StandardCharsets.UTF_8);
                System.out.println((expectedToFail ? "REJECTED " : "FAILED   ") + name + " (" + e.problems().size()
                        + " problem" + (e.problems().size() == 1 ? "" : "s") + ")");
                e.problems().forEach(problem -> System.out.println("         " + problem));
                if (!expectedToFail) {
                    failures++;
                }
            }
        }
        System.out.println();
        System.out.println(samples.size() + " sample(s), " + failures + " unexpected result(s); output in " + outDir);
        if (failures > 0) {
            System.exit(1);
        }
    }
}
