/**
 * Payment Exchange payment object (SDPPayload) to ISO 20022 pain.001.001.11 customer credit transfer
 * initiation. Entry point: {@link com.capitalone.bank.wire.object.mapper.pain001.v11.Pain001V11Mapper}.
 */
@org.jspecify.annotations.NullMarked
package com.capitalone.bank.wire.object.mapper.pain001.v11;
