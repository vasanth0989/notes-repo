package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.BranchAndFinancialInstitutionIdentification6;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ClearingSystemIdentification2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ClearingSystemMemberIdentification2;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.FinancialInstitutionIdentification18;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.FinancialInstitution;
import com.capitalone.commercial.payx.sdp.payload.model.Account;
import com.capitalone.commercial.payx.sdp.payload.model.Bank;
import java.util.Optional;
import java.util.regex.Pattern;
import org.jspecify.annotations.Nullable;

/**
 * Payment-object {@link Bank} to {@link BranchAndFinancialInstitutionIdentification6}: BICFI from the
 * SWIFT code, ClrSysMmbId from the clearing system id and member code (a nine-digit code without a
 * system id is taken as USABA when the rule allows), LEI, name and address. An agent must carry a BIC
 * or a member id; a name alone is not an identification.
 */
final class AgentMapper {

    private static final Pattern NINE_DIGITS = Pattern.compile("\\d{9}");
    private static final String USABA = "USABA";

    private AgentMapper() {
    }

    static BranchAndFinancialInstitutionIdentification6 agent(Bank bank, String path, MappingRules rules) {
        var institution = new FinancialInstitutionIdentification18();
        Text.clean(bank.getSwiftBankIdentifierCode())
                .map(value -> Text.bic(value, path + ".swiftBankIdentifierCode"))
                .ifPresent(institution::setBICFI);
        Text.clean(bank.getBankCode()).ifPresent(code -> {
            var member = new ClearingSystemMemberIdentification2();
            member.setMmbId(Text.bounded(code, Text.MAX_35, path + ".bankCode"));
            clearingSystem(bank.getBankSystemIdentifier(), code, path, rules).ifPresent(member::setClrSysId);
            institution.setClrSysMmbId(member);
        });
        Text.clean(bank.getLegalEntityIdentifier())
                .map(value -> Text.lei(value, path + ".legalEntityIdentifier"))
                .ifPresent(institution::setLEI);
        PartyMapper.boundedName(bank.getBankName(), path + ".bankName", rules.parties().namePolicy())
                .ifPresent(institution::setNm);
        PostalAddressMapper.map(bank.getAddress(), path + ".address", rules.parties().addressStyle())
                .ifPresent(institution::setPstlAdr);
        if (institution.getBICFI() == null && institution.getClrSysMmbId() == null) {
            throw new MappingException(path, "needs a BIC or a clearing system member id");
        }
        return wrap(institution);
    }

    /** Empty when the bank is absent or carries no identification at all. */
    static Optional<BranchAndFinancialInstitutionIdentification6> optionalAgent(@Nullable Bank bank, String path,
                                                                                MappingRules rules) {
        if (bank == null || (Text.isBlank(bank.getSwiftBankIdentifierCode()) && Text.isBlank(bank.getBankCode()))) {
            return Optional.empty();
        }
        return Optional.of(agent(bank, path, rules));
    }

    /** The V9 reading of onBehalfOfPayer as a bank: its BIC, LEI, name and address. */
    static Optional<BranchAndFinancialInstitutionIdentification6> fromParty(@Nullable Account party, String path,
                                                                            MappingRules rules) {
        if (party == null || Text.isBlank(party.getBankIdentifierCode())) {
            return Optional.empty();
        }
        var institution = new FinancialInstitutionIdentification18();
        institution.setBICFI(Text.bic(party.getBankIdentifierCode(), path + ".bankIdentifierCode"));
        Text.clean(party.getLegalEntityIdentifier())
                .map(value -> Text.lei(value, path + ".legalEntityIdentifier"))
                .ifPresent(institution::setLEI);
        PartyMapper.name(party, path, rules.parties().namePolicy()).ifPresent(institution::setNm);
        PostalAddressMapper.map(party.getAddress(), path + ".address", rules.parties().addressStyle())
                .ifPresent(institution::setPstlAdr);
        return Optional.of(wrap(institution));
    }

    /** A fixed institution from the {@link MappingContext}. */
    static BranchAndFinancialInstitutionIdentification6 fromContext(FinancialInstitution fixed) {
        var path = "context.debtorAgent";
        var institution = new FinancialInstitutionIdentification18();
        Text.clean(fixed.bicfi()).map(value -> Text.bic(value, path + ".bicfi")).ifPresent(institution::setBICFI);
        Text.clean(fixed.memberId()).ifPresent(code -> {
            var member = new ClearingSystemMemberIdentification2();
            member.setMmbId(Text.bounded(code, Text.MAX_35, path + ".memberId"));
            Text.clean(fixed.clearingSystemCode())
                    .map(system -> CodeTables.clearingSystem(system, path + ".clearingSystemCode"))
                    .ifPresent(member::setClrSysId);
            institution.setClrSysMmbId(member);
        });
        Text.boundedOptional(fixed.name(), Text.MAX_140, path + ".name").ifPresent(institution::setNm);
        return wrap(institution);
    }

    private static Optional<ClearingSystemIdentification2Choice> clearingSystem(@Nullable String systemId, String code,
                                                                                String path, MappingRules rules) {
        var system = Text.clean(systemId);
        if (system.isPresent()) {
            return Optional.of(CodeTables.clearingSystem(system.get(), path + ".bankSystemIdentifier"));
        }
        if (rules.codes().inferUsabaFromNineDigitBankCode() && NINE_DIGITS.matcher(code.strip()).matches()) {
            var choice = new ClearingSystemIdentification2Choice();
            choice.setCd(USABA);
            return Optional.of(choice);
        }
        return Optional.empty();
    }

    private static BranchAndFinancialInstitutionIdentification6 wrap(FinancialInstitutionIdentification18 institution) {
        var agent = new BranchAndFinancialInstitutionIdentification6();
        agent.setFinInstnId(institution);
        return agent;
    }
}
