package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CustomerCreditTransferInitiationV11;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.util.Objects;

/**
 * Maps one Payment Exchange payment object ({@link SDPPayload}, an outbound GPN or corporate wire after
 * OFAC) to a pain.001.001.11 {@link Document}: one group header, one payment information block, one
 * credit transfer transaction.
 *
 * <p>The payment is checked first ({@link PayloadPreconditions}) so that a payment missing several
 * things is rejected with every reason at once; the builders then apply the rules of
 * {@link MappingRules} block by block. The mapping rules are documented in
 * {@code docs/pain001-v11-field-mapping.md} and the README.
 *
 * <p>Thread-safe; one instance per configuration is enough.
 */
public final class Pain001V11Mapper {

    private final MappingContext context;
    private final Pain001V11Marshaller marshaller;

    public Pain001V11Mapper(MappingContext context) {
        this.context = Objects.requireNonNull(context, "context");
        this.marshaller = new Pain001V11Marshaller();
    }

    /** The JAXB document for one payment. Throws {@link MappingException} with every problem found. */
    public Document map(SDPPayload payload) {
        Objects.requireNonNull(payload, "payload");
        PayloadPreconditions.check(payload, context).throwIfAny();

        var amount = AmountMapper.map(payload, context.rules());

        var initiation = new CustomerCreditTransferInitiationV11();
        initiation.setGrpHdr(new GroupHeaderBuilder(context).build(payload, amount));
        var instruction = new PaymentInformationBuilder(context).build(payload, amount);
        initiation.getPmtInf().add(instruction);

        if (context.rules().supplements().emitFisSupplements()) {
            var supplements = new FisSupplementMapper(context);
            instruction.getCdtTrfTxInf().getFirst().getSplmtryData().add(supplements.transactionSupplement(payload));
            initiation.getSplmtryData().add(supplements.paymentInformationSupplement(payload, amount.currencyOfTransfer()));
        }

        var document = new Document();
        document.setCstmrCdtTrfInitn(initiation);
        return document;
    }

    /** The pain.001.001.11 XML for one payment, validated against the schema before it is returned. */
    public String mapToXml(SDPPayload payload) {
        return marshaller.toXml(map(payload), true);
    }

    public MappingContext context() {
        return context;
    }
}
