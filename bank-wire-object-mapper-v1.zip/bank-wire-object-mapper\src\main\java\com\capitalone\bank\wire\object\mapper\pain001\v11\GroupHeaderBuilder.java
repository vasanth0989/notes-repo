package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.IsoDates;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.GroupHeader95;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.OrganisationIdentification29;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Party38Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PartyIdentification135;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentInitiationSource1;
import com.capitalone.bank.wire.object.mapper.pain001.v11.AmountMapper.MappedAmount;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.time.OffsetDateTime;
import java.util.Optional;

/** GrpHdr: message id, creation time, one transaction, control sum, initiating party, initiation source. */
final class GroupHeaderBuilder {

    static final String ONE_TRANSACTION = "1";

    private final MappingContext context;

    GroupHeaderBuilder(MappingContext context) {
        this.context = context;
    }

    GroupHeader95 build(SDPPayload payload, MappedAmount amount) {
        var rules = context.rules();
        var header = new GroupHeader95();
        header.setMsgId(Identifiers.messageId(payload, rules.identifiers()));
        header.setCreDtTm(IsoDates.dateTime(OffsetDateTime.now(context.clock())));
        header.setNbOfTxs(ONE_TRANSACTION);
        header.setCtrlSum(amount.controlSum());
        header.setInitgPty(initiatingParty(payload));
        if (rules.header().emitInitiationSource() && context.initiationSource() != null) {
            header.setInitnSrc(initiationSource());
        }
        return header;
    }

    /** The payment object's initiating party when it has a name; otherwise the fixed party from the context. */
    private PartyIdentification135 initiatingParty(SDPPayload payload) {
        return Optional.ofNullable(payload.getInitiatingParty())
                .filter(party -> Text.hasText(party.getAccountName()))
                .map(party -> PartyMapper.party(party, "payload.initiatingParty", context.rules().parties()))
                .orElseGet(this::contextInitiatingParty);
    }

    private PartyIdentification135 contextInitiatingParty() {
        var fixed = context.initiatingParty();
        var path = "context.initiatingParty";
        var party = new PartyIdentification135();
        party.setNm(Text.bounded(fixed.name(), Text.MAX_140, path + ".name"));
        Text.clean(fixed.anyBic()).map(value -> Text.bic(value, path + ".anyBic")).ifPresent(bic -> {
            var organisation = new OrganisationIdentification29();
            organisation.setAnyBIC(bic);
            var choice = new Party38Choice();
            choice.setOrgId(organisation);
            party.setId(choice);
        });
        Text.clean(fixed.countryOfResidence())
                .map(value -> Text.country(value, path + ".countryOfResidence"))
                .ifPresent(party::setCtryOfRes);
        return party;
    }

    private PaymentInitiationSource1 initiationSource() {
        var fixed = context.initiationSource();
        var path = "context.initiationSource";
        var source = new PaymentInitiationSource1();
        source.setNm(Text.bounded(fixed.name(), Text.MAX_140, path + ".name"));
        Text.boundedOptional(fixed.provider(), Text.MAX_35, path + ".provider").ifPresent(source::setPrvdr);
        Text.boundedOptional(fixed.version(), Text.MAX_35, path + ".version").ifPresent(source::setVrsn);
        return source;
    }
}
