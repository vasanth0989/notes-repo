package com.capitalone.bank.wire.object.mapper.pain001.v11;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

/**
 * The full XML of each valid sample against its golden file under src/test/resources/golden. The clock is
 * fixed, so the output is byte-for-byte stable apart from line endings. Regenerate a golden file with
 * {@code ./gradlew renderSamples} only after reviewing the diff.
 */
class GoldenXmlTest {

    @ParameterizedTest
    @ValueSource(strings = {"gpn-usd-wire", "corp-fx-eur-wire", "corp-on-behalf-of-wire", "fx-instructed-amount-only",
            "fis-bank-transfer", "fis-customer-transfer", "fis-intermediary-customer-transfer", "fis-drawdown-structured"})
    void sampleMatchesItsGoldenFile(String name) throws IOException {
        var xml = new Pain001V11Mapper(Samples.context()).mapToXml(Samples.load(name));

        assertThat(normalise(xml)).isEqualTo(normalise(golden(name)));
    }

    private static String golden(String name) throws IOException {
        try (InputStream in = GoldenXmlTest.class.getResourceAsStream("/golden/" + name + ".xml")) {
            if (in == null) {
                throw new IllegalStateException("No golden file for " + name);
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static String normalise(String xml) {
        return xml.replace("\r\n", "\n").strip();
    }
}
