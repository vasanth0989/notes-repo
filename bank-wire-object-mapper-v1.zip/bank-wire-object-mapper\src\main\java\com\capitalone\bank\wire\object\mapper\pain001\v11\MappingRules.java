package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ChargeBearerType1Code;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.util.Objects;
import org.jspecify.annotations.Nullable;

/**
 * The named, configurable rules of the mapping: every place where the mapping document records a
 * decision still open with the tech lead or FIS is a field here, so the answer changes one value and
 * not the mapping code. {@link #defaults()} holds the recommended answers.
 */
public record MappingRules(
        IdentifierRules identifiers,
        PartyRules parties,
        AccountRules accounts,
        CodeRules codes,
        AmountRules amounts,
        TextRules texts,
        HeaderRules header,
        SupplementRules supplements) {

    public MappingRules {
        Objects.requireNonNull(identifiers, "identifiers");
        Objects.requireNonNull(parties, "parties");
        Objects.requireNonNull(accounts, "accounts");
        Objects.requireNonNull(codes, "codes");
        Objects.requireNonNull(amounts, "amounts");
        Objects.requireNonNull(texts, "texts");
        Objects.requireNonNull(header, "header");
        Objects.requireNonNull(supplements, "supplements");
    }

    /** The recommended rules: the field mapping document, adjusted to the FIS sample requests of 2026-11-02. */
    public static MappingRules defaults() {
        return new MappingRules(IdentifierRules.defaults(), PartyRules.defaults(), AccountRules.defaults(),
                CodeRules.defaults(), AmountRules.defaults(), TextRules.defaults(), HeaderRules.defaults(),
                SupplementRules.defaults());
    }

    public MappingRules withIdentifiers(IdentifierRules value) {
        return new MappingRules(value, parties, accounts, codes, amounts, texts, header, supplements);
    }

    public MappingRules withParties(PartyRules value) {
        return new MappingRules(identifiers, value, accounts, codes, amounts, texts, header, supplements);
    }

    public MappingRules withAccounts(AccountRules value) {
        return new MappingRules(identifiers, parties, value, codes, amounts, texts, header, supplements);
    }

    public MappingRules withCodes(CodeRules value) {
        return new MappingRules(identifiers, parties, accounts, value, amounts, texts, header, supplements);
    }

    public MappingRules withAmounts(AmountRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, value, texts, header, supplements);
    }

    public MappingRules withTexts(TextRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, amounts, value, header, supplements);
    }

    public MappingRules withHeader(HeaderRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, amounts, texts, value, supplements);
    }

    public MappingRules withSupplements(SupplementRules value) {
        return new MappingRules(identifiers, parties, accounts, codes, amounts, texts, header, value);
    }

    /** Which payment-object field feeds an identifier (mapping document, open question 2). */
    public enum IdentifierSource {
        CLIENT_TRANSACTION_ID("clientTransactionId") {
            @Override
            @Nullable String read(SDPPayload payload) {
                return payload.getClientTransactionId();
            }
        },
        INSTRUCTION_ID("instructionId") {
            @Override
            @Nullable String read(SDPPayload payload) {
                return payload.getInstructionId();
            }
        },
        END_TO_END_ID("endToEndId") {
            @Override
            @Nullable String read(SDPPayload payload) {
                return payload.getEndToEndId();
            }
        },
        MESSAGE_TRANSMISSION_ID("messageTransmissionId") {
            @Override
            @Nullable String read(SDPPayload payload) {
                return payload.getMessageTransmissionId();
            }
        },
        TRANSACTION_ID("transactionId") {
            @Override
            @Nullable String read(SDPPayload payload) {
                return payload.getTransactionId();
            }
        };

        private final String field;

        IdentifierSource(String field) {
            this.field = field;
        }

        /** The payment-object path, for problem reports. */
        public String path() {
            return "payload." + field;
        }

        abstract @Nullable String read(SDPPayload payload);
    }

    /**
     * @param messageId           source of GrpHdr/MsgId
     * @param paymentInformationId source of PmtInf/PmtInfId
     * @param instructionId       source of CdtTrfTxInf/PmtId/InstrId
     * @param endToEndId          source of CdtTrfTxInf/PmtId/EndToEndId
     * @param fallbackToClientTransactionId when a chosen source is blank, use clientTransactionId instead of rejecting
     * @param uetrRequired        reject a payment without a UETR (swiftEndToEndTransactionReference)
     */
    public record IdentifierRules(
            IdentifierSource messageId,
            IdentifierSource paymentInformationId,
            IdentifierSource instructionId,
            IdentifierSource endToEndId,
            boolean fallbackToClientTransactionId,
            boolean uetrRequired) {

        public static IdentifierRules defaults() {
            return new IdentifierRules(IdentifierSource.CLIENT_TRANSACTION_ID, IdentifierSource.CLIENT_TRANSACTION_ID,
                    IdentifierSource.INSTRUCTION_ID, IdentifierSource.END_TO_END_ID, true, true);
        }

        public IdentifierRules withUetrRequired(boolean value) {
            return new IdentifierRules(messageId, paymentInformationId, instructionId, endToEndId,
                    fallbackToClientTransactionId, value);
        }

        public IdentifierRules withEndToEndId(IdentifierSource value) {
            return new IdentifierRules(messageId, paymentInformationId, instructionId, value,
                    fallbackToClientTransactionId, uetrRequired);
        }
    }

    /** Where PmtInf/DbtrAgt comes from (open question 1). */
    public enum DebtorAgentSource {
        /** payerBank, the debtor's bank as the payment object names it. */
        PAYER_BANK,
        /** onBehalfOfPayer treated as a bank, as the V9 reference converter does. */
        ON_BEHALF_OF_PAYER,
        /** The fixed Capital One agent given in the {@link MappingContext}. */
        CONTEXT
    }

    /** Which address elements are written (open question 6 and FIS question 13). */
    public enum AddressStyle {
        /** Structured fields and address lines, whatever the payment object carries. */
        STRUCTURED_AND_LINES,
        /** Structured fields only; address lines dropped. */
        STRUCTURED_ONLY,
        /** Address lines only; structured fields dropped. */
        LINES_ONLY
    }

    /** The scheme name written with a non-IBAN account identification (Othr/SchmeNm). */
    public enum AccountScheme {
        /** No scheme name, as the FIS samples show for the debtor account. */
        NONE,
        /** SchmeNm/Cd = BBAN (ISO external code). */
        BBAN,
        /** SchmeNm/Prtry = "Proprietary", as the FIS samples show for the creditor account. */
        PROPRIETARY
    }

    /** The account type written as *Acct/Tp. */
    public enum AccountType {
        /** Nothing, as the FIS samples show for the creditor account. */
        NONE,
        /** Tp/Cd from accountIdType: DDA, CHK, CACC become CACC; SVGS, SAV become SVGS; anything else OTHR (FIS debtor account). */
        FROM_ACCOUNT_ID_TYPE,
        /** Tp/Cd = CACC always. */
        CACC,
        /** Tp/Prtry = the raw accountIdType, as the V9 reference converter does. */
        PROPRIETARY_RAW
    }

    /** How the debtor and creditor accounts are written; the defaults follow the FIS sample requests. */
    public record AccountRules(
            AccountScheme debtorScheme,
            AccountType debtorType,
            AccountScheme creditorScheme,
            AccountType creditorType,
            boolean writeCurrency) {

        public static AccountRules defaults() {
            return new AccountRules(AccountScheme.NONE, AccountType.FROM_ACCOUNT_ID_TYPE,
                    AccountScheme.PROPRIETARY, AccountType.NONE, true);
        }

        public AccountRules withDebtor(AccountScheme scheme, AccountType type) {
            return new AccountRules(scheme, type, creditorScheme, creditorType, writeCurrency);
        }

        public AccountRules withCreditor(AccountScheme scheme, AccountType type) {
            return new AccountRules(debtorScheme, debtorType, scheme, type, writeCurrency);
        }

        public AccountRules withWriteCurrency(boolean value) {
            return new AccountRules(debtorScheme, debtorType, creditorScheme, creditorType, value);
        }
    }

    /** Precedence between ultimateDebtor and onBehalfOfPayer for CdtTrfTxInf/UltmtDbtr (open question 7). */
    public enum UltimateDebtorSource {
        ULTIMATE_DEBTOR_THEN_ON_BEHALF_OF_PAYER,
        ULTIMATE_DEBTOR_ONLY
    }

    /** What to do with a text longer than its Max<i>n</i>Text (open question 10). */
    public enum LongTextPolicy {
        REJECT,
        TRUNCATE,
        /** Only for repeating elements such as RmtInf/Ustrd: one element per 140-character piece. */
        SPLIT
    }

    public record PartyRules(
            DebtorAgentSource debtorAgentSource,
            UltimateDebtorSource ultimateDebtorSource,
            AddressStyle addressStyle,
            LongTextPolicy namePolicy) {

        public PartyRules {
            if (namePolicy == LongTextPolicy.SPLIT) {
                throw new IllegalArgumentException("a name cannot be split");
            }
        }

        public static PartyRules defaults() {
            return new PartyRules(DebtorAgentSource.PAYER_BANK, UltimateDebtorSource.ULTIMATE_DEBTOR_THEN_ON_BEHALF_OF_PAYER,
                    AddressStyle.STRUCTURED_AND_LINES, LongTextPolicy.REJECT);
        }

        public PartyRules withDebtorAgentSource(DebtorAgentSource value) {
            return new PartyRules(value, ultimateDebtorSource, addressStyle, namePolicy);
        }

        public PartyRules withAddressStyle(AddressStyle value) {
            return new PartyRules(debtorAgentSource, ultimateDebtorSource, value, namePolicy);
        }

        public PartyRules withNamePolicy(LongTextPolicy value) {
            return new PartyRules(debtorAgentSource, ultimateDebtorSource, addressStyle, value);
        }
    }

    /** Whether a code is written into the ISO external-code slot or the proprietary slot (open question 3). */
    public enum CodeStyle {
        EXTERNAL_CODE,
        PROPRIETARY
    }

    /** What to do with a payment-object value that is not in the ISO code list (open question 5). */
    public enum UnknownCodePolicy {
        REJECT,
        USE_DEFAULT
    }

    /**
     * @param localInstrumentStyle    PmtTpInf/LclInstrm: Cd or Prtry for paymentTypeCode (BTR, CTR, CTRC ...)
     * @param chargeBearerPolicy      unknown chargedTo value: reject, or use the default
     * @param defaultChargeBearer     ChrgBr when chargedTo is absent (or unknown with USE_DEFAULT)
     * @param rateTypePolicy          unknown foreignExchangeTrade value: reject, or omit RateTp
     * @param inferUsabaFromNineDigitBankCode a nine-digit bankCode without bankSystemIdentifier is a USABA number
     */
    public record CodeRules(
            CodeStyle localInstrumentStyle,
            UnknownCodePolicy chargeBearerPolicy,
            ChargeBearerType1Code defaultChargeBearer,
            UnknownCodePolicy rateTypePolicy,
            boolean inferUsabaFromNineDigitBankCode) {

        /** EXTERNAL_CODE: the FIS samples carry BTR, CTR and DRC in localInstrument.code, not proprietary. */
        public static CodeRules defaults() {
            return new CodeRules(CodeStyle.EXTERNAL_CODE, UnknownCodePolicy.REJECT, ChargeBearerType1Code.SHAR,
                    UnknownCodePolicy.REJECT, true);
        }

        public CodeRules withLocalInstrumentStyle(CodeStyle value) {
            return new CodeRules(value, chargeBearerPolicy, defaultChargeBearer, rateTypePolicy, inferUsabaFromNineDigitBankCode);
        }

        public CodeRules withChargeBearerPolicy(UnknownCodePolicy value) {
            return new CodeRules(localInstrumentStyle, value, defaultChargeBearer, rateTypePolicy, inferUsabaFromNineDigitBankCode);
        }

        public CodeRules withRateTypePolicy(UnknownCodePolicy value) {
            return new CodeRules(localInstrumentStyle, chargeBearerPolicy, defaultChargeBearer, value, inferUsabaFromNineDigitBankCode);
        }
    }

    /** How an FX payment's amount is written (open question 4 and FIS question 12). */
    public enum FxAmountStyle {
        /** Amt/EqvtAmt: the debit amount in the account currency plus the currency of transfer, as V9 does. */
        EQUIVALENT_AMOUNT,
        /** Amt/InstdAmt in the foreign currency from exchangeRate.instructedAmount; EqvtAmt never used. */
        INSTRUCTED_AMOUNT_ONLY
    }

    public record AmountRules(FxAmountStyle fxAmountStyle) {

        public static AmountRules defaults() {
            return new AmountRules(FxAmountStyle.EQUIVALENT_AMOUNT);
        }
    }

    /**
     * @param remittancePolicy        remitterInfo.unstructuredInfo over 140 characters: split, truncate or reject
     * @param bankToBankSlashCleanup  replace every slash with a space when the sender is TMOBS, TMOBSDOM or OBS and the
     *                                text has more than one slash (a PIE work-around carried by the V9 converter)
     */
    public record TextRules(LongTextPolicy remittancePolicy, boolean bankToBankSlashCleanup) {

        public static TextRules defaults() {
            return new TextRules(LongTextPolicy.SPLIT, false);
        }

        public TextRules withRemittancePolicy(LongTextPolicy value) {
            return new TextRules(value, bankToBankSlashCleanup);
        }
    }

    /**
     * @param emitInitiationSource write GrpHdr/InitnSrc from the context (new in V11; not in the FIS samples, so off)
     */
    public record HeaderRules(boolean emitInitiationSource) {

        public static HeaderRules defaults() {
            return new HeaderRules(false);
        }
    }

    /**
     * The FIS supplementary data envelopes seen in every FIS sample request: a payment-information
     * supplement (first instruction receipt and trace identification plus an extension block) and a
     * transaction supplement (transaction trace identification). Written as SplmtryData envelopes in the
     * XML so the JSON rendering can copy them.
     *
     * @param emitFisSupplements  write the two envelopes
     * @param traceIdentifier     which identifier fills the three trace and receipt fields (the samples use the message id)
     */
    public record SupplementRules(boolean emitFisSupplements, IdentifierSource traceIdentifier) {

        public static SupplementRules defaults() {
            return new SupplementRules(true, IdentifierSource.CLIENT_TRANSACTION_ID);
        }

        public SupplementRules withEmitFisSupplements(boolean value) {
            return new SupplementRules(value, traceIdentifier);
        }
    }
}
