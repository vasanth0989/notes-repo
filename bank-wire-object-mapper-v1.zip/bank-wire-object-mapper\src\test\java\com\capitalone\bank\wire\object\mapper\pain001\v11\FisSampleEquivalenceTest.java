package com.capitalone.bank.wire.object.mapper.pain001.v11;

import static org.assertj.core.api.Assertions.assertThat;

import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CreditTransferTransaction54;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Document;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PaymentInstruction40;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.PostalAddress24;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.SupplementaryData1;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.InitiatingParty;
import com.capitalone.bank.wire.object.mapper.pain001.v11.json.Pain001V11JsonRenderer;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.List;
import java.util.stream.StreamSupport;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Element;

/**
 * Each FIS sample request (bank transfer, customer transfer, drawdown with structured addresses and
 * structured remittance) rebuilt from a payment object: the mapped message must carry the same values the
 * FIS JSON carries, element by element, so the JSON rendering in Wire Rail II has nothing to invent.
 */
class FisSampleEquivalenceTest {

    private static final ObjectMapper JSON = new ObjectMapper();

    /** The FIS samples are initiated by "EWB", so the context names it as the initiating party. */
    private final Pain001V11Mapper mapper = new Pain001V11Mapper(
            new MappingContext(new InitiatingParty("EWB", null, null), null, null,
                    new MappingContext.FisExtension("Person", "templateName", "Consumer", "N"),
                    Samples.FIXED_CLOCK, MappingRules.defaults()));

    @Test
    void bankTransferMatchesTheFisSample() throws IOException {
        var fis = fis("fisopf_api_bank_transfer_req.json");
        var document = mapper.map(Samples.load("fis-bank-transfer"));
        var instruction = instruction(document);
        var transaction = transaction(document);

        assertCommonShape(fis, document);
        assertThat(instruction.getDbtrAcct().getTp().getCd()).isEqualTo("OTHR");
        assertThat(instruction.getDbtrAgt().getFinInstnId().getBICFI())
                .isEqualTo(text(fis, "paymentInformation/0/debtorAgent/financialInstitutionIdentification/BICFI"));
        assertThat(transaction.getRmtInf().getUstrd())
                .containsExactly("Payroll Week 5 - March 2021", "Payroll Week 5 - March 2022");
        assertThat(transaction.getInstrForCdtrAgt()).extracting(i -> i.getInstrInf())
                .containsExactly("Payroll Week Value1", "Payroll Week Value2");
    }

    @Test
    void customerTransferMatchesTheFisSample() throws IOException {
        var fis = fis("fisopf_api_customer_transfer_req.json");
        var document = mapper.map(Samples.load("fis-customer-transfer"));
        var instruction = instruction(document);
        var transaction = transaction(document);

        assertCommonShape(fis, document);
        assertThat(instruction.getDbtrAcct().getTp().getCd()).isEqualTo("CACC");
        assertThat(instruction.getDbtrAgt().getFinInstnId().getClrSysMmbId().getMmbId()).isEqualTo(
                text(fis, "paymentInformation/0/debtorAgent/financialInstitutionIdentification/clearingSystemMemberIdentification/memberIdentification"));
        assertThat(transaction.getRmtInf().getUstrd()).containsExactly("Payroll Week 5 - March 2021");
        assertThat(transaction.getInstrForCdtrAgt()).isEmpty();
    }

    @Test
    void customerTransferWithIntermediaryMatchesTheFisSample() throws IOException {
        var fis = fis("fisopf_api_with_intermediary_customer_transfer_req.json");
        var document = mapper.map(Samples.load("fis-intermediary-customer-transfer"));
        var instruction = instruction(document);
        var transaction = transaction(document);

        assertCommonShape(fis, document);
        assertThat(instruction.getDbtrAcct().getTp().getCd()).isEqualTo("CACC");
        assertThat(instruction.getDbtrAgt().getFinInstnId().getBICFI())
                .isEqualTo(text(fis, "paymentInformation/0/debtorAgent/financialInstitutionIdentification/BICFI"));
        assertThat(instruction.getDbtrAgt().getFinInstnId().getClrSysMmbId()).isNull();
        assertThat(transaction.getIntrmyAgt1().getFinInstnId().getClrSysMmbId().getClrSysId().getCd()).isEqualTo("USABA");
        assertThat(transaction.getIntrmyAgt1().getFinInstnId().getClrSysMmbId().getMmbId())
                .isEqualTo(tx(fis).at("/intermediaryAgent1/financialInstitutionIdentification/clearingSystemMemberIdentification/memberIdentification").asText());
        assertThat(transaction.getIntrmyAgt1Acct()).isNull();
        assertThat(transaction.getIntrmyAgt2()).isNull();
        assertThat(transaction.getRmtInf().getUstrd())
                .containsExactlyElementsOf(texts(tx(fis).at("/remittanceInformation/unstructured")));
        assertThat(transaction.getInstrForCdtrAgt()).extracting(i -> i.getInstrInf())
                .containsExactlyElementsOf(texts(tx(fis).at("/instructionForCreditorAgent").findValues("instructionInformation")
                        .stream().reduce(JSON.createArrayNode(), (array, node) -> array.add(node), (a, b) -> a)));
    }

    @Test
    void drawdownWithStructuredAddressesMatchesTheFisSample() throws IOException {
        var fis = fis("fisopf_api_DRC_StructuredAndHybridAddress_StructuredRemittance_req.json");
        var document = mapper.map(Samples.load("fis-drawdown-structured"));
        var header = document.getCstmrCdtTrfInitn().getGrpHdr();
        var instruction = instruction(document);
        var transaction = transaction(document);

        assertCommonShape(fis, document);
        // The FIS sample has no end-to-end id; the mapper falls back to the message id.
        assertThat(transaction.getPmtId().getEndToEndId()).isEqualTo("CHANNEL_UNIQUEID4");

        assertAddress(header.getInitgPty().getPstlAdr(), fis.at("/groupHeader/initiatingParty/postalAddress"));
        assertAddress(instruction.getDbtr().getPstlAdr(), fis.at("/paymentInformation/0/debtor/postalAddress"));
        assertAddress(instruction.getDbtrAgt().getFinInstnId().getPstlAdr(),
                fis.at("/paymentInformation/0/debtorAgent/financialInstitutionIdentification/postalAddress"));
        assertThat(instruction.getDbtrAgt().getFinInstnId().getNm()).isNull();
        assertThat(instruction.getUltmtDbtr()).isNull();
        assertThat(transaction.getUltmtDbtr().getNm()).isEqualTo(text(fis, "paymentInformation/0/ultimateDebtor/name"));
        assertAddress(transaction.getUltmtDbtr().getPstlAdr(), fis.at("/paymentInformation/0/ultimateDebtor/postalAddress"));
        assertAddress(transaction.getIntrmyAgt1().getFinInstnId().getPstlAdr(),
                tx(fis).at("/intermediaryAgent1/financialInstitutionIdentification/postalAddress"));
        assertAddress(transaction.getCdtrAgt().getFinInstnId().getPstlAdr(),
                tx(fis).at("/creditorAgent/financialInstitutionIdentification/postalAddress"));
        assertAddress(transaction.getCdtr().getPstlAdr(), tx(fis).at("/creditor/postalAddress"));
        assertThat(transaction.getUltmtCdtr().getNm()).isEqualTo(tx(fis).at("/ultimateCreditor/name").asText());
        assertAddress(transaction.getUltmtCdtr().getPstlAdr(), tx(fis).at("/ultimateCreditor/postalAddress"));

        var structured = transaction.getRmtInf().getStrd().getFirst();
        assertThat(structured.getInvcr().getId().getOrgId().getOthr().getFirst().getId())
                .isEqualTo(tx(fis).at("/remittanceInformation/structured/0/invoicer/identification/organisationIdentification/other/0/identification").asText());
        assertThat(structured.getInvcee().getId().getOrgId().getOthr().getFirst().getId())
                .isEqualTo(tx(fis).at("/remittanceInformation/structured/0/invoicee/identification/organisationIdentification/other/0/identification").asText());
        assertThat(structured.getGrnshmtRmt()).isNull();
    }

    private static void assertCommonShape(JsonNode fis, Document document) {
        var header = document.getCstmrCdtTrfInitn().getGrpHdr();
        var instruction = instruction(document);
        var transaction = transaction(document);
        var fisInstruction = fis.at("/paymentInformation/0");
        var fisTransaction = tx(fis);

        assertThat(header.getMsgId()).isEqualTo(text(fis, "groupHeader/messageIdentification"));
        assertThat(header.getNbOfTxs()).isEqualTo(text(fis, "groupHeader/numberOfTransactions"));
        assertThat(header.getInitgPty().getNm()).isEqualTo(text(fis, "groupHeader/initiatingParty/name"));
        assertThat(header.getInitnSrc()).isNull();

        assertThat(instruction.getPmtInfId()).isEqualTo(fisInstruction.at("/paymentInformationIdentification").asText());
        assertThat(instruction.getPmtMtd().value()).isEqualTo(fisInstruction.at("/paymentMethod").asText());
        assertThat(transaction.getPmtTpInf().getLclInstrm().getCd())
                .isEqualTo(fisInstruction.at("/paymentTypeInformation/localInstrument/code").asText());
        assertThat(transaction.getPmtTpInf().getLclInstrm().getPrtry()).isNull();
        assertThat(instruction.getReqdExctnDt().getDt().toXMLFormat())
                .isEqualTo(fisInstruction.at("/requestedExecutionDate/date").asText());
        assertThat(instruction.getDbtr().getNm()).isEqualTo(fisInstruction.at("/debtor/name").asText());
        assertThat(instruction.getDbtr().getPstlAdr().getAdrLine())
                .containsExactlyElementsOf(texts(fisInstruction.at("/debtor/postalAddress/addressLine")));
        assertThat(instruction.getDbtrAcct().getId().getOthr().getId())
                .isEqualTo(fisInstruction.at("/debtorAccount/identification/other/identification").asText());
        assertThat(instruction.getDbtrAcct().getId().getOthr().getSchmeNm()).isNull();
        assertThat(instruction.getDbtrAcct().getTp().getCd()).isEqualTo(fisInstruction.at("/debtorAccount/type/code").asText());

        assertThat(transaction.getPmtId().getInstrId()).isEqualTo(fisTransaction.at("/paymentIdentification/instructionIdentification").asText());
        if (!fisTransaction.at("/paymentIdentification/endToEndIdentification").isMissingNode()) {
            assertThat(transaction.getPmtId().getEndToEndId())
                    .isEqualTo(fisTransaction.at("/paymentIdentification/endToEndIdentification").asText());
        }
        assertThat(transaction.getAmt().getInstdAmt().getValue().toPlainString())
                .isEqualTo(fisTransaction.at("/amount/instructedAmount/amount").asText());
        assertThat(transaction.getAmt().getInstdAmt().getCcy()).isEqualTo(fisTransaction.at("/amount/instructedAmount/currency").asText());
        assertThat(transaction.getChrgBr().value()).isEqualTo(fisTransaction.at("/chargeBearer").asText());
        assertThat(transaction.getCdtrAgt().getFinInstnId().getClrSysMmbId().getClrSysId().getCd())
                .isEqualTo(fisTransaction.at("/creditorAgent/financialInstitutionIdentification/clearingSystemMemberIdentification/clearingSystemIdentification/code").asText());
        assertThat(transaction.getCdtrAgt().getFinInstnId().getClrSysMmbId().getMmbId())
                .isEqualTo(fisTransaction.at("/creditorAgent/financialInstitutionIdentification/clearingSystemMemberIdentification/memberIdentification").asText());
        assertThat(transaction.getCdtr().getNm()).isEqualTo(fisTransaction.at("/creditor/name").asText());
        assertThat(transaction.getCdtr().getPstlAdr().getAdrLine())
                .containsExactlyElementsOf(texts(fisTransaction.at("/creditor/postalAddress/addressLine")));
        assertThat(transaction.getCdtrAcct().getId().getOthr().getId())
                .isEqualTo(fisTransaction.at("/creditorAccount/identification/other/identification").asText());
        assertThat(transaction.getCdtrAcct().getId().getOthr().getSchmeNm().getPrtry())
                .isEqualTo(fisTransaction.at("/creditorAccount/identification/other/schemeName/proprietary").asText());
        assertThat(transaction.getCdtrAcct().getTp()).isNull();

        // The two FIS supplements, with the same trace id as the sample.
        var transactionSupplement = supplement(transaction.getSplmtryData().getFirst());
        assertThat(transactionSupplement.getNamespaceURI()).isEqualTo(FisSupplementMapper.TRANSACTION_SCHEMA);
        assertThat(child(transactionSupplement, "transactionTraceIdentification"))
                .isEqualTo(fisTransaction.at("/supplementaryData/0/envelope/transactionInformationSupplement/transactionTraceIdentification").asText());

        var messageSupplement = document.getCstmrCdtTrfInitn().getSplmtryData().getFirst();
        assertThat(messageSupplement.getPlcAndNm()).isEqualTo(fis.at("/supplementaryData/0/placeAndName").asText());
        var paymentSupplement = supplement(messageSupplement);
        var fisSupplement = fis.at("/supplementaryData/0/envelope/paymentInformationSupplement");
        assertThat(paymentSupplement.getNamespaceURI()).isEqualTo(FisSupplementMapper.PAYMENT_INFORMATION_SCHEMA);
        assertThat(child(paymentSupplement, "firstInstructionReceiptIdentification"))
                .isEqualTo(fisSupplement.at("/firstInstructionReceiptIdentification").asText());
        assertThat(child(paymentSupplement, "firstInstructionTraceIdentification"))
                .isEqualTo(fisSupplement.at("/firstInstructionTraceIdentification").asText());
        var extension = (Element) paymentSupplement.getElementsByTagNameNS("*", "extension").item(0);
        assertThat(child(extension, "internationalPayment")).isEqualTo(fisSupplement.at("/extension/internationalPayment").asText());
        assertThat(child(extension, "instMethod")).isEqualTo(fisSupplement.at("/extension/instMethod").asText());
        assertThat(child(extension, "templateName")).isEqualTo(fisSupplement.at("/extension/templateName").asText());
        assertThat(child(extension, "waiveFees")).isEqualTo(fisSupplement.at("/extension/waiveFees").asText());
        assertThat(child(extension, "accountType")).isEqualToIgnoringCase(fisSupplement.at("/extension/accountType").asText());
    }

    private static void assertAddress(PostalAddress24 address, JsonNode fis) {
        assertThat(address.getDept()).isEqualTo(optional(fis, "department"));
        assertThat(address.getSubDept()).isEqualTo(optional(fis, "subDepartment"));
        assertThat(address.getStrtNm()).isEqualTo(optional(fis, "streetName"));
        assertThat(address.getBldgNb()).isEqualTo(optional(fis, "buildingNumber"));
        assertThat(address.getPstCd()).isEqualTo(optional(fis, "postCode"));
        assertThat(address.getTwnNm()).isEqualTo(optional(fis, "townName"));
        assertThat(address.getCtrySubDvsn()).isEqualTo(optional(fis, "countrySubDivision"));
        assertThat(address.getCtry()).isEqualTo(optional(fis, "country"));
        assertThat(address.getAdrLine()).containsExactlyElementsOf(texts(fis.at("/addressLine")));
    }

    private static JsonNode fis(String file) throws IOException {
        return JSON.readTree(Pain001V11JsonRenderer.sample("/samples/fis/" + file))
                .at("/businessDocument/customerCreditTransferInitiation");
    }

    private static JsonNode tx(JsonNode fis) {
        return fis.at("/paymentInformation/0/creditTransferTransactionInformation/0");
    }

    private static String text(JsonNode node, String path) {
        return node.at("/" + path).asText();
    }

    private static String optional(JsonNode node, String field) {
        var value = node.get(field);
        return value == null ? null : value.asText();
    }

    private static List<String> texts(JsonNode array) {
        return StreamSupport.stream(array.spliterator(), false).map(JsonNode::asText).toList();
    }

    private static PaymentInstruction40 instruction(Document document) {
        return document.getCstmrCdtTrfInitn().getPmtInf().getFirst();
    }

    private static CreditTransferTransaction54 transaction(Document document) {
        return instruction(document).getCdtTrfTxInf().getFirst();
    }

    private static Element supplement(SupplementaryData1 data) {
        return (Element) data.getEnvlp().getAny();
    }

    private static String child(Element parent, String name) {
        var nodes = parent.getElementsByTagNameNS("*", name);
        return nodes.getLength() == 0 ? null : nodes.item(0).getTextContent();
    }
}
