"""Writes the local stand-in classes of the Payment Exchange payment object library, version 2.16-beta.

Field names, order and types are transcribed from the library's sources (payx-payload-2.16-beta-sources.jar,
package com.capitalone.commercial.payx.sdp.payload.model) on 2026-11-04. The stand-in is a subset: it
carries every field the wire mapper reads plus the scalar fields of SDPPayload, and leaves out the nested
objects the mapper never touches (paymentStatus enum, letterDetail, originalMessageInfo, returnSpecificInfo,
acknowLedgementSpecific, enrichedDataInExchange, the notification objects, additionalInfoByChannel,
cardSpecificInfo). OptionalHeaderInfo, SupplementaryData and RelatedRemitterInfo were not photographed; their
fields follow the schema inventory, and the mapper reads only optionalHeaderInfo.senderMemberId, whose
accessor the 2.16-beta compile confirmed.
"""
import io
import os
import sys

OUT = sys.argv[1]
PKG = "com.capitalone.commercial.payx.sdp.payload.model"

S = "String"
B = "java.math.BigDecimal"
BOOL = "Boolean"

CLASSES = {
    # 22 fields, @JsonPropertyOrder of Address.java lines 15 to 37
    "Address": [(f, S) for f in [
        "addressLine1", "addressLine2", "addressLine3", "addressLine4", "buildingName", "city",
        "countryCode", "countryName", "districtName", "floor", "postalBox", "proxyAccountIdentification",
        "streetName", "buildingNumber", "postalCode", "room", "townName", "stateProvince", "stateCode",
        "department", "subDepartment", "townLocationName"]],
    # CustomerPersonalInfo.java lines 14 to 17: note the lower-case spelling of countryofbirth
    "CustomerPersonalInfo": [(f, S) for f in ["dateOfBirth", "cityOfBirth", "countryofbirth"]],
    # 23 fields, Account.java lines 15 to 38
    "Account": [(f, S) for f in [
        "accountHolderFullName", "accountNumber", "accountIdType", "identificationNumber", "identificationNumberType",
        "accountName", "accountSuffixName", "accountFirstName", "accountMiddleName", "accountLastName",
        "accountPrefixName", "alsoKnownAsName", "bankIdentifierCode", "currencyCode", "legalEntityIdentifier",
        "organizationIdentificationNumber", "organizationIdentificationNumberType", "otherIdentifier",
        "otherIdentifierType"]] + [("address", "Address"), ("customerPersonalInfo", "CustomerPersonalInfo")]
        + [(f, S) for f in ["sorId", "customerId"]],
    # 8 fields, Bank.java lines 15 to 23
    "Bank": [(f, S) for f in ["accountIdType", "bankAccountNumber", "bankName", "bankSystemIdentifier", "bankCode",
                              "legalEntityIdentifier", "swiftBankIdentifierCode"]] + [("address", "Address")],
    # PaymentType.java: one field
    "PaymentType": [("relatedReference", S)],
    # ExchangeRate.java lines 21 to 26; instructedAmount is BigDecimal
    "ExchangeRate": [("exchangeRate", S), ("foreignExchangeTrade", S), ("foreignExchangeCurrencyCode", S),
                     ("contractId", S), ("instructedAmount", B)],
    # 9 fields, RemitterInfo.java lines 20 to 29 (no relatedTime in this version)
    "RemitterInfo": [(f, S) for f in ["unstructuredInfo", "remitterId", "relatedDate",
                                      "invoicerIdentification", "invoiceeIdentification", "rtpRemitterId",
                                      "rtpRelatedDate", "documentCode", "documentProprietary"]],
    # not photographed: schema inventory
    "RelatedRemitterInfo": [(f, S) for f in ["remiterId", "methodOfRequest", "electronicValue"]],
    "SupplementaryData": [(f, S) for f in ["contractedCurrencyCode", "contractedDebitAmount", "initiatorId", "approverId"]],
    "OptionalHeaderInfo": [(f, S) for f in ["senderMemberId", "receiverMemberId", "senderBranchId", "receiverBranchId",
                                            "businessMsgId", "fromClearingSystemMemberId", "toClearingSystemMemberId",
                                            "businessService"]],
    # SDPPayload.java lines 25 to 95 (70 properties); nested objects the mapper never reads are left out
    "SDPPayload": [
        ("transactionAmount", B), ("traceNumber", S), ("discountAppliedAmount", B), ("returnAmount", B),
        ("currencyCode", S), ("paymentTypeCode", S), ("chargedTo", S), ("valueDate", S), ("bankToBank", S),
        ("instructionId", S), ("messageTransmissionId", S), ("transactionId", S), ("endToEndId", S),
        ("swiftEndToEndTransactionReference", S), ("batchId", S), ("clientTransactionId", S), ("checkNumber", S),
        ("paymentSourceChannelId", S), ("paymentSourceChannelDescription", S),
        # paymentStatus (SDPPayload.PaymentStatus enum) left out
        ("previousPaymentStatus", S), ("transactionDirectionName", S), ("messageFormat", S), ("paymentType", S),
        ("standardEntryCode", S), ("clearingSystem", S), ("clearingSystemReferenceNumber", S),
        ("previousClearingSystemReferenceNumber", S), ("clearingSystemOutputReferenceNumber", S),
        ("newPaymentTypeCode", S), ("serviceLevelCd", S), ("transactionReasonCd", S), ("localInstrumentCode", S),
        ("categoryPurpose", S), ("isSameDay", BOOL), ("exchangeRate", "ExchangeRate"),
        ("domesticPayment", "PaymentType"), ("internationalPayment", "PaymentType"), ("isDecisionMade", BOOL),
        ("decisionReasonCode", S),
        # letterDetail left out
        ("payer", "Account"), ("payee", "Account"), ("initiatingParty", "Account"), ("payeeBank", "Bank"),
        ("payerBank", "Bank"), ("firstIntermediaryBank", "Bank"), ("secondaryIntermediaryBank", "Bank"),
        ("senderCorrespondentBank", "Bank"), ("receiverCorrespondentBank", "Bank"), ("instructingAgent", "Bank"),
        # originalMessageInfo, returnSpecificInfo, acknowLedgementSpecific left out
        ("relatedRemitterInfo", "RelatedRemitterInfo"), ("remitterInfo", "RemitterInfo"), ("instructedAgent", "Bank"),
        # enrichedDataInExchange left out
        ("supplementaryData", "SupplementaryData"), ("onBehalfOfPayer", "Account"), ("ultimateCreditor", "Account"),
        ("ultimateDebtor", "Account"), ("optionalHeaderInfo", "OptionalHeaderInfo"),
        # eventNotification, messageRejectNotification, signOffRequestNotification, additionalInfoByChannel,
        # cardSpecificInfo left out
        ("relatedReference", S),
    ],
}

HEADER = """package %s;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload:2.16-beta}. Field names, order and types follow that
 * version's sources; the stand-in carries the fields the wire mapper reads and leaves out nested objects it
 * never touches. Replace with the real library on the Capital One network ({@code -PpayxPayloadVersion}).
 * Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({%s})
public class %s {
"""


def cap(s):
    return s[0].upper() + s[1:]


def write_class(name, fields):
    order = ", ".join('"%s"' % f for f, _ in fields)
    out = [HEADER % (PKG, order, name)]
    for f, t in fields:
        out.append('    @JsonProperty("%s")\n    private %s %s;\n' % (f, t, f))
    for f, t in fields:
        out.append('\n    public %s get%s() {\n        return %s;\n    }\n' % (t, cap(f), f))
        out.append('\n    public void set%s(%s %s) {\n        this.%s = %s;\n    }\n' % (cap(f), t, f, f, f))
    out.append("}\n")
    path = os.path.join(OUT, name + ".java")
    with io.open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("".join(out))


os.makedirs(OUT, exist_ok=True)
for cls, flds in CLASSES.items():
    write_class(cls, flds)
print("wrote", len(CLASSES), "classes to", OUT)
