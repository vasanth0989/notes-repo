package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.SupplementaryData1;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.SupplementaryDataEnvelope1;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingContext.FisExtension;
import com.capitalone.commercial.payx.sdp.payload.model.SDPPayload;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * The two FIS supplementary data envelopes that every FIS sample request carries, written as
 * {@code SplmtryData} elements so the XML is lossless and the JSON rendering only copies them:
 *
 * <ul>
 *   <li>at message level, placed on the payment information block: {@code paymentInformationSupplement}
 *       with the first instruction receipt and trace identification and an {@code extension} block
 *       (internationalPayment, instMethod, templateName, accountType, waiveFees);</li>
 *   <li>at transaction level: {@code transactionInformationSupplement} with the transaction trace
 *       identification.</li>
 * </ul>
 *
 * <p>The three identifications all carry the message id in the FIS samples. The extension values come
 * from the {@link MappingContext}, except {@code internationalPayment}, which is derived from the payment.
 */
final class FisSupplementMapper {

    static final String PAYMENT_INFORMATION_SCHEMA = "urn:fis:ep:supplement:pain.001.001.11:pmtinf:universal:1";
    static final String TRANSACTION_SCHEMA = "urn:fis:ep:supplement:pain.001.001.11:txinf:universal:1";
    /** The place-and-name the FIS samples use for the payment information supplement. */
    static final String PAYMENT_INFORMATION_PLACE = "$.businessDocument.customerCreditTransferInitiation.paymentInformation[0]";

    private static final Set<String> INTERNATIONAL_CLEARING_SYSTEMS = Set.of("SWIFT");
    private static final String DOMESTIC_CURRENCY = "USD";

    private final MappingContext context;
    private final DocumentBuilderFactory documents;

    FisSupplementMapper(MappingContext context) {
        this.context = context;
        this.documents = DocumentBuilderFactory.newInstance();
        this.documents.setNamespaceAware(true);
        try {
            this.documents.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        } catch (ParserConfigurationException e) {
            throw new IllegalStateException("Secure XML processing is not available", e);
        }
    }

    /** CstmrCdtTrfInitn/SplmtryData: the payment information supplement. */
    SupplementaryData1 paymentInformationSupplement(SDPPayload payload, String currencyOfTransfer) {
        var trace = traceIdentifier(payload);
        var values = new LinkedHashMap<String, String>();
        values.put("firstInstructionReceiptIdentification", trace);
        values.put("firstInstructionTraceIdentification", trace);

        var extension = new LinkedHashMap<String, String>();
        extension.put("internationalPayment", isInternational(payload, currencyOfTransfer) ? "Y" : "N");
        var defaults = context.fisExtension();
        Text.clean(defaults.instMethod()).ifPresent(v -> extension.put("instMethod", v));
        Text.clean(defaults.templateName()).ifPresent(v -> extension.put("templateName", v));
        Text.clean(defaults.accountType()).ifPresent(v -> extension.put("accountType", v));
        Text.clean(defaults.waiveFees()).ifPresent(v -> extension.put("waiveFees", v));

        var supplement = new SupplementaryData1();
        supplement.setPlcAndNm(PAYMENT_INFORMATION_PLACE);
        supplement.setEnvlp(envelope(PAYMENT_INFORMATION_SCHEMA, "paymentInformationSupplement", values, extension));
        return supplement;
    }

    /** CdtTrfTxInf/SplmtryData: the transaction supplement. */
    SupplementaryData1 transactionSupplement(SDPPayload payload) {
        var values = new LinkedHashMap<String, String>();
        values.put("transactionTraceIdentification", traceIdentifier(payload));
        var supplement = new SupplementaryData1();
        supplement.setEnvlp(envelope(TRANSACTION_SCHEMA, "transactionInformationSupplement", values, Map.of()));
        return supplement;
    }

    private String traceIdentifier(SDPPayload payload) {
        var source = context.rules().supplements().traceIdentifier();
        var value = Text.clean(source.read(payload)).or(() -> Text.clean(payload.getClientTransactionId()));
        return Text.bounded(value.orElse(null), Text.MAX_35, source.path());
    }

    /** International when the clearing system is SWIFT, the payment object carries internationalPayment, or the transfer is not in USD. */
    private static boolean isInternational(SDPPayload payload, String currencyOfTransfer) {
        var clearing = Text.clean(payload.getClearingSystem()).map(Text::upper);
        return clearing.filter(INTERNATIONAL_CLEARING_SYSTEMS::contains).isPresent()
                || payload.getInternationalPayment() != null
                || !DOMESTIC_CURRENCY.equals(currencyOfTransfer);
    }

    private SupplementaryDataEnvelope1 envelope(String schema, String rootName, Map<String, String> values,
                                               Map<String, String> extension) {
        Document document;
        try {
            document = documents.newDocumentBuilder().newDocument();
        } catch (ParserConfigurationException e) {
            throw new IllegalStateException("Cannot create a DOM document for the supplement", e);
        }
        var root = document.createElementNS(schema, rootName);
        document.appendChild(root);
        values.forEach((name, value) -> root.appendChild(text(document, schema, name, value)));
        if (!extension.isEmpty()) {
            var block = document.createElementNS(schema, "extension");
            extension.forEach((name, value) -> block.appendChild(text(document, schema, name, value)));
            root.appendChild(block);
        }
        var envelope = new SupplementaryDataEnvelope1();
        envelope.setAny(root);
        return envelope;
    }

    private static Element text(Document document, String namespace, String name, String value) {
        var element = document.createElementNS(namespace, name);
        element.setTextContent(value);
        return element;
    }
}
