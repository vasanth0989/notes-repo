package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload:2.16-beta}. Field names, order and types follow that
 * version's sources; the stand-in carries the fields the wire mapper reads and leaves out nested objects it
 * never touches. Replace with the real library on the Capital One network ({@code -PpayxPayloadVersion}).
 * Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"transactionAmount", "traceNumber", "discountAppliedAmount", "returnAmount", "currencyCode", "paymentTypeCode", "chargedTo", "valueDate", "bankToBank", "instructionId", "messageTransmissionId", "transactionId", "endToEndId", "swiftEndToEndTransactionReference", "batchId", "clientTransactionId", "checkNumber", "paymentSourceChannelId", "paymentSourceChannelDescription", "previousPaymentStatus", "transactionDirectionName", "messageFormat", "paymentType", "standardEntryCode", "clearingSystem", "clearingSystemReferenceNumber", "previousClearingSystemReferenceNumber", "clearingSystemOutputReferenceNumber", "newPaymentTypeCode", "serviceLevelCd", "transactionReasonCd", "localInstrumentCode", "categoryPurpose", "isSameDay", "exchangeRate", "domesticPayment", "internationalPayment", "isDecisionMade", "decisionReasonCode", "payer", "payee", "initiatingParty", "payeeBank", "payerBank", "firstIntermediaryBank", "secondaryIntermediaryBank", "senderCorrespondentBank", "receiverCorrespondentBank", "instructingAgent", "relatedRemitterInfo", "remitterInfo", "instructedAgent", "supplementaryData", "onBehalfOfPayer", "ultimateCreditor", "ultimateDebtor", "optionalHeaderInfo", "relatedReference"})
public class SDPPayload {
    @JsonProperty("transactionAmount")
    private java.math.BigDecimal transactionAmount;
    @JsonProperty("traceNumber")
    private String traceNumber;
    @JsonProperty("discountAppliedAmount")
    private java.math.BigDecimal discountAppliedAmount;
    @JsonProperty("returnAmount")
    private java.math.BigDecimal returnAmount;
    @JsonProperty("currencyCode")
    private String currencyCode;
    @JsonProperty("paymentTypeCode")
    private String paymentTypeCode;
    @JsonProperty("chargedTo")
    private String chargedTo;
    @JsonProperty("valueDate")
    private String valueDate;
    @JsonProperty("bankToBank")
    private String bankToBank;
    @JsonProperty("instructionId")
    private String instructionId;
    @JsonProperty("messageTransmissionId")
    private String messageTransmissionId;
    @JsonProperty("transactionId")
    private String transactionId;
    @JsonProperty("endToEndId")
    private String endToEndId;
    @JsonProperty("swiftEndToEndTransactionReference")
    private String swiftEndToEndTransactionReference;
    @JsonProperty("batchId")
    private String batchId;
    @JsonProperty("clientTransactionId")
    private String clientTransactionId;
    @JsonProperty("checkNumber")
    private String checkNumber;
    @JsonProperty("paymentSourceChannelId")
    private String paymentSourceChannelId;
    @JsonProperty("paymentSourceChannelDescription")
    private String paymentSourceChannelDescription;
    @JsonProperty("previousPaymentStatus")
    private String previousPaymentStatus;
    @JsonProperty("transactionDirectionName")
    private String transactionDirectionName;
    @JsonProperty("messageFormat")
    private String messageFormat;
    @JsonProperty("paymentType")
    private String paymentType;
    @JsonProperty("standardEntryCode")
    private String standardEntryCode;
    @JsonProperty("clearingSystem")
    private String clearingSystem;
    @JsonProperty("clearingSystemReferenceNumber")
    private String clearingSystemReferenceNumber;
    @JsonProperty("previousClearingSystemReferenceNumber")
    private String previousClearingSystemReferenceNumber;
    @JsonProperty("clearingSystemOutputReferenceNumber")
    private String clearingSystemOutputReferenceNumber;
    @JsonProperty("newPaymentTypeCode")
    private String newPaymentTypeCode;
    @JsonProperty("serviceLevelCd")
    private String serviceLevelCd;
    @JsonProperty("transactionReasonCd")
    private String transactionReasonCd;
    @JsonProperty("localInstrumentCode")
    private String localInstrumentCode;
    @JsonProperty("categoryPurpose")
    private String categoryPurpose;
    @JsonProperty("isSameDay")
    private Boolean isSameDay;
    @JsonProperty("exchangeRate")
    private ExchangeRate exchangeRate;
    @JsonProperty("domesticPayment")
    private PaymentType domesticPayment;
    @JsonProperty("internationalPayment")
    private PaymentType internationalPayment;
    @JsonProperty("isDecisionMade")
    private Boolean isDecisionMade;
    @JsonProperty("decisionReasonCode")
    private String decisionReasonCode;
    @JsonProperty("payer")
    private Account payer;
    @JsonProperty("payee")
    private Account payee;
    @JsonProperty("initiatingParty")
    private Account initiatingParty;
    @JsonProperty("payeeBank")
    private Bank payeeBank;
    @JsonProperty("payerBank")
    private Bank payerBank;
    @JsonProperty("firstIntermediaryBank")
    private Bank firstIntermediaryBank;
    @JsonProperty("secondaryIntermediaryBank")
    private Bank secondaryIntermediaryBank;
    @JsonProperty("senderCorrespondentBank")
    private Bank senderCorrespondentBank;
    @JsonProperty("receiverCorrespondentBank")
    private Bank receiverCorrespondentBank;
    @JsonProperty("instructingAgent")
    private Bank instructingAgent;
    @JsonProperty("relatedRemitterInfo")
    private RelatedRemitterInfo relatedRemitterInfo;
    @JsonProperty("remitterInfo")
    private RemitterInfo remitterInfo;
    @JsonProperty("instructedAgent")
    private Bank instructedAgent;
    @JsonProperty("supplementaryData")
    private SupplementaryData supplementaryData;
    @JsonProperty("onBehalfOfPayer")
    private Account onBehalfOfPayer;
    @JsonProperty("ultimateCreditor")
    private Account ultimateCreditor;
    @JsonProperty("ultimateDebtor")
    private Account ultimateDebtor;
    @JsonProperty("optionalHeaderInfo")
    private OptionalHeaderInfo optionalHeaderInfo;
    @JsonProperty("relatedReference")
    private String relatedReference;

    public java.math.BigDecimal getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(java.math.BigDecimal transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

    public String getTraceNumber() {
        return traceNumber;
    }

    public void setTraceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
    }

    public java.math.BigDecimal getDiscountAppliedAmount() {
        return discountAppliedAmount;
    }

    public void setDiscountAppliedAmount(java.math.BigDecimal discountAppliedAmount) {
        this.discountAppliedAmount = discountAppliedAmount;
    }

    public java.math.BigDecimal getReturnAmount() {
        return returnAmount;
    }

    public void setReturnAmount(java.math.BigDecimal returnAmount) {
        this.returnAmount = returnAmount;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getPaymentTypeCode() {
        return paymentTypeCode;
    }

    public void setPaymentTypeCode(String paymentTypeCode) {
        this.paymentTypeCode = paymentTypeCode;
    }

    public String getChargedTo() {
        return chargedTo;
    }

    public void setChargedTo(String chargedTo) {
        this.chargedTo = chargedTo;
    }

    public String getValueDate() {
        return valueDate;
    }

    public void setValueDate(String valueDate) {
        this.valueDate = valueDate;
    }

    public String getBankToBank() {
        return bankToBank;
    }

    public void setBankToBank(String bankToBank) {
        this.bankToBank = bankToBank;
    }

    public String getInstructionId() {
        return instructionId;
    }

    public void setInstructionId(String instructionId) {
        this.instructionId = instructionId;
    }

    public String getMessageTransmissionId() {
        return messageTransmissionId;
    }

    public void setMessageTransmissionId(String messageTransmissionId) {
        this.messageTransmissionId = messageTransmissionId;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getEndToEndId() {
        return endToEndId;
    }

    public void setEndToEndId(String endToEndId) {
        this.endToEndId = endToEndId;
    }

    public String getSwiftEndToEndTransactionReference() {
        return swiftEndToEndTransactionReference;
    }

    public void setSwiftEndToEndTransactionReference(String swiftEndToEndTransactionReference) {
        this.swiftEndToEndTransactionReference = swiftEndToEndTransactionReference;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getClientTransactionId() {
        return clientTransactionId;
    }

    public void setClientTransactionId(String clientTransactionId) {
        this.clientTransactionId = clientTransactionId;
    }

    public String getCheckNumber() {
        return checkNumber;
    }

    public void setCheckNumber(String checkNumber) {
        this.checkNumber = checkNumber;
    }

    public String getPaymentSourceChannelId() {
        return paymentSourceChannelId;
    }

    public void setPaymentSourceChannelId(String paymentSourceChannelId) {
        this.paymentSourceChannelId = paymentSourceChannelId;
    }

    public String getPaymentSourceChannelDescription() {
        return paymentSourceChannelDescription;
    }

    public void setPaymentSourceChannelDescription(String paymentSourceChannelDescription) {
        this.paymentSourceChannelDescription = paymentSourceChannelDescription;
    }

    public String getPreviousPaymentStatus() {
        return previousPaymentStatus;
    }

    public void setPreviousPaymentStatus(String previousPaymentStatus) {
        this.previousPaymentStatus = previousPaymentStatus;
    }

    public String getTransactionDirectionName() {
        return transactionDirectionName;
    }

    public void setTransactionDirectionName(String transactionDirectionName) {
        this.transactionDirectionName = transactionDirectionName;
    }

    public String getMessageFormat() {
        return messageFormat;
    }

    public void setMessageFormat(String messageFormat) {
        this.messageFormat = messageFormat;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getStandardEntryCode() {
        return standardEntryCode;
    }

    public void setStandardEntryCode(String standardEntryCode) {
        this.standardEntryCode = standardEntryCode;
    }

    public String getClearingSystem() {
        return clearingSystem;
    }

    public void setClearingSystem(String clearingSystem) {
        this.clearingSystem = clearingSystem;
    }

    public String getClearingSystemReferenceNumber() {
        return clearingSystemReferenceNumber;
    }

    public void setClearingSystemReferenceNumber(String clearingSystemReferenceNumber) {
        this.clearingSystemReferenceNumber = clearingSystemReferenceNumber;
    }

    public String getPreviousClearingSystemReferenceNumber() {
        return previousClearingSystemReferenceNumber;
    }

    public void setPreviousClearingSystemReferenceNumber(String previousClearingSystemReferenceNumber) {
        this.previousClearingSystemReferenceNumber = previousClearingSystemReferenceNumber;
    }

    public String getClearingSystemOutputReferenceNumber() {
        return clearingSystemOutputReferenceNumber;
    }

    public void setClearingSystemOutputReferenceNumber(String clearingSystemOutputReferenceNumber) {
        this.clearingSystemOutputReferenceNumber = clearingSystemOutputReferenceNumber;
    }

    public String getNewPaymentTypeCode() {
        return newPaymentTypeCode;
    }

    public void setNewPaymentTypeCode(String newPaymentTypeCode) {
        this.newPaymentTypeCode = newPaymentTypeCode;
    }

    public String getServiceLevelCd() {
        return serviceLevelCd;
    }

    public void setServiceLevelCd(String serviceLevelCd) {
        this.serviceLevelCd = serviceLevelCd;
    }

    public String getTransactionReasonCd() {
        return transactionReasonCd;
    }

    public void setTransactionReasonCd(String transactionReasonCd) {
        this.transactionReasonCd = transactionReasonCd;
    }

    public String getLocalInstrumentCode() {
        return localInstrumentCode;
    }

    public void setLocalInstrumentCode(String localInstrumentCode) {
        this.localInstrumentCode = localInstrumentCode;
    }

    public String getCategoryPurpose() {
        return categoryPurpose;
    }

    public void setCategoryPurpose(String categoryPurpose) {
        this.categoryPurpose = categoryPurpose;
    }

    public Boolean getIsSameDay() {
        return isSameDay;
    }

    public void setIsSameDay(Boolean isSameDay) {
        this.isSameDay = isSameDay;
    }

    public ExchangeRate getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(ExchangeRate exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public PaymentType getDomesticPayment() {
        return domesticPayment;
    }

    public void setDomesticPayment(PaymentType domesticPayment) {
        this.domesticPayment = domesticPayment;
    }

    public PaymentType getInternationalPayment() {
        return internationalPayment;
    }

    public void setInternationalPayment(PaymentType internationalPayment) {
        this.internationalPayment = internationalPayment;
    }

    public Boolean getIsDecisionMade() {
        return isDecisionMade;
    }

    public void setIsDecisionMade(Boolean isDecisionMade) {
        this.isDecisionMade = isDecisionMade;
    }

    public String getDecisionReasonCode() {
        return decisionReasonCode;
    }

    public void setDecisionReasonCode(String decisionReasonCode) {
        this.decisionReasonCode = decisionReasonCode;
    }

    public Account getPayer() {
        return payer;
    }

    public void setPayer(Account payer) {
        this.payer = payer;
    }

    public Account getPayee() {
        return payee;
    }

    public void setPayee(Account payee) {
        this.payee = payee;
    }

    public Account getInitiatingParty() {
        return initiatingParty;
    }

    public void setInitiatingParty(Account initiatingParty) {
        this.initiatingParty = initiatingParty;
    }

    public Bank getPayeeBank() {
        return payeeBank;
    }

    public void setPayeeBank(Bank payeeBank) {
        this.payeeBank = payeeBank;
    }

    public Bank getPayerBank() {
        return payerBank;
    }

    public void setPayerBank(Bank payerBank) {
        this.payerBank = payerBank;
    }

    public Bank getFirstIntermediaryBank() {
        return firstIntermediaryBank;
    }

    public void setFirstIntermediaryBank(Bank firstIntermediaryBank) {
        this.firstIntermediaryBank = firstIntermediaryBank;
    }

    public Bank getSecondaryIntermediaryBank() {
        return secondaryIntermediaryBank;
    }

    public void setSecondaryIntermediaryBank(Bank secondaryIntermediaryBank) {
        this.secondaryIntermediaryBank = secondaryIntermediaryBank;
    }

    public Bank getSenderCorrespondentBank() {
        return senderCorrespondentBank;
    }

    public void setSenderCorrespondentBank(Bank senderCorrespondentBank) {
        this.senderCorrespondentBank = senderCorrespondentBank;
    }

    public Bank getReceiverCorrespondentBank() {
        return receiverCorrespondentBank;
    }

    public void setReceiverCorrespondentBank(Bank receiverCorrespondentBank) {
        this.receiverCorrespondentBank = receiverCorrespondentBank;
    }

    public Bank getInstructingAgent() {
        return instructingAgent;
    }

    public void setInstructingAgent(Bank instructingAgent) {
        this.instructingAgent = instructingAgent;
    }

    public RelatedRemitterInfo getRelatedRemitterInfo() {
        return relatedRemitterInfo;
    }

    public void setRelatedRemitterInfo(RelatedRemitterInfo relatedRemitterInfo) {
        this.relatedRemitterInfo = relatedRemitterInfo;
    }

    public RemitterInfo getRemitterInfo() {
        return remitterInfo;
    }

    public void setRemitterInfo(RemitterInfo remitterInfo) {
        this.remitterInfo = remitterInfo;
    }

    public Bank getInstructedAgent() {
        return instructedAgent;
    }

    public void setInstructedAgent(Bank instructedAgent) {
        this.instructedAgent = instructedAgent;
    }

    public SupplementaryData getSupplementaryData() {
        return supplementaryData;
    }

    public void setSupplementaryData(SupplementaryData supplementaryData) {
        this.supplementaryData = supplementaryData;
    }

    public Account getOnBehalfOfPayer() {
        return onBehalfOfPayer;
    }

    public void setOnBehalfOfPayer(Account onBehalfOfPayer) {
        this.onBehalfOfPayer = onBehalfOfPayer;
    }

    public Account getUltimateCreditor() {
        return ultimateCreditor;
    }

    public void setUltimateCreditor(Account ultimateCreditor) {
        this.ultimateCreditor = ultimateCreditor;
    }

    public Account getUltimateDebtor() {
        return ultimateDebtor;
    }

    public void setUltimateDebtor(Account ultimateDebtor) {
        this.ultimateDebtor = ultimateDebtor;
    }

    public OptionalHeaderInfo getOptionalHeaderInfo() {
        return optionalHeaderInfo;
    }

    public void setOptionalHeaderInfo(OptionalHeaderInfo optionalHeaderInfo) {
        this.optionalHeaderInfo = optionalHeaderInfo;
    }

    public String getRelatedReference() {
        return relatedReference;
    }

    public void setRelatedReference(String relatedReference) {
        this.relatedReference = relatedReference;
    }
}
