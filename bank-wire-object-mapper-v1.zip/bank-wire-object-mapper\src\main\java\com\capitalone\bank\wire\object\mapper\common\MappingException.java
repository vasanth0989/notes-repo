package com.capitalone.bank.wire.object.mapper.common;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Thrown when the payment object cannot be mapped to a valid pain.001.001.11 message. Carries every
 * problem found, each with the payment-object path that caused it. Messages never contain field values.
 */
public final class MappingException extends RuntimeException {

    private final transient List<MappingProblem> problems;

    public MappingException(String path, String message) {
        this(List.of(new MappingProblem(path, message)));
    }

    public MappingException(List<MappingProblem> problems) {
        super(describe(problems));
        this.problems = List.copyOf(problems);
    }

    public MappingException(String path, String message, Throwable cause) {
        super(path + ": " + message, cause);
        this.problems = List.of(new MappingProblem(path, message));
    }

    /** Every problem found, in the order the mapping met them. */
    public List<MappingProblem> problems() {
        return problems;
    }

    private static String describe(List<MappingProblem> problems) {
        if (problems.isEmpty()) {
            throw new IllegalArgumentException("at least one problem is required");
        }
        if (problems.size() == 1) {
            return problems.getFirst().toString();
        }
        return problems.size() + " mapping problems: "
                + problems.stream().map(MappingProblem::toString).collect(Collectors.joining("; "));
    }
}
