package com.capitalone.bank.wire.object.mapper.pain001.v11;

import com.capitalone.bank.wire.object.mapper.common.MappingException;
import com.capitalone.bank.wire.object.mapper.common.Text;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.CategoryPurpose1Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ChargeBearerType1Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ClearingSystemIdentification2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ExchangeRateType1Code;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.LocalInstrument2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.Purpose2Choice;
import com.capitalone.bank.wire.object.mapper.generated.pain001v11.ServiceLevel8Choice;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.CodeRules;
import com.capitalone.bank.wire.object.mapper.pain001.v11.MappingRules.CodeStyle;
import java.util.Optional;
import java.util.function.Consumer;
import org.jspecify.annotations.Nullable;

/**
 * Translates payment-object code values into the ISO code slots. A value shaped like an ISO external
 * code (1 to 4 upper-case letters or digits) goes into {@code Cd}; anything else into {@code Prtry},
 * except where a rule says otherwise.
 */
final class CodeTables {

    /** ExternalClearingSystemIdentification1Code is at most 5 characters. */
    private static final int CLEARING_SYSTEM_CODE_MAX = 5;

    private CodeTables() {
    }

    static ChargeBearerType1Code chargeBearer(@Nullable String value, CodeRules rules) {
        var path = "payload.chargedTo";
        return Text.clean(value)
                .map(text -> {
                    try {
                        return ChargeBearerType1Code.fromValue(Text.upper(text));
                    } catch (IllegalArgumentException e) {
                        return switch (rules.chargeBearerPolicy()) {
                            case USE_DEFAULT -> rules.defaultChargeBearer();
                            case REJECT -> throw new MappingException(path, "is not one of DEBT, CRED, SHAR, SLEV", e);
                        };
                    }
                })
                .orElse(rules.defaultChargeBearer());
    }

    static Optional<ExchangeRateType1Code> rateType(@Nullable String value, CodeRules rules) {
        var path = "payload.exchangeRate.foreignExchangeTrade";
        return Text.clean(value).flatMap(text -> {
            try {
                return Optional.of(ExchangeRateType1Code.fromValue(Text.upper(text)));
            } catch (IllegalArgumentException e) {
                return switch (rules.rateTypePolicy()) {
                    case USE_DEFAULT -> Optional.empty();
                    case REJECT -> throw new MappingException(path, "is not one of SPOT, SALE, AGRD", e);
                };
            }
        });
    }

    static ServiceLevel8Choice serviceLevel(String value, String path) {
        var choice = new ServiceLevel8Choice();
        codeOrProprietary(value, path, choice::setCd, choice::setPrtry);
        return choice;
    }

    static LocalInstrument2Choice localInstrument(String value, String path, CodeStyle style) {
        var choice = new LocalInstrument2Choice();
        switch (style) {
            case EXTERNAL_CODE -> codeOrProprietary(value, path, choice::setCd, choice::setPrtry);
            case PROPRIETARY -> choice.setPrtry(Text.bounded(value, Text.MAX_35, path));
        }
        return choice;
    }

    static CategoryPurpose1Choice categoryPurpose(String value, String path) {
        var choice = new CategoryPurpose1Choice();
        codeOrProprietary(value, path, choice::setCd, choice::setPrtry);
        return choice;
    }

    static Purpose2Choice purpose(String value, String path) {
        var choice = new Purpose2Choice();
        codeOrProprietary(value, path, choice::setCd, choice::setPrtry);
        return choice;
    }

    /** ClrSysId: USABA and the other short ISO clearing system codes go to Cd, longer values to Prtry. */
    static ClearingSystemIdentification2Choice clearingSystem(String value, String path) {
        var choice = new ClearingSystemIdentification2Choice();
        var code = Text.upper(Text.required(value, path));
        if (code.length() <= CLEARING_SYSTEM_CODE_MAX) {
            choice.setCd(code);
        } else {
            choice.setPrtry(Text.bounded(code, Text.MAX_35, path));
        }
        return choice;
    }

    private static void codeOrProprietary(String value, String path, Consumer<String> code, Consumer<String> proprietary) {
        var text = Text.required(value, path);
        var upper = Text.upper(text);
        if (Text.isExternalCode(upper)) {
            code.accept(upper);
        } else {
            proprietary.accept(Text.bounded(text, Text.MAX_35, path));
        }
    }
}
