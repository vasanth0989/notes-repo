package com.capitalone.commercial.payx.sdp.payload.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Local stand-in for the generated payment object class of the same name in
 * {@code com.capitalone.commercial:payx-payload:2.16-beta}. Field names, order and types follow that
 * version's sources; the stand-in carries the fields the wire mapper reads and leaves out nested objects it
 * never touches. Replace with the real library on the Capital One network ({@code -PpayxPayloadVersion}).
 * Deliberately no {@code toString()}: it would print account data.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"exchangeRate", "foreignExchangeTrade", "foreignExchangeCurrencyCode", "contractId", "instructedAmount"})
public class ExchangeRate {
    @JsonProperty("exchangeRate")
    private String exchangeRate;
    @JsonProperty("foreignExchangeTrade")
    private String foreignExchangeTrade;
    @JsonProperty("foreignExchangeCurrencyCode")
    private String foreignExchangeCurrencyCode;
    @JsonProperty("contractId")
    private String contractId;
    @JsonProperty("instructedAmount")
    private java.math.BigDecimal instructedAmount;

    public String getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(String exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public String getForeignExchangeTrade() {
        return foreignExchangeTrade;
    }

    public void setForeignExchangeTrade(String foreignExchangeTrade) {
        this.foreignExchangeTrade = foreignExchangeTrade;
    }

    public String getForeignExchangeCurrencyCode() {
        return foreignExchangeCurrencyCode;
    }

    public void setForeignExchangeCurrencyCode(String foreignExchangeCurrencyCode) {
        this.foreignExchangeCurrencyCode = foreignExchangeCurrencyCode;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public java.math.BigDecimal getInstructedAmount() {
        return instructedAmount;
    }

    public void setInstructedAmount(java.math.BigDecimal instructedAmount) {
        this.instructedAmount = instructedAmount;
    }
}
