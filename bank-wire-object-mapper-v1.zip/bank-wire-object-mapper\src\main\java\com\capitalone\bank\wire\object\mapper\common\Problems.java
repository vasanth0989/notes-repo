package com.capitalone.bank.wire.object.mapper.common;

import java.util.ArrayList;
import java.util.List;

/** Collects mapping problems so a payment is rejected with every reason at once, not one per attempt. */
public final class Problems {

    private final List<MappingProblem> list = new ArrayList<>();

    public Problems add(String path, String message) {
        list.add(new MappingProblem(path, message));
        return this;
    }

    public boolean isEmpty() {
        return list.isEmpty();
    }

    public List<MappingProblem> asList() {
        return List.copyOf(list);
    }

    /** Throws a {@link MappingException} with every problem collected, if any. */
    public void throwIfAny() {
        if (!list.isEmpty()) {
            throw new MappingException(list);
        }
    }
}
