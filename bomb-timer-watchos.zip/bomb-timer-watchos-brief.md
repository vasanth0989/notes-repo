# Brief: recreate the Daybreak "bomb timer" graphic on Apple Watch Ultra

You are building a countdown timer for a watchOS app (SwiftUI, Apple Watch Ultra). The
owner already has a version of this graphic he likes, in a desktop app called Daybreak,
and wants the watch version to look **the same**. This brief is the exact specification
of that graphic, measured from the working code. Follow the numbers; don't redesign it.

Two files come with this brief:

- `bomb.png` — the bomb itself (560 × 614 px, transparent background). **Use this image.
  Do not draw the bomb with shapes, gradients or an SF Symbol** — that is the main reason
  earlier attempts looked wrong. Add it to the asset catalog as `bomb`.
- `bomb-lit-reference.png` — what the finished graphic looks like while the fuse burns,
  at 3× scale on the desktop app's dark background. Match this.

## What it is, in one paragraph

A glossy black cartoon-render bomb with a grey metal cap. A short fuse rises out of the
cap and curls to the upper right. **The fuse is the progress indicator**: as time runs
out it burns from the far tip down toward the cap, so the length of fuse left is the time
left. A small flame and a glowing spark sit at the burning point and travel down with it.
The remaining time is printed under the bomb. There is no ring, arc or progress bar
anywhere — the owner rejected a countdown ring ("it doesn't feel like a bomb"), a
photoreal bomb ("too realistic") and a long trailing cord ("thread hanging around").
Keep the fuse short and attached.

## Geometry

Everything scales from one number: the bomb's drawn width **W**. On the desktop W = 112.
On the Ultra's screen (about 205 × 251 pt) something like W = 104 pt works; read the real
size from `GeometryReader` rather than hard-coding. The image keeps its aspect ratio, so
its height is 1.096 W.

Coordinates below are in units of W, measured from the **top-left corner of the bomb
image**, x to the right and y downward (the same direction SwiftUI uses). Negative y is
above the image.

**The fuse path** — two cubic Béziers, starting inside the nozzle and ending at the tip:

| | x | y |
|---|---|---|
| start (in the nozzle) | 0.500 | 0.048 |
| control 1 | 0.500 | −0.041 |
| control 2 | 0.536 | −0.113 |
| midpoint | 0.607 | −0.166 |
| control 3 | 0.661 | −0.211 |
| control 4 | 0.714 | −0.220 |
| end (the tip) | 0.750 | −0.202 |

So the whole fuse is only about 0.25 W wide and reaches 0.22 W above the image.
Stroke width 0.045 W, round line caps.

**Layer order, back to front:** background glow → fuse (ash, then unburnt part) → flame
and spark → **bomb image** → time text. The bomb image is drawn *over* the fuse, so the
first few points of the path are hidden inside the cap and the fuse appears to come out
of the nozzle. At the very end the spark sinks into the cap. Getting this order wrong
makes the fuse look pasted on.

**Time text:** centred under the bomb, its baseline about 0.2 W below the image's bottom
edge.

## Colours

| Use | Hex |
|---|---|
| Ember (orange) | `#ff8a5c` |
| Ember hot (gold) | `#ffd166` |
| Unburnt fuse, lit | `#d9c08a` |
| Fuse when not lit, and ash | `#5a5366` |
| Spark core | `#fff6dc` |
| Time text in the last stretch; blast flash | `#fff3d0` |
| Desktop background (for reference) | `#12141d` — on the watch use black |

## States

**Idle (no timer running).** Bomb with a plain drop shadow (black at 75 %, offset y
0.125 W, blur 0.2 W). The full fuse is drawn in `#5a5366` at 70 % opacity as a *braided*
line: dash pattern 0.045 W on, 0.022 W off, with round caps (the caps overlap the gaps,
so it reads as a beaded cord, not separate dashes). No flame, no spark, no time.

**Burning.** With `fraction = timeRemaining / totalDuration` (1 → 0):

- *Ash:* the full path, same braided grey, at 18 % opacity.
- *Unburnt fuse:* the path from the start to `fraction` of its length, **solid**
  (not dashed) `#d9c08a`, round caps. In SwiftUI: `fusePath.trimmedPath(from: 0, to: fraction)`.
- *Burning point:* the end of that trimmed path
  (`fusePath.trimmedPath(from: 0, to: fraction).currentPoint`). The flame, spark and
  flecks are all drawn relative to this point and move with it.
- *Bomb glow:* add a second shadow around the bomb, ember at 55 %, no offset, blur 0.2 W.
- *Time:* shown under the bomb.

Motion must be continuous, not one jump per second. Drive it from the end date:
`TimelineView(.animation)` and compute `fraction` from `endDate.timeIntervalSince(now)`
each frame. Never decrement a counter.

**Last stretch** — when remaining ≤ max(60 s, 10 % of the total). Note that a one-minute
timer is therefore in this state from the start, which is intended.

- The bomb pulses like a heartbeat on a 1.1 s cycle: scale 1 → 1.045 at 0.2 s → 1 at
  0.4 s → rest until 1.1 s.
- The bomb's glow deepens: ember at 85 %, blur 0.27 W.
- The time text turns `#fff3d0`.

## The burning point, in detail

All sizes in units of W, positions relative to the burning point, y negative = up.
These always point straight up on screen; they do not rotate to follow the fuse.

**Flame** (drawn first, behind the spark). Two filled teardrops. On the desktop they are
these SVG paths in a space where W = 112, so multiply every number by W / 112:

- Outer, fill `#ff8a5c`:
  `M0 -2 C5 -7 6 -12 2.5 -17 C1 -19 -2.5 -19 -4 -16 C-6 -12 -5 -7 0 -2 Z`
- Inner, fill `#ffd166`:
  `M0 -4 C2.5 -7 3 -10 1.2 -12.5 C0.3 -13.6 -1.6 -13.4 -2.2 -12 C-3.2 -9.6 -2.4 -7 0 -4 Z`

The flame is about 0.15 W tall. It flickers: scale 0.9 ↔ 1.1 and rotate −7° ↔ +7°
together, 0.42 s each way, ease-in-out, repeating back and forth, anchored at the
burning point.

**Halo:** a circle of radius 0.0625 W, `#ffd166`, pulsing between (scale 0.8, opacity
0.40) and (scale 1.3, opacity 0.75), 0.5 s each way, ease-in-out.

**Core:** a circle of radius 0.023 W, `#fff6dc`, steady.

**Flecks:** three short lines, each from the burning point to 0.0625 W above it, stroke
`#ffd166`, width 0.0125 W, round caps, tilted −30°, +10° and +40° from vertical. Each
one repeatedly shoots outward along its own direction: over 0.6 s (linear) it travels
0.125 W, shrinks to 40 % and fades from 90 % to 0, then restarts. Stagger the three by
0.2 s.

**Embers:** five dots, 0.027 W across, `#ffd166`, released from a fixed point near the
middle of the fuse at (0.63, −0.09). Each rises 0.625 W over 2.6 s (ease-out) while
drifting sideways (+0.036, +0.143, −0.125, +0.071, −0.054 W respectively), shrinking to
30 %, fading in to 90 % in the first 12 % of its life and out to 0 by the end. They loop,
offset from each other by 0, 0.5, 1.1, 1.7 and 2.2 s.

## Time text

- Typeface: **Chakra Petch Bold**, 0.134 W (15 px at W = 112), monospaced digits,
  letter-spacing 0.05 em. It is an open-licensed Google font and can be bundled. If you
  don't bundle it, use the system font with `.fontDesign(.monospaced)`, bold, and
  `.monospacedDigit()`.
- Colour `#ffd166`, with a soft glow: ember at 65 %, blur 0.1 W.
- Format `m:ss` under an hour (`15:00`, `0:42`), `h:mm:ss` above.

## Background

Black, with a soft radial ember glow behind and below the bomb: `#ff8a5c` at about 18 %
in the centre fading to clear, radius roughly 1.2 W, only while burning. It breathes
slowly, opacity 80 % ↔ 100 % over 4 s. Fade it in over about 1.2 s when a timer starts.

## The blast (at zero)

All of these start together, centred on the middle of the bomb:

1. **Flash:** the whole screen filled with `#fff3d0` at 50 % opacity, fading to 0 over
   0.5 s (ease-out).
2. **Shockwave:** a ring, starting 0.14 W across (0.4 × a 0.36 W circle), stroke
   `#ffd166` about 0.027 W, with an ember glow around it. Over 0.9 s it expands to 28× the
   base circle (well past the screen edges) while fading from 100 % to 0. Fast at first,
   slowing: timing curve `(0.2, 0.8, 0.3, 1)`.
3. **Kick:** the bomb scales 1 → 1.3 at 0.15 s → 1 at 0.5 s, with a slight overshoot.
4. **Shake:** the whole graphic jitters for 0.5 s through offsets (−3, 2), (3, −2),
   (−2, −1), (2, 1) points and back to rest.
5. **Ember burst:** particles thrown in all directions from the bomb's centre, drawn as
   five-pointed stars (inner radius 45 % of outer) with a soft glow, in these colours at
   random: `#ffd166`, `#ff8a5c`, `#ff5c3a`, `#fff3d0`, `#ffb347`. On the desktop: 150
   particles, initial speed 180–1000 pt/s with a small upward bias, size 4–13 pt,
   gravity pulling down, a little drag, each living 1.1–2.0 s, fading over the last 30 %
   and twinkling slightly; then seven smaller bursts of 28 at random spots, 0.09 s apart.
   The watch screen is about a fifth of that area: scale to roughly 50 particles, sizes
   2–6 pt, speeds 100–450 pt/s, and three secondary bursts. Draw them in one `Canvas`.
6. **Haptic** (the watch's addition; the desktop version is silent): play
   `WKInterfaceDevice.current().play(.notification)` at the moment of the flash.

Afterwards return to the idle state.

## watchOS notes

- Build the graphic as one view sized by W, inside a `ZStack` in the layer order above.
  A single `Canvas` inside `TimelineView(.animation)` is the simplest way to draw the
  fuse, flame, spark, flecks and embers together; the bomb is an `Image("bomb")` on top.
- Compute every looping animation from the timeline's date (for example
  `sin` of elapsed time for the flicker) rather than chaining `withAnimation` calls, so
  everything stays in step and survives the view being rebuilt.
- When `@Environment(\.isLuminanceReduced)` is true (wrist down, Always On), stop the
  flicker, flecks, embers and glow breathing; keep the bomb, the fuse at its current
  length, a static spark and the time.
- When `@Environment(\.accessibilityReduceMotion)` is true, skip the shake, kick and
  particle burst; keep the flash short, and keep the haptic.
- The timer must fire even when the app isn't on screen: store the end date, and schedule
  a local notification (or hold a `WKExtendedRuntimeSession`) so the haptic still arrives.
  This is outside the graphic, but a bomb that goes off late is the worst failure it has.

## Check your work against this

- [ ] The bomb is the supplied PNG, not a drawing.
- [ ] No ring, arc or bar; the only progress indicator is the fuse getting shorter.
- [ ] The fuse is short (about a quarter of the bomb's width) and comes out of the cap.
- [ ] The fuse burns from the tip toward the cap, and the flame rides the burning point.
- [ ] The bomb is drawn over the base of the fuse.
- [ ] Burnt fuse stays behind as faint braided ash; unburnt fuse is solid tan.
- [ ] Movement is smooth, not one step per second.
- [ ] Side by side with `bomb-lit-reference.png`, it reads as the same graphic.

*Not verified on a device: the SwiftUI API names above are given from knowledge, not
compiled here (this brief was written on a Windows machine). Every measurement, colour
and timing is taken directly from the working desktop code.*
