import {read,utils} from 'xlsx';

export const segmentCode=value=>{
 const match=String(value??'').trim().toUpperCase().match(/^(?:SEGMENT\s*)?(\d+)(?:[.\s-]*([A-Z]))?$/);
 return match?'SEGMENT '+match[1]+(match[2]?'.'+match[2]:''):null;
};
const text=cell=>cell&&!cell.f?String(cell.v??'').trim():'';
const header=cell=>text(cell).toUpperCase().replace(/\s+/g,'_');
function cifValue(cell){
 if(!cell||cell.f)return null;
 if(cell.t==='s'||cell.t==='str')return text(cell)||null;
 if(cell.t==='n'&&Number.isSafeInteger(cell.v)&&cell.v>=0){
  // Only an explicit zero-only Excel format can restore displayed leading zeros.
  return /^0+$/.test(cell.z||'')?String(cell.v).padStart(cell.z.length,'0'):String(cell.v);
 }
 return null;
}
function denseRows(sheet){return sheet?.['!data']||[];}
export function parseSegmentation(buffer,name='Workbook'){
 const signature=new Uint8Array(buffer).slice(0,4);
 if(!(signature[0]===0x50&&signature[1]===0x4b)&&!(signature[0]===0xd0&&signature[1]===0xcf))throw Error('Choose an Excel .xlsx or .xls workbook, not a renamed text file.');
 const names=read(buffer,{type:'array',bookSheets:true}).SheetNames;
 const dataName=names.find(n=>n.trim().toLowerCase()==='data');
 if(!dataName)throw Error('Segmentation workbook needs a Data sheet with BNK_CUST_NBR and SEGMENTS columns.');
 const definitionName=names.find(n=>n.trim().toLowerCase()==='segmentation');
 const book=read(buffer,{type:'array',sheets:[dataName,...(definitionName?[definitionName]:[])],dense:true,cellNF:true,cellText:false,cellHTML:false,bookVBA:false});
 const rows=denseRows(book.Sheets[dataName]);
 const headerIndex=rows.slice(0,30).findIndex(r=>r?.some(c=>header(c)==='BNK_CUST_NBR')&&r?.some(c=>header(c)==='SEGMENTS'));
 if(headerIndex<0)throw Error('Data sheet headers BNK_CUST_NBR and SEGMENTS were not found in the first 30 rows.');
 const headers=rows[headerIndex],cifCol=headers.findIndex(c=>header(c)==='BNK_CUST_NBR'),segmentCol=headers.findIndex(c=>header(c)==='SEGMENTS');
 if(headers.filter(c=>header(c)==='BNK_CUST_NBR').length!==1||headers.filter(c=>header(c)==='SEGMENTS').length!==1)throw Error('Data sheet has duplicate CIF or SEGMENTS columns.');
 const assignments=new Map(),stats={rows:0,invalidRows:0,repeatedRows:0,conflictingCifs:0,numericCifs:0},issues=[];
 const issue=(row,reason)=>{stats.invalidRows++;if(issues.length<100)issues.push({row,reason});};
 for(let i=headerIndex+1;i<rows.length;i++){
  const r=rows[i];if(!r||!r.some(c=>c&&(c.v!==undefined||c.f)))continue;stats.rows++;
  const cif=cifValue(r[cifCol]),code=segmentCode(text(r[segmentCol]));
  if(!cif){issue(i+1,'CIF is missing, a formula, or an unsafe numeric value. Supply CIF as text preserving leading zeros.');continue;}
  if(r[cifCol].t==='n')stats.numericCifs++;
  const previous=assignments.get(cif);
  if(!code){issue(i+1,'Segment is missing, a formula, or not a recognized segment label.');assignments.set(cif,{code:null,conflict:true});continue;}
  if(previous){if(previous.code===code&&!previous.conflict)stats.repeatedRows++;else assignments.set(cif,{code:null,conflict:true});}
  else assignments.set(cif,{code,conflict:false});
 }
 stats.conflictingCifs=[...assignments.values()].filter(v=>v.conflict).length;
 const definitions=new Map();let asOf='';
 if(definitionName){
  const definitionRows=denseRows(book.Sheets[definitionName]);
  for(let i=0;i<definitionRows.length;i++){
   const r=definitionRows[i];if(!r)continue;
   const first=r.findIndex(c=>!!text(c));if(first<0)continue;
   const code=segmentCode(text(r[first]));
   if(code){const description=text(r[first+1]);if(description&&description.toLowerCase()!=='definition'){
    const old=definitions.get(code);definitions.set(code,old&&old!==description?'Conflicting definitions in workbook; review Segmentation sheet.':description);
   }}
   if(i<5)for(const cell of r){if(!cell||cell.f)continue;const displayed=utils.format_cell(cell);if(/^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(displayed)||/^\d{4}-\d{2}-\d{2}$/.test(displayed))asOf=displayed;}
  }
 }
 return {assignments,definitions,source:{name,dataSheet:dataName,definitionSheet:definitionName||null,asOf,...stats,uniqueCifs:assignments.size,issues}};
}
export function applySegmentation(result,reference){
 const cifOwners=new Map();
 for(const c of result.customers)for(const cif of new Set(c.cifs||[]))cifOwners.set(cif,(cifOwners.get(cif)||0)+1);
 const counts=new Map([...reference.definitions.keys()].map(code=>[code,0])),used=new Set();let matched=0;
 for(const assignment of reference.assignments.values())if(assignment.code&&!counts.has(assignment.code))counts.set(assignment.code,0);
 for(const customer of result.customers){
  const cifs=[...new Set(customer.cifs||[])],hits=cifs.map(cif=>reference.assignments.get(cif)),codes=new Set(hits.filter(Boolean).map(h=>h.code));
  for(const cif of cifs)if(reference.assignments.has(cif))used.add(cif);
  let code;
  if(!cifs.length)code='MISSING CIF';
  else if(cifs.some(cif=>cifOwners.get(cif)>1)||hits.some(h=>h?.conflict)||codes.size>1)code='CONFLICT';
  else if(hits.some(h=>!h))code='UNMATCHED';
  else {code=[...codes][0];matched++;}
  customer.segment=code;counts.set(code,(counts.get(code)||0)+1);
 }
 const reasons={'MISSING CIF':'No Secure login ID supplied in the Member customer record.','UNMATCHED':'No exact workbook match for every supplied customer CIF. Leading zeros are not removed or guessed.','CONFLICT':'Conflicting/invalid workbook assignments, different segments across customer CIFs, or a CIF shared by multiple Member customers. Review required.'};
 const segments=[...counts].map(([code,count])=>({code,count,group:code.startsWith('SEGMENT ')?code.split('.')[0]:code,definition:reasons[code]||reference.definitions.get(code)||'Definition not supplied in the workbook.'})).sort((a,b)=>Number(b.code.startsWith('SEGMENT '))-Number(a.code.startsWith('SEGMENT '))||a.code.localeCompare(b.code,undefined,{numeric:true}));
 result.segmentation={source:reference.source,total:result.customers.length,matched,unresolved:result.customers.length-matched,referenceCifsNotInDelivery:reference.assignments.size-used.size,segments};
 return result;
}
export const matchesSegment=(code,filter)=>!filter||code===filter||(filter.startsWith('GROUP:')&&code?.split('.')[0]===filter.slice(6));
