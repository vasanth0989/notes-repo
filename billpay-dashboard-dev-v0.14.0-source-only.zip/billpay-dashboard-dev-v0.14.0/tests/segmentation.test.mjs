import test from 'node:test';
import assert from 'node:assert/strict';
import {utils,write} from 'xlsx';
import {parseSegmentation,applySegmentation,matchesSegment} from '../src/core/segmentation.mjs';
import {pageEntities,summary,publicResult} from '../src/core/explore.mjs';
function workbook(rows,options={}){
 const w=utils.book_new(),s=utils.aoa_to_sheet([['BNK_CUST_NBR','PRDCT_GRP_NM','SEGMENTS'],...rows]);options.edit?.(s);
 utils.book_append_sheet(w,s,'Data');utils.book_append_sheet(w,utils.aoa_to_sheet([['Date','10/15/2026'],[],['SEGMENTS','Definition'],['SEGMENT 1.A','Future scheduled payments'],['SEGMENT 2.C','Billers, no paid or scheduled payments'],['SEGMENT 3','Self-enrolled without billers or payments']]),'Segmentation');
 return write(w,{type:'buffer',bookType:options.bookType||'xlsx'});
}
const customer=(id,cifs)=>({key:id,id,cifs,name:id,memberIds:[],largestDuplicateGroup:2});
const result=customers=>({customers,unlinkedCustomers:[],payees:[],accounts:[],_customers:new Map(customers.map(c=>[c.key,c])),_payees:new Map()});
test('XLSX and legacy XLS preserve text CIF zeros and workbook definitions',()=>{
 for(const bookType of ['xlsx','biff8']){const r=parseSegmentation(workbook([['00087','CHECKING','SEGMENT 1.A'],['00088','SAVINGS','SEGMENT 3']],{bookType}));assert.equal(r.assignments.get('00087').code,'SEGMENT 1.A');assert.equal(r.definitions.get('SEGMENT 1.A'),'Future scheduled payments');assert.equal(r.source.asOf,'10/15/2026');}
});
test('numeric CIF zero formats are preserved; plain numeric IDs are not guessed',()=>{
 const r=parseSegmentation(workbook([[87,'','1A'],[88,'','3']],{edit:s=>s.A2.z='00000'}));assert.equal(r.assignments.get('00087').code,'SEGMENT 1.A');assert.ok(r.assignments.has('88'));assert.ok(!r.assignments.has('00088'));assert.equal(r.source.numericCifs,2);
});
test('formulas and unsafe numbers are rejected, repeated and conflicting assignments tracked',()=>{
 const r=parseSegmentation(workbook([['001','','1A'],['001','','1A'],['002','','1A'],['002','','3'],['003','','1A'],[9007199254740992,'','3'],['004','',''],['005','','3']],{edit:s=>{s.A6.f='1+2';s.C9.f='1+2';}}));
 assert.equal(r.source.repeatedRows,1);assert.equal(r.source.invalidRows,4);assert.equal(r.assignments.get('002').conflict,true);assert.equal(r.assignments.get('004').conflict,true);assert.equal(r.assignments.get('005').conflict,true);assert.ok(!r.assignments.has('003'));
});
test('delivery denominator, missing/unmatched/conflict buckets and shared CIF ambiguity',()=>{
 const ref=parseSegmentation(workbook([['001','','1A'],['002','','2C'],['003','','3'],['003','','1A'],['outside','','3']]));
 const r=applySegmentation(result([customer('a',['001']),customer('b',['002']),customer('c',[]),customer('d',['00001']),customer('e',['003']),customer('f',['002'])]),ref);
 assert.deepEqual(r.customers.map(c=>c.segment),['SEGMENT 1.A','CONFLICT','MISSING CIF','UNMATCHED','CONFLICT','CONFLICT']);assert.equal(r.segmentation.total,6);assert.equal(r.segmentation.matched,1);assert.equal(r.segmentation.referenceCifsNotInDelivery,1);assert.equal(r.segmentation.segments.reduce((n,s)=>n+s.count,0),6);assert.equal(summary(r).segmentation.total,6);assert.ok(!('assignments' in publicResult(r)));
});
test('segment groups, search and duplicate filters compose before sorting and paging',()=>{
 const customers=Array.from({length:205},(_,i)=>({...customer('TEST '+i,[String(i)]),segment:i%2?'SEGMENT 2.C':'SEGMENT 1.A',accounts:i}));const r=result(customers);
 let p=pageEntities(r,{entity:'Customers',segment:'GROUP:SEGMENT 1',duplicateCount:'2',sortBy:'accounts',sortDirection:'desc'});assert.equal(p.total,103);assert.equal(p.rows[0].accounts,204);assert.equal(p.rows.length,100);assert.equal(p.duplicateCounts.all,103);
 p=pageEntities(r,{entity:'Customers',segment:'SEGMENT 1.A',query:'TEST 204'});assert.equal(p.total,1);assert.ok(matchesSegment('SEGMENT 1.A','GROUP:SEGMENT 1'));assert.ok(!matchesSegment('SEGMENT 11.A','GROUP:SEGMENT 1'));
});
test('malformed workbook and missing Data headers fail explicitly',()=>{
 assert.throws(()=>parseSegmentation(new TextEncoder().encode('hello')),/Excel/);const w=utils.book_new();utils.book_append_sheet(w,utils.aoa_to_sheet([['CIF','Segment']]),'Data');assert.throws(()=>parseSegmentation(write(w,{type:'buffer',bookType:'xlsx'})),/headers/);
});
test('multiple customer CIFs need consistent complete evidence',()=>{
 const ref=parseSegmentation(workbook([['a','','1A'],['b','','1A'],['c','','3']]));const r=applySegmentation(result([customer('one',['a','b']),customer('two',['c','missing'])]),ref);assert.deepEqual(r.customers.map(c=>c.segment),['SEGMENT 1.A','UNMATCHED']);
});
