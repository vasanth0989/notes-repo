import test from 'node:test';
import assert from 'node:assert/strict';
import {createAccountPayments,accountPaymentEvidence} from '../src/core/account-payments.mjs';
import {createClosedAnalyzer,exportClosed} from '../src/core/closed-accounts.mjs';
const funding={refs:new Map()};
const setup=()=>({_accountPayments:createAccountPayments(),files:['single_payments','recurring_payments'].map(layout=>({layout,rejected:0}))});
const row=(account='001',key='c')=>({_customerKey:key,'FI Account Number':account});
test('account payment counts isolate customers and accounts; model-only and history remain separate',()=>{
 const r=setup(),p=r._accountPayments;
 p.add(row(),'recurring_payments','model',funding,true);p.add(row(),'payment_history','history',funding,true);p.add(row('002'),'single_payments','single',funding,true);p.add(row('001','other'),'single_payments','single',funding,true);
 const e=accountPaymentEvidence(r,'c','001');assert.equal(e.models,1);assert.equal(e.single,0);assert.equal(e.history,1);assert.equal(e.state,'Payments present');assert.equal(accountPaymentEvidence(r,'c','003').state,'None reported');
});
test('history alone is not an active payment; missing/rejected files and unresolved ownership require review',()=>{
 const r=setup();r._accountPayments.add(row(),'payment_history','history',funding,true);assert.equal(accountPaymentEvidence(r,'c','001').state,'None reported');r.files[0].rejected=1;assert.equal(accountPaymentEvidence(r,'c','001').state,'Review needed');r.files.pop();assert.equal(accountPaymentEvidence(r,'c','001').state,'Review needed');
 const other=setup();other._accountPayments.add(row(),'single_payments','single',funding,false);assert.equal(accountPaymentEvidence(other,'else','002').state,'Review needed');
});
test('reference-only matching tolerates repeated identical rows but rejects conflicts and unclassified rows',()=>{
 const r=setup(),f={refs:new Map([[JSON.stringify(['c','ref']),[{number:'001',routing:'123'},{number:'001',routing:'123'}]]])};
 r._accountPayments.add({...row(''),'FI Account Reference Number':'ref'},'single_payments','single',f,true);assert.equal(accountPaymentEvidence(r,'c','001').single,1);
 r._accountPayments.add({...row('002'),'FI Account Reference Number':'ref'},'single_payments','single',f,true);assert.equal(accountPaymentEvidence(r,'c','002').state,'Review needed');
 const other=setup();other._accountPayments.add(row(),'recurring_payments','unclassified',funding,true);assert.equal(accountPaymentEvidence(other,'c','001').state,'Review needed');
});
test('closed payment filter controls export without changing post-removal counts',()=>{
 const r={...setup(),customers:[{key:'c',name:'Customer',cifs:['0001']}],accounts:[{customerKey:'c'},{customerKey:'c'}],_accountNumbers:['001','002']};r._accountPayments.add(row(),'recurring_payments','model',funding,true);
 const a=createClosedAnalyzer(r);a.line('001,0001',1);a.line('002,0001',2);a.line('003,0001',3);const done=a.finish('test');assert.equal(done.summary.paymentCounts['Payments present'],1);assert.equal(done.rows[0].post,0);assert.equal(exportClosed(done,{payment:'Payments present'}),'0001,001\r\n');assert.equal(exportClosed(done,{payment:'None reported'}),'0001,002\r\n');assert.equal(done.rows[2].payments.state,'Not matched');
});
